#!perl

#---------------------------------------------------------------
# Topic	  : Exemple PERL traitement de l'autor�ponse de paiement
# Version : P600
#
# 	Dans cet exemple, les donn�es de la transaction	sont
#	d�crypt�es et sauvegard�es dans un fichier log.
#
#---------------------------------------------------------------

payment_autoresponse();



sub get_data_field {

# Acc�s au STDIN � l'aide de la fonction read

read(STDIN, $save_string, $ENV{CONTENT_LENGTH});

# Dissocie la cha�ne de caract�res en une liste

@prompts = split(/&/, $save_string);

# parcours de la liste

foreach (@prompts) {
	# dissocie la paire nom=valeur
	($name, $value) = split (/=/, $_);
	# decode les valeurs
	$name=~	s/\%(..)/pack("c",hex($1))/ge;
	$value=~	s/\%(..)/pack("c",hex($1))/ge;
	# cree une liste associative
	$fields{$name} = $value;
	}
$data=$fields{'DATA'};
}


sub payment_autoresponse
{

  # r�cup�ration de la variable crypt�e post�e
  # Initialisation de la variable message pour le binaire
  
  get_data_field();
  $message="message=$data";

  # Initialisation du chemin du fichier pathfile (� modifier)
  #   ex :
  #    -> Windows : $pathfile="pathfile=c:\\repertoire\\pathfile"
  #    -> Unix    : $pathfile="pathfile=/home/repertoire/pathfile"
  
  $pathfile="pathfile=chemin_du_fichier_pathfile";

 # Initialisation du chemin de l'executable response (� modifier)
 # ex :
 #    -> Windows : $path_bin = "c:\\repertoire\\bin\\response"
 #    -> Unix    : $path_bin = "/home/repertoire/bin/response"
 #
 	
	$path_bin = "chemin_de_l'executable_response";


 #	Tous les param�tres initialis�s pr�c�demment doivent �tre pass�s
 #	en param�tre � la fonction pesponse pour �tre pris en compte
 # 	L'ordre n'a pas d'importance
 #	Exemple : $parm = $message . " " . $pathfile;

 $parm = $message;
 
  # Appel du binaire response

 open(INFO, $path_bin . " " . $pathfile . " " . $parm . "|");
   for ($result = 0, $i = 0; <INFO>; $i++)
   {
       $result = $result . $_;
   }
 close(INFO);

   #	Sortie de la fonction : !code!error!v1!v2!v3!...!v29
   #		- code=0	: la fonction retourne les donn�es de la transaction dans les variables v1, v2, ...
   #				: Ces variables sont d�crites dans le GUIDE DU PROGRAMMEUR
   #		- code=-1 	: La fonction retourne un message d'erreur dans la variable error
   
   # on separe les differents champs et on les met dans une variable tableau
   
 @tableau = split("!",$result);

# recuperation des donnees de la reponse

	$code = $tableau[1];
	$error = $tableau[2];
	$merchant_id = $tableau[3];
	$merchant_country = $tableau[4];
	$amount = $tableau[5];
	$transaction_id = $tableau[6];
	$payment_means = $tableau[7];
	$transmission_date= $tableau[8];
	$payment_time = $tableau[9];
	$payment_date = $tableau[10];
	$response_code = $tableau[11];
	$payment_certificate = $tableau[12];
	$authorisation_id = $tableau[13];
	$currency_code = $tableau[14];
	$card_number = $tableau[15];
	$cvv_flag = $tableau[16];
	$cvv_response_code = $tableau[17];
	$bank_response_code = $tableau[18];
	$complementary_code = $tableau[19];
	$complementary_info = $tableau[20];
	$return_context = $tableau[21];
	$caddie = $tableau[22];
	$receipt_complement = $tableau[23];
	$merchant_language = $tableau[24];
	$language = $tableau[25];
	$customer_id = $tableau[26];
	$order_id = $tableau[27];
	$customer_email = $tableau[28];
	$customer_ip_address = $tableau[29];
	$capture_day = $tableau[30];
	$capture_mode = $tableau[31];
	$data = $tableau[32];

  # Initialisation du chemin du fichier log (� modifier)
  # ex :
  #    -> Windows : $logfile="c:\\repertoire\\log\\log.txt";
  #    -> Unix    : $logfile="/home/repertoire/log/log.txt";
  #

$logfile="chemin_du_fichier_de_log";

# Ouverture du fichier de log en append

open(LOG, ">>$logfile");

# analyse du code retour

 if (( $code eq "" ) && ( $error eq "" ) )
	{
 	print LOG "fichier response non trouve\n";
 	close(LOG);
    	return;
	};

 if ( $code != 0 )
 	{
 	print LOG "message erreur : $error\n";
 	close(LOG);
    	return;
	};

 # sauvegarde des champs de la reponse

 print LOG "merchant_id : $merchant_id\n";
 print LOG "merchant_country : $merchant_country\n";
 print LOG "amount : $amount\n";
 print LOG "transaction_id : $transaction_id\n";
 print LOG "transmission_date: $transmission_date\n";
 print LOG "payment_means: $payment_means\n";
 print LOG "payment_time : $payment_time\n";
 print LOG "payment_date : $payment_date\n";
 print LOG "response_code : $response_code\n";
 print LOG "payment_certificate : $payment_certificate\n";
 print LOG "authorisation_id : $authorisation_id\n";
 print LOG "currency_code : $currency_code\n";
 print LOG "card_number : $card_number\n";
 print LOG "cvv_flag: $cvv_flag\n";
 print LOG "cvv_response_code: $cvv_response_code\n";
 print LOG "bank_response_code: $bank_response_code\n";
 print LOG "complementary_code: $complementary_code\n";
 print LOG "complementary_info: $complementary_info\n";
 print LOG "return_context: $return_context\n";
 print LOG "caddie : $caddie\n";
 print LOG "receipt_complement: $receipt_complement\n";
 print LOG "merchant_language: $merchant_language\n";
 print LOG "language: $language\n";
 print LOG "customer_id: $customer_id\n";
 print LOG "order_id: $order_id\n";
 print LOG "customer_email: $customer_email\n";
 print LOG "customer_ip_address: $customer_ip_address\n";
 print LOG "capture_day: $capture_day\n";
 print LOG "capture_mode: $capture_mode\n";
 print LOG "data: $data";

 # Fermeture du fichier log

 close(LOG);

}


