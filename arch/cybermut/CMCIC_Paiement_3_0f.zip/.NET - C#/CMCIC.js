/*****************************************************************************
 *
 * "open source" kit for CMCIC-P@iement(TM) 
 *
 * File "CMCIC.js":
 *
 * Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.04
 * Date     : 01/01/2009
 *
 * Copyright: (c) 2009 Euro-Information. All rights reserved.
 * License  : see attached document "License.txt".
 *
 *****************************************************************************/

function DataCheck()
{
        var ref = document.getElementById("Reference");
	if (ref.value == "") {
		alert("Le champ Reference est obligatoire / Reference is a mandatory field");
		ref.focus();
		return false;
        }

        if (ref.value.length > 12) {
                alert("Le champ Reference a une taille maxi. de 12 caracteres / Reference field has a max length of 12 characters !");
                ref.focus();
		return false;
        }

        var montant = document.getElementById("Montant");
        if (isNaN(parseFloat(montant.value))){
                alert ("Le montant doit etre un nombre. / The amount must be a number");
                montant.focus();
		return false;
        }

	return true;
}

function Toggle(id){

        if (document.getElementById(id).style.display == "block")
                document.getElementById(id).style.display = "none";
        else
                document.getElementById(id).style.display = "block";
}

