/****************************************************************************
'
' "Open source" kit for CM-CIC P@iement (TM)
'
' File "CMCIC_Tpe.cs":
'
' Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
' Version  : 1.04
' Date     : 01/01/2009
'
' Copyright: (c) 2009 Euro-Information. All rights reserved.
' License  : see attached document "License.txt".
'
*****************************************************************************/

namespace CMCIC {

	using System;
	using System.Web;
	using System.Web.UI;
	using System.Web.UI.WebControls;
	using System.Data;
	using System.Security.Cryptography;
	using System.Text;


	public class CMCIC_Page : System.Web.UI.Page {


		protected CMCIC_Tpe oTpe;
		protected CMCIC_Hmac oHmac; 
		public string sReference;
		public string sMontant;
		public string sDevise;
		public string sLangue;
		public string sDate;
		public string sTexteLibre;
		public string sEmail;
		public string sOptions;

        public string sNbrEch;
        public string sDateEcheance1;
        public string sMontantEcheance1;
        public string sDateEcheance2;
        public string sMontantEcheance2;
        public string sDateEcheance3;
        public string sMontantEcheance3;
        public string sDateEcheance4;
        public string sMontantEcheance4;

		public string sDataToValidate;
		

		public CMCIC_Page() {

			oTpe = new CMCIC_Tpe();
			oHmac = new CMCIC_Hmac(oTpe);
		}

		public string HmacString {

			get { return sDataToValidate; }

		}

		public string HmacControlString {

			get { return "V1.04.sha1.aspx-C#.NET-[CtlHmac"+ sVersion + sNumero +"]-" + oHmac.computeHmac("CtlHmac" + sVersion + sNumero); }
		}

		public string sMAC {

			get { return oHmac.computeHmac(HmacString); }
		}

		public string sMontantForm {

			get { return this.sMontant + this.sDevise; }

		}

		public string sVersion {

			get { return oTpe.sVersion; }
		}

		public string sNumero {

			get { return oTpe.sNumero; }
		}

		public string sLangueForm {
			
			get { return oTpe.sLangue; }
		}

		public string sCodeSociete {

			get { return oTpe.sCodeSociete; }
		}


		public string sUrlOk {

			get { return oTpe.sUrlOk; }
		}

		public string sUrlKo {

			get { return oTpe.sUrlKo; }
		}

		public string sUrlPaiement {

			get { return oTpe.sUrlPaiement; }
		}

	}


	public partial class CMCIC_Tpe {

		const string CMCIC_URLPAIEMENT = "paiement.cgi";
		public string sVersion;
		public string sNumero;
		public string sLangue;
		public string sCodeSociete;
		public string sUrlOk;
		public string sUrlKo;
		public string sUrlPaiement;

		private string _sCle;

		public CMCIC_Tpe() : this ("FR") {

		}

		public CMCIC_Tpe(string sLangue) {

			this.sVersion = CMCIC_VERSION;
			this._sCle = CMCIC_CLE;
			this.sNumero = CMCIC_TPE;
			this.sUrlOk = CMCIC_URLOK;
			this.sUrlKo = CMCIC_URLKO;
			this.sUrlPaiement = CMCIC_SERVEUR + CMCIC_URLPAIEMENT;
			this.sCodeSociete = CMCIC_CODESOCIETE;
			this.sLangue = sLangue;

		}

		public string sCle {

			get { return this._sCle; }

		}

	}

	public class CMCIC_Hmac {


		private byte[] _sUsableKey;

		public CMCIC_Hmac(CMCIC_Tpe oTpe) {

			_sUsableKey = _getUsableKey(oTpe);

		}


		private byte[] _getUsableKey(CMCIC_Tpe oTpe) {
	
			string hexStrKey = oTpe.sCle.Substring(0, 38);
			string hexFinal = oTpe.sCle.Substring(38, 2) + "00";

			int cca0 = (int) hexFinal[0];

			if (cca0 > 70 && cca0 < 97) {
				hexStrKey += (char) (cca0 - 23) + hexFinal.Substring(1,1);
			}
			else {
				if (hexFinal.Substring(1,1) == "M")
					hexStrKey += hexFinal.Substring(0,1) + "0";
				else
					hexStrKey += hexFinal.Substring(0,2);
			}


			return (byte []) hexStringToByteArray(hexStrKey);
			
		}

		public string computeHmac(string sData) {

			HMACSHA1 TpeHmac = new HMACSHA1(_sUsableKey);

	                TpeHmac.Initialize();
			byte[] bytes = Encoding.ASCII.GetBytes(sData);
			byte[] ba = TpeHmac.ComputeHash(bytes);

			return this.byteArrayToHexString(ba);
		}

		public bool isValidHmac(string sChaineMAC, string sMAC) {

			return (this.computeHmac(sChaineMAC) == sMAC.ToLower());
		}

	        private object hexStringToByteArray(string hs) {

			string str = "";
			if (hs.StartsWith("0x")) {
				str = str + hs.Substring(2, hs.Length - 2);
			}
			else {
				str = str + hs;
			}

			int num = (int) Math.Round((double) (((double) str.Length) / 2.0));

			if (str.Length != (2 * num)) {
				str = "0" + str;
			}

			byte[] buffer = new byte[((int) Math.Round((double) ((((double) str.Length) / 2.0) - 1.0))) + 1];
			
			int num3 = buffer.Length - 1;
			for (int i = 0; i <= num3; i++) {
            
				buffer[i] = Convert.ToByte(str.Substring(2 * i, 2), 0x10);
			}

			return (byte[]) buffer.Clone();
		}

		private string byteArrayToHexString(byte[] ba) {

			string str = "";
			int num2 = ba.Length - 1;

			for (int i = 0; i <= num2; i++) {
				str = str + ba[i].ToString("x2");
			}

			return str;
		}

	}

}
