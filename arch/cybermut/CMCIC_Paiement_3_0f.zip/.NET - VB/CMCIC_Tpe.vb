'*****************************************************************************
'
' "Open source" kit for CM-CIC P@iement(TM).
' Process CMCIC Payment. Sample RFC2104 compliant with PHP4 skeleton.
'
' File "CMCIC_Tpe.vb" :
'
' Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
' Version  : 1.04
' Date     : 01/01/2009
'
' Copyright: (c) 2009 Euro-Information. All rights reserved.
' License  : see attached document "Licence.txt".
'
' *****************************************************************************

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Data
Imports System.Security.Cryptography
Imports System.Text

Namespace CMCIC 

	Public Class CMCIC_Page 

		Inherits Page


		Protected oTpe as CMCIC_Tpe
		Protected oHmac as CMCIC_Hmac
		Public sReference as String
		Public sMontant as String
		Public sDevise as String
		Public sLangue as String
		Public sDate as String
		Public sTexteLibre as String
		Public sEmail as String
        Public sOptions As String

        Public sNbrEch As String
        Public sDateEcheance1 As String
        Public sMontantEcheance1 As String
        Public sDateEcheance2 As String
        Public sMontantEcheance2 As String
        Public sDateEcheance3 As String
        Public sMontantEcheance3 As String
        Public sDateEcheance4 As String
        Public sMontantEcheance4 As String

		Public sDataToValidate as String

		Public Sub New() 

			oTpe = new CMCIC_Tpe()
			oHmac = new CMCIC_Hmac(oTpe)

		end Sub

		Public Readonly Property HmacString() as String

			Get 
				return sDataToValidate
			end Get

		end Property

		Public Readonly Property HmacControlString() as String

			Get 
				return "V1.04.sha1.aspx-VB.NET-[CtlHmac" & sVersion & sNumero & "]-" & oHmac.computeHmac("CtlHmac" & sVersion & sNumero)
			end Get

		end Property

		Public Readonly Property sMAC() as String

			Get 
				return oHmac.computeHmac(HmacString)
			end Get

		end Property

        Public ReadOnly Property sMontantForm() As String

            Get
                Return Me.sMontant + Me.sDevise
            End Get

        End Property

        Public ReadOnly Property sVersion() As String

            Get
                Return oTpe.sVersion
            End Get

        End Property

		Public Readonly Property sNumero() as String

			Get 
				return oTpe.sNumero
			end Get
		
		end Property

		Public Readonly Property sLangueForm() as String
			
			Get 
				return oTpe.sLangue
			end Get
		
		end Property

		Public Readonly Property sCodeSociete() as String

			Get 
				return oTpe.sCodeSociete
			end Get
		
		end Property


		Public Readonly Property sUrlOk() as String

			Get 
				return oTpe.sUrlOk
			end Get

		end Property

		Public Readonly Property sUrlKo() as String

			Get 
				return oTpe.sUrlKo
			end Get

		end Property


		Public Readonly Property sUrlPaiement() as String

			Get 
				return oTpe.sUrlPaiement
			end Get

		end Property

	end Class


	Public Partial Class CMCIC_Tpe

		Const CMCIC_URLPAIEMENT as String = "paiement.cgi"
		public sVersion as String
		Public sNumero as String
		Public sLangue as String
		Public sCodeSociete as String
		Public sUrlOk as String
		Public sUrlKo as String
		Public sUrlPaiement as String

		Private _sCle as String

		Public Sub New() 

			me.sVersion = CMCIC_VERSION
			me._sCle = CMCIC_CLE
			me.sNumero = CMCIC_TPE
			me.sUrlOk = CMCIC_URLOK
			me.sUrlKo = CMCIC_URLKO
			me.sUrlPaiement = CMCIC_SERVEUR & CMCIC_URLPAIEMENT
			me.sCodeSociete = CMCIC_CODESOCIETE
			me.sLangue = "FR"

		end Sub

		Public Sub New (ByVal sLangue as String) 

			me.sVersion = CMCIC_VERSION
			me._sCle = CMCIC_CLE
			me.sNumero = CMCIC_TPE
			me.sUrlOk = CMCIC_URLOK
			me.sUrlKo = CMCIC_URLKO
			me.sUrlPaiement = CMCIC_SERVEUR & CMCIC_URLPAIEMENT
			me.sCodeSociete = CMCIC_CODESOCIETE
			me.sLangue = sLangue

		end Sub

		Public Readonly Property sCle as String

			Get 
				return me._sCle
			end Get

		end Property

	end Class

	Public Class CMCIC_Hmac 


		Private _sUsableKey as Byte()

		Public Sub New(ByVal oTpe as CMCIC_Tpe) 

			_sUsableKey = _getUsableKey(oTpe)

		end Sub


		Private Function _getUsableKey(ByVal oTpe as CMCIC_Tpe) as Byte()
	
			Dim hexStrKey as String = oTpe.sCle.Substring(0, 38)
			Dim hexFinal as String = oTpe.sCle.Substring(38, 2) & "00"

			Dim cca0 as Int32 = Convert.ToInt32(hexFinal(0))

			If (cca0 > 70 And cca0 < 97) Then
				hexStrKey &=  Convert.ToChar(cca0 - 23) & hexFinal.Substring(1,1)
			Else 
				If (hexFinal.Substring(1,1) = "M") Then
					hexStrKey &= hexFinal.Substring(0,1) & "0"
				Else
					hexStrKey &= hexFinal.Substring(0,2)
				end If
			end If

			return hexStringToByteArray(hexStrKey)
			
		end Function

		Public Function computeHmac(ByVal sData as String) as String

			Dim TpeHmac as HMACSHA1 = new HMACSHA1(_sUsableKey)

	                TpeHmac.Initialize()
			Dim bytes as Byte() = Encoding.ASCII.GetBytes(sData)
			Dim ba as Byte() = TpeHmac.ComputeHash(bytes)

			return me.byteArrayToHexString(ba)

		end Function

		Public Function isValidHmac(ByVal sChaineMAC as String, ByVal sMAC as String) as Boolean

			return (me.computeHmac(sChaineMAC) = sMAC.ToLower())

		end Function

		Private Function hexStringToByteArray(ByVal hs as String) as Object
        
			Dim xs as String = ""
			If hs.startsWith("0x") Then
				xs &= hs.Substring(2,hs.length-2)
			Else
				xs &= hs
			end If

			Dim bal as Integer = xs.Length/2
			If xs.Length <> 2*bal then
				xs = "0" & xs
			end If

			Dim ba((xs.Length/2)-1) as Byte
			Dim i as Integer

			For i = 0 To ba.Length - 1
				ba(i) = System.convert.ToByte(xs.Substring(2*i,2),16)
			Next i
			Return CType(ba.Clone(), Byte())

		end Function

		Private Function byteArrayToHexString(ByVal ba() as [Byte]) as Object
			
			Dim i as Integer
			Dim s as String = ""
			For i = 0 To ba.Length - 1
				s = s & ba(i).toString("x2")
			Next i
			Return s

		end Function

	end Class

end Namespace
