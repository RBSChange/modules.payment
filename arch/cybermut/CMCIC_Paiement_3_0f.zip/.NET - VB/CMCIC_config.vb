'***************************************************************************************
' Warning !! CMCIC_Config contains the key, you have to protect this file with all     *   
' the mechanism available in your development environment.                             *
' You may for instance put this file in another directory and/or change its name       *
'***************************************************************************************

Namespace CMCIC 

	Public Partial Class CMCIC_Tpe 

		Const CMCIC_VERSION as String     = "3.0"
		Const CMCIC_TPE as String         = "0000001"
		Const CMCIC_CODESOCIETE as String = "yours"
		Const CMCIC_CLE as String         = "12345678901234567890123456789012345678P0"
		Const CMCIC_SERVEUR as String     = "https://paiement.creditmutuel.fr/test/"
		Const CMCIC_URLOK as String       = "http://www.google.fr"
		Const CMCIC_URLKO as String       = "http://www.google.nz"
	
	end Class

end Namespace
