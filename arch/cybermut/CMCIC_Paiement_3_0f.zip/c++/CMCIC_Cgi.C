/*****************************************************************************
 *
 * "Open source" kit for CM-CIC P@iement (TM)
 *
 * File "CMCIC_Cgi.C":
 *
 * Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.04
 * Date     : 01/01/2009
 *
 * Copyright: (c) 2009 Euro-Information. All rights reserved.
 * License  : see attached document "License.txt".
 *
 *****************************************************************************/

#include "CMCIC_Cgi.H"

/*----------------------------------------------------------------------------*
 * Constructeur
 *---------------------------------------------------------------------------*/
CMCIC_CGI::CMCIC_CGI()
{
	char *var;
	var = getenv("REQUEST_METHOD");
	if (var == NULL)
		throw CMCIC_CGIException(NO_REQUEST_METHOD);

	string methode(var);
	string data;

	if (methode == "POST") {
		var = getenv("CONTENT_LENGTH");
		if (var == NULL)
			throw CMCIC_CGIException(NO_CONTENT_LENGTH);

		int size=atoi(var);
		char c;

		for (int i=0; i<size; i++) {
			cin >> c;
			data += c;
		}
	}
	else if (methode == "GET") {
		var=getenv("QUERY_STRING");
		if (var == NULL)
			throw CMCIC_CGIException(NO_QUERY_STRING);
		data = var;
	}
	else {
		throw CMCIC_CGIException(INVALID_REQUEST_METHOD);
  	}

	split(data);
} 

/*----------------------------------------------------------------------------*
 * Destructeur
 *---------------------------------------------------------------------------*/

CMCIC_CGI::~CMCIC_CGI() {
}

/*----------------------------------------------------------------------------*
 * string CMCIC_CGI::operator[](const string s)
 *
 * Renvoie la valeur de la variable s si elle est d�finie, sinon renvoie une 
 * chaine vide
 *---------------------------------------------------------------------------*/

string CMCIC_CGI::operator[](const string s)
{
	if (cgi_data.find(s) != cgi_data.end())
		return cgi_data[s];

	return string("");

}

/*----------------------------------------------------------------------------*
 * Constructeur de la classe d'exception
 *---------------------------------------------------------------------------*/

CMCIC_CGI::CMCIC_CGIException::CMCIC_CGIException(int i)
{
	errnum=i;
} 

/*----------------------------------------------------------------------------*
 * void CMCIC_CGI::split(string s)
 *
 * S�pare la chaine de donn�es (POST ou GET) en un tableau variables / valeurs
 *---------------------------------------------------------------------------*/

void CMCIC_CGI::split(string s)
{
	static char ampersand='&';
	int position_amp;
	string var;
	pair<string,string> data;

	if ((position_amp = s.find(ampersand)) != -1) {

		var = s.substr(0,position_amp);
		unescape(var);
		data = couple(var);
		this->cgi_data[data.first]=data.second;
		split(s.substr(position_amp+1));
	}
	else {

		unescape(s);
		data = couple(s);
		this->cgi_data[data.first]=data.second;
	}
}

/*----------------------------------------------------------------------------*
 * char CMCIC_CGI::x2c(const string &s)
 *
 * Convertit s en son �quivalent hexd�cimal
 *---------------------------------------------------------------------------*/

char CMCIC_CGI::x2c(const string &s)
{
	char digit;
	digit = (s[0]>='A' ? ((s[0] & 0xdf)-'A')+10 : (s[0]-'0'));
	digit *= 16;
	digit += (s[1]>='A' ? ((s[1] & 0xdf)-'A')+10 : (s[1]-'0'));
	return digit;
} 

/*----------------------------------------------------------------------------*
 * void CMCIC_CGI::unescape(string &s)
 *
 * D�code les caract�res url-encod�s de la chaine s et convertit les '+' en espace
 *---------------------------------------------------------------------------*/

void CMCIC_CGI::unescape(string &s)
{

	static char plus = '+';
	int position_espace;
	while ((position_espace=s.find(plus)) != -1)
		s[position_espace]=' ';

	static char percent='%';
	int position_percent;
	string hex_seq;
	string reste = s;

	for (s="";((position_percent = reste.find(percent)) != -1);) {
		if (position_percent+2<static_cast<int>(reste.length()) &&
			isalnum(reste[position_percent + 1]) &&
			isalnum(reste[position_percent + 2])) {
        
			hex_seq = reste.substr(position_percent+1,2);
			s = s+reste.substr(0,position_percent)+x2c(hex_seq);
			reste = reste.erase(0,position_percent+3);
		}
		else {
	          s = s + reste.substr(0,position_percent+1);
        	  reste = reste.erase(0,position_percent+1);
		}
	}

	s += reste;
}

/*----------------------------------------------------------------------------*
 * pair<string,string> CMCIC_CGI:: couple(const string & s)
 *
 * Cr�e les paires variable / valeur
 *---------------------------------------------------------------------------*/

pair<string,string> CMCIC_CGI:: couple(const string & s)
{
	string nom, valeur;
	static char egal = '=';
	int position_egal = s.find(egal);

	nom = s.substr(0,position_egal);
	valeur = s.substr(position_egal+1);
	return make_pair(nom, valeur);
}
