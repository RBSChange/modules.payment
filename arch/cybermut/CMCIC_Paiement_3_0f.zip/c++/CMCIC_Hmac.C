/*****************************************************************************
 *
 * "Open source" kit for CM-CIC P@iement (TM)
 *
 * File "CMCIC_Hmac.C":
 *
 * Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.04
 * Date     : 01/01/2009
 *
 * Copyright: (c) 2009 Euro-Information. All rights reserved.
 * License  : see attached document "License.txt".
 *
 *****************************************************************************/

#include "CMCIC_Hmac.H"

/*----------------------------------------------------------------------------*
 * Constructeur
 *---------------------------------------------------------------------------*/

CMCIC_Hmac::CMCIC_Hmac(CMCIC_Tpe * oTpe) {

	_sUsableKey = _getUsableKey(oTpe);

}

/*----------------------------------------------------------------------------*
 * string CMCIC_Hmac::_getUsableKey(CMCIC_Tpe *oTpe)
 *
 * Renvoie la cl� sous forme de chaine hexad�cimale
 *---------------------------------------------------------------------------*/

string CMCIC_Hmac::_getUsableKey(CMCIC_Tpe *oTpe){
	
	string hexStrKey  = oTpe->getCle().substr(0,38);
	string hexFinal   = oTpe->getCle().substr(38, 2).append("00");
	string key;

	int cca0=(int) hexFinal.at(0);

	if (cca0>70 && cca0<97) {
		hexStrKey.push_back((char) (cca0-23));
		hexStrKey += hexFinal.at(1);
	}
	else if (hexFinal.at(2) == 'M') {
		hexStrKey += hexFinal.at(0);
		hexStrKey += "0";
	}
	else {
		hexStrKey += hexFinal.substr(0,2);
	}

	for (int i = 0; i < hexStrKey.size(); i = i + 2) {
		key += x2c(hexStrKey.substr(i, 2));
	}

	return key;
}

/*----------------------------------------------------------------------------*
 * char * CMCIC_Hmac::computeHmac(string sData)
 *
 * Renvoie le HMAC SHA1 pour la chaine sData
 *---------------------------------------------------------------------------*/

char * CMCIC_Hmac::computeHmac(string sData)
{
	unsigned char md[EVP_MAX_MD_SIZE];
	unsigned char * result;
	unsigned int md_size;

	result = HMAC(EVP_sha1(), 
		     _sUsableKey.c_str(), 
		     _sUsableKey.size(), 
		     (unsigned char *) sData.c_str(), 
		     sData.size(), 
		     md, 
		     &md_size);

	char *hmac = StrAllocation(md_size * 2);

	for (int i = 0; i < md_size; i++)
		sprintf( ((hmac)+(i*2)), "%02X", md[i]);

        return hmac;
}

/*----------------------------------------------------------------------------*
 * char CMCIC_Hmac::x2c(const string &s)
 *
 * Convertit s en son �quivalent hexadecimal
 *---------------------------------------------------------------------------*/

char CMCIC_Hmac::x2c(const string &s)
{
        char digit;
	digit = (s[0]>='A' ? ((s[0] & 0xdf)-'A')+10 : (s[0]-'0'));
	digit *= 16;
	digit += (s[1]>='A' ? ((s[1] & 0xdf)-'A')+10 : (s[1]-'0'));
	return digit;
}

/*----------------------------------------------------------------------------*
 * int CMCIC_Hmac::isValidHmac(string sChaineMAC, string sSentMAC)
 *
 * V�rifie si le HMAC de sChaineMAC est le m�me que sSentMAC
 *---------------------------------------------------------------------------*/

int CMCIC_Hmac::isValidHmac(string sChaineMAC, string sSentMAC){

	return (sSentMAC.compare(computeHmac(sChaineMAC)) == 0);

}

/*----------------------------------------------------------------------------*
 * Destructeur
 *---------------------------------------------------------------------------*/

CMCIC_Hmac::~CMCIC_Hmac() {

}
