/*****************************************************************************
 *
 * "Open source" kit for CM-CIC P@iement (TM)
 *
 * File "CMCIC_Tpe.C":
 *
 * Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.04
 * Date     : 01/01/2009
 *
 * Copyright: (c) 2009 Euro-Information. All rights reserved.
 * License  : see attached document "License.txt".
 *
 *****************************************************************************/

#include "CMCIC_Tpe.H"


/*----------------------------------------------------------------------------*
 * Constructeurs
 *---------------------------------------------------------------------------*/

CMCIC_Tpe::CMCIC_Tpe(string sLang) {

	sVersion = (string) CMCIC_VERSION;
	_sCle = (string) CMCIC_CLE;
	sNumero = (string) CMCIC_TPE;
	sUrlPaiement = (string) CMCIC_SERVEUR + (string) CMCIC_URLPAIEMENT;
	sCodeSociete = (string) CMCIC_CODESOCIETE;
	sLangue = sLang;
	sUrlOk = (string) CMCIC_URLOK;
	sUrlKo = (string) CMCIC_URLKO;
}

CMCIC_Tpe::CMCIC_Tpe() {

	sVersion = (string) CMCIC_VERSION;
	_sCle = (string) CMCIC_CLE;
	sNumero = (string) CMCIC_TPE;
	sUrlPaiement = (string) CMCIC_SERVEUR;
	sCodeSociete = (string) CMCIC_CODESOCIETE;
	sLangue = (string) "FR";
	sUrlOk = (string) CMCIC_URLOK;
	sUrlKo = (string) CMCIC_URLKO;
}

/*----------------------------------------------------------------------------*
 * Destructeur
 *---------------------------------------------------------------------------*/

CMCIC_Tpe::~CMCIC_Tpe() {

}
