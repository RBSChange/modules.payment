/*****************************************************************************
 *
 * "Open source" kit for CM-CIC P@iement (TM)
 *
 * File "Phase1Aller.C":
 *
 * Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.04
 * Date     : 01/01/2009
 *
 * Copyright: (c) 2009 Euro-Information. All rights reserved.
 * License  : see attached document "License.txt".
 *
 *****************************************************************************/

#include "Phase1Aller.H"

int main (int argc, char* argv[])
{
        
// ----------------------------------------------------------------------------
//  CheckOut Stub setting fictious Merchant and Order datas.
//  That's your job to set actual order fields. Here is a stub.
// -----------------------------------------------------------------------------
        
        string sPad = "*";

        // transaction date : format d/m/y:h:m:s
        string sDate = GetDateCommerce();

        // Amount : format  "xxxxx.yy" (no spaces)
        string sMontant = "1.01";

        // Currency : ISO 4217 compliant
        string sDevise = "EUR";

        // Language of the company code
        string sLangue = "FR";

        // Reference: unique, alphaNum (A-Z a-z 0-9), 12 characters max
        string sReference = GetReference();

        // free texte : a bigger reference, session context for the return on the merchant website
        string sTexteLibre = "Texte Libre";

        // Customer email
        string sEmail = "test@test.zz";
		
	// ----------------------------------------------------------------------------

	// between 2 and 4
	//string sNbrEch = "4";
	string sNbrEch = "";

	// date echeance 1 - format dd/mm/yyyy
	string sDateEcheance1 = "";

	// montant �ch�ance 1 - format  "xxxxx.yy" (no spaces)
	//string sMontantEcheance1 = "0.26" + sDevise;
	string sMontantEcheance1 = "";

	// date echeance 2 - format dd/mm/yyyy
	string sDateEcheance2 = "";

	// montant �ch�ance 2 - format  "xxxxx.yy" (no spaces)
	//string sMontantEcheance2 = "0.25" + sDevise;
	string sMontantEcheance2 = "";

	// date echeance 3 - format dd/mm/yyyy
	string sDateEcheance3 = "";

	// montant �ch�ance 3 - format  "xxxxx.yy" (no spaces)
	//string sMontantEcheance3 = "0.25" + sDevise;
	string sMontantEcheance3 = "";

	// date echeance 4 - format dd/mm/yyyy
	string sDateEcheance4 = "";

	// montant �ch�ance 4 - format  "xxxxx.yy" (no spaces)
	//string sMontantEcheance4 = "0.25" + sDevise;
	string sMontantEcheance4 = "";

        // ---------------------------------------------------------------------------

        string sOptions = "";

        CMCIC_Tpe *oTpe = new CMCIC_Tpe(sLangue);
        CMCIC_Hmac *oMac = new CMCIC_Hmac(oTpe);


        // Data to certify
        string sChaineMAC = oTpe->sNumero;
        sChaineMAC += sPad;
        sChaineMAC += sDate;
        sChaineMAC += sPad;
        sChaineMAC += sMontant;
        sChaineMAC += sDevise;
        sChaineMAC += sPad;
        sChaineMAC += sReference;
        sChaineMAC += sPad;
        sChaineMAC += sTexteLibre;
        sChaineMAC += sPad;
        sChaineMAC += oTpe->sVersion; 
        sChaineMAC += sPad;
        sChaineMAC += oTpe->sLangue;
        sChaineMAC += sPad;
        sChaineMAC += oTpe->sCodeSociete ;
        sChaineMAC += sPad;
        sChaineMAC += sEmail;
        sChaineMAC += sPad;
	sChaineMAC += sNbrEch;
	sChaineMAC += sPad;
	sChaineMAC += sDateEcheance1;
	sChaineMAC += sPad;
	sChaineMAC += sMontantEcheance1;
	sChaineMAC += sPad;
	sChaineMAC += sDateEcheance2;
	sChaineMAC += sPad;
	sChaineMAC += sMontantEcheance2;
	sChaineMAC += sPad;
	sChaineMAC += sDateEcheance3;
	sChaineMAC += sPad;
	sChaineMAC += sMontantEcheance3;
	sChaineMAC += sPad;
	sChaineMAC += sDateEcheance4;
	sChaineMAC += sPad;
	sChaineMAC += sMontantEcheance4;
	sChaineMAC += sPad;
        sChaineMAC += sOptions;

        // Control String for support
        string sChaineDebugMAC = "CtlHmac";
        sChaineDebugMAC += oTpe->sVersion;
        sChaineDebugMAC += oTpe->sNumero;

// ----------------------------------------------------------------------------
// Your Page displaying payment button to be customized  
// ----------------------------------------------------------------------------

        cout << "Content-type: text/html" << endl << endl; 
        cout << "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">" << endl;
        cout << "<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"fr\" lang=\"fr\">" << endl;
        cout << "<head>" << endl;
        cout << "<meta http-equiv=\"content-type\" content=\"text/html; charset=ISO-8859-1\" />" << endl;
        cout << "<meta http-equiv=\"cache-control\" content=\"no-store, no-cache, must-revalidate, post-check=0, pre-check=0\" />" << endl;
        cout << "<meta http-equiv=\"Expires\" content=\"Mon, 26 Jul 1997 05:00:00 GMT\" />" << endl;
        cout << "<meta http-equiv=\"pragma\" content=\"no-cache\" />" << endl;
        cout << "<title>Connexion au serveur de paiement</title>" << endl;
        cout << "<link type=\"text/css\" rel=\"stylesheet\" href=\"CMCIC.css\" />" << endl;
        cout << "</head>" << endl;
        cout << "<body>" << endl;
        cout << "<div id=\"header\">" << endl;
        cout << "<a href=\"http://www.cmcicpaiement.fr\"><img src=\"logocmcicpaiement.gif\" alt=\"CM-CIC P@iement\" title=\"CM-CIC P@iement\" /></a>" << endl;
        cout << "</div>" << endl;
        cout << "<h1>Connexion au serveur de paiement / <span class=\"anglais\">Connecting the payment server</span></h1>" << endl;
        cout << "<div id=\"presentation\">" << endl;
        cout << "       <p>" << endl;
        cout << "       Cette page g&eacute;n&egrave;re le formulaire de paiement avec des donn&eacute;es arbitraires.<br />" << endl;
        cout << "       <span class=\"anglais\">This page generates the payment form with some arbitrary data.</span>" << endl;
        cout << "       </p>" << endl;
        cout << "</div>" << endl;
        cout << "<div id=\"frm\">" << endl;
        cout << "<p>" << endl;
        cout << "       Cliquez sur le bouton ci-dessous pour vous connecter au serveur de paiement.<br />" << endl;
        cout << "       <span class=\"anglais\">Click on the following button to be redirected to the payment server.</span>" << endl;
        cout << "</p>" << endl;
        cout << "<!-- FORMULAIRE TYPE DE PAIEMENT / PAYMENT FORM TEMPLATE -->" << endl;
        cout << "<form action=\"" << oTpe->sUrlPaiement << "\" method=\"post\" id=\"PaymentRequest\">" << endl;
        cout << "<p>" << endl;
        cout << "       <input type=\"hidden\" name=\"version\"         id=\"version\"        value=\"" << oTpe->sVersion << "\" />" << endl;
        cout << "       <input type=\"hidden\" name=\"TPE\"             id=\"TPE\"            value=\"" << oTpe->sNumero << "\" />" << endl;
        cout << "       <input type=\"hidden\" name=\"date\"            id=\"date\"           value=\"" << sDate << "\" />" << endl;
        cout << "       <input type=\"hidden\" name=\"montant\"         id=\"montant\"        value=\"" << sMontant << sDevise << "\" />" << endl;
        cout << "       <input type=\"hidden\" name=\"reference\"       id=\"reference\"      value=\"" << sReference << "\" />" << endl;
        cout << "       <input type=\"hidden\" name=\"MAC\"             id=\"MAC\"            value=\"" << oMac->computeHmac(sChaineMAC) << "\" />" << endl;
        cout << "       <input type=\"hidden\" name=\"url_retour\"      id=\"url_retour\"     value=\"" << oTpe->sUrlKo << "\" />" << endl;
        cout << "       <input type=\"hidden\" name=\"url_retour_ok\"   id=\"url_retour_ok\"  value=\"" << oTpe->sUrlOk << "\" />" << endl;
        cout << "       <input type=\"hidden\" name=\"url_retour_err\"  id=\"url_retour_err\" value=\"" << oTpe->sUrlKo << "\" />" << endl;
        cout << "       <input type=\"hidden\" name=\"lgue\"            id=\"lgue\"           value=\"" << oTpe->sLangue << "\" />" << endl;
        cout << "       <input type=\"hidden\" name=\"societe\"         id=\"societe\"        value=\"" << oTpe->sCodeSociete << "\" />" << endl;
        cout << "       <input type=\"hidden\" name=\"texte-libre\"     id=\"texte-libre\"    value=\"" << sTexteLibre << "\" />" << endl;
        cout << "       <input type=\"hidden\" name=\"mail\"            id=\"mail\"           value=\"" << sEmail << "\" />" << endl;
	cout << " 	<!-- Uniquement pour le paiement fractionn&eacute; -->" << endl;
        cout << "	<input type=\"hidden\" name=\"nbrech\"          id=\"nbrech\"         value=\"" << sNbrEch << "\" />" << endl;
        cout << "	<input type=\"hidden\" name=\"dateech1\"        id=\"dateech1\"       value=\"" << sDateEcheance1 << "\" />" << endl;
        cout << "	<input type=\"hidden\" name=\"montantech1\"     id=\"montantech1\"    value=\"" << sMontantEcheance1 << "\" />" << endl;
        cout << "	<input type=\"hidden\" name=\"dateech2\"        id=\"dateech2\"       value=\"" << sDateEcheance2 << "\" />" << endl;
        cout << "	<input type=\"hidden\" name=\"montantech2\"     id=\"montantech2\"    value=\"" << sMontantEcheance2 << "\" />" << endl;
        cout << "	<input type=\"hidden\" name=\"dateech3\"        id=\"dateech3\"       value=\"" << sDateEcheance3 << "\" />" << endl;
        cout << "	<input type=\"hidden\" name=\"montantech3\"     id=\"montantech3\"    value=\"" << sMontantEcheance3 << "\" />" << endl;
        cout << "	<input type=\"hidden\" name=\"dateech4\"        id=\"dateech4\"       value=\"" << sDateEcheance4 << "\" />" << endl;
        cout << "	<input type=\"hidden\" name=\"montantech4\"     id=\"montantech4\"    value=\"" << sMontantEcheance4 << "\" />" << endl;
	cout << "	<!-- -->" << endl;
        cout << "       <input type=\"submit\" name=\"bouton\"          id=\"bouton\"         value=\"Connexion / Connection\" />" << endl;
        cout << "</p>" << endl;
        cout << "</form>" << endl;
        cout << "<!-- FIN FORMULAIRE TYPE DE PAIEMENT / END PAYMENT FORM TEMPLATE -->" << endl;
        cout << "</div>" << endl;
        cout << "<div id=\"source\">" << endl;
        cout << "       <h2>Uniquement pour le d&eacute;bogage / <span class=\"anglais\">For debug purpose only</span></h2>" << endl;
        cout << "<p>" << endl;
        cout << "Code source du formulaire.  <br />" << endl;
        cout << "<span class=\"anglais\">Form source code.</span>" << endl;
        cout << "</p>" << endl;
        cout << "<pre>" << endl;
        cout << "&lt;form <span class=\"name\">action</span>=\"<span class=\"value\">" << oTpe->sUrlPaiement << "\"</span> method=\"post\" id=\"PaymentRequest\"&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">version</span>\"          value=\"<span class=\"value\">" << oTpe->sVersion << "</span>\" /&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">TPE</span>\"              value=\"<span class=\"value\">" << oTpe->sNumero << "</span>\" /&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">date</span>\"             value=\"<span class=\"value\">" << sDate << "</span>\" /&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">montant</span>\"          value=\"<span class=\"value\">" << sMontant << sDevise << "</span>\" /&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">reference</span>\"        value=\"<span class=\"value\">" << sReference << "</span>\" /&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">MAC</span>\"              value=\"<span class=\"value\">" << oMac->computeHmac(sChaineMAC) << "</span>\" /&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">url_retour</span>\"       value=\"<span class=\"value\">" << oTpe->sUrlKo << "</span>\" /&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">url_retour_ok</span>\"    value=\"<span class=\"value\">" << oTpe->sUrlOk << "</span>\" /&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">url_retour_err</span>\"   value=\"<span class=\"value\">" << oTpe->sUrlKo << "</span>\" /&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">lgue</span>\"             value=\"<span class=\"value\">" << oTpe->sLangue << "</span>\" /&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">societe</span>\"          value=\"<span class=\"value\">" << oTpe->sCodeSociete << "</span>\" /&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">texte-libre</span>\"      value=\"<span class=\"value\">" << sTexteLibre << "</span>\" /&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">mail</span>\"             value=\"<span class=\"value\">" << sEmail << "</span>\" /&gt;" << endl;
	cout << "&lt;!-- Uniquement pour le paiement fractionn&eacute; --&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">nbrech</span>\"           value=\"<span class=\"value\">" << sNbrEch << "</span>\" /&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">dateech1</span>\"         value=\"<span class=\"value\">" << sDateEcheance1 << "</span>\" /&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">montantech1</span>\"      value=\"<span class=\"value\">" << sMontantEcheance1 << "</span>\" /&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">dateech2</span>\"         value=\"<span class=\"value\">" << sDateEcheance2 << "</span>\" /&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">montantech2</span>\"      value=\"<span class=\"value\">" << sMontantEcheance2 << "</span>\" /&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">dateech3</span>\"         value=\"<span class=\"value\">" << sDateEcheance3 << "</span>\" /&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">montantech3</span>\"      value=\"<span class=\"value\">" << sMontantEcheance3 << "</span>\" /&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">dateech4</span>\"         value=\"<span class=\"value\">" << sDateEcheance4 << "</span>\" /&gt;" << endl;
        cout << "&lt;input type=\"hidden\" name=\"<span class=\"name\">montantech4</span>\"      value=\"<span class=\"value\">" << sMontantEcheance4 << "</span>\" /&gt;" << endl;
	cout << "&lt;!-- --&gt;" << endl;        
        cout << "&lt;input type=\"submit\" name=\"<span class=\"name\">bouton</span>\"           value=\"<span class=\"value\">Connexion / Connection</span>\" /&gt;" << endl;
        cout << "&lt;/form&gt;" << endl; 
        cout << "</pre>" << endl;
        cout << "</div>" << endl;
        cout << "<div>" << endl;
        cout << "       <p>" << endl;
        cout << "       Cha&icirc;ne de contr&ocirc;le &agrave; fournir au support en cas de probl&egrave;mes <br />" << endl;
        cout << "       <span class=\"anglais\">Control string needed by support in case of problems</span>" << endl;
        cout << "       </p>" << endl;
        cout << "       <pre>V1.04.sha1.cpp--[CtlHmac" << oTpe->sVersion << oTpe->sNumero  << "]-" << oMac->computeHmac(sChaineDebugMAC) << "</pre>" << endl;
        cout << "       <p>" << endl;
        cout << "       Cha&icirc;ne utilis&eacute;e pour le calcul du sceau HMAC <br />" << endl;
        cout << "       Num&eacute;ro de TPE*date*montant*r&eacute;f&eacute;rence*texte libre*version*code langue*code soci&eacute;t&eacute;*email*nombre ech&eacute;ance*date &eacute;ch&eacute;ance1*montant &eacute;ch&eacute;ance1*date &eacute;ch&eacute;ance2*montant &eacute;ch&eacute;ance2*date &eacute;ch&eacute;ance3*montant &eacute;ch&eacute;ance3*date &eacute;ch&eacute;ance4*montant &eacute;ch&eacute;ance4*options<br />" << endl;
        cout << "       <span class=\"anglais\">String used to generate the HMAC<br />" << endl;
        cout << "       TPE number*date*amount*reference*free text*version*language code*company code*e-mail*nombre ech�ance*date �ch�ance1*montant �ch�ance1*date �ch�ance2*montant �ch�ance2*date �ch�ance3*montant �ch�ance3*date �ch�ance4*montant �ch�ance4*options</span>" << endl;
        cout << "       </p>" << endl;
        cout << "       <pre>" << sChaineMAC << "</pre>" << endl;
        cout << "</div>" << endl;
        cout << "<div id=\"footer\">" << endl;
        cout << "        <p>" << endl;
        cout << "       Cette page est fournie comme un exemple d'impl&eacute;mentation de la solution de paiement CyberMUT.<br />" << endl;
        cout << "       Elle n'a pas pour but de r&eacute;pondre &agrave; toutes les configurations existantes. &copy; 2009 Euro Informations.<br />" << endl;
        cout << "       <span class=\"anglais\">This page is just an example of the use of CyberMUT payment solution.<br />" << endl;
        cout << "       Its main purpose is not to give an answer to every existing configurations. &copy; 2009 Euro Informations</span>" << endl;
        cout << "       </p>" << endl;
        cout << "</div>" << endl;
        cout << "</body>" << endl;
        cout << "</html>" << endl;





        return 0;
}
