/*****************************************************************************
 *
 * "Open source" kit for CM-CIC P@iement (TM)
 *
 * File "Phase2Retour.C":
 *
 * Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.04
 * Date     : 01/01/2009
 *
 * Copyright: (c) 2009 Euro-Information. All rights reserved.
 * License  : see attached document "License.txt".
 *
 *****************************************************************************/

#include "Phase2Retour.H"

int main (int argc, char* argv[])
{

	CMCIC_CGI Cgi;
	CMCIC_Tpe *oTpe = new CMCIC_Tpe();
	CMCIC_Hmac *oMac = new CMCIC_Hmac(oTpe);

	string sResult;

	string sPad = "*";
	string sMAC = Cgi["MAC"];
	string sCodeRetour = Cgi["code-retour"];


	// Data to certify
	string sChaineMAC = oTpe->sNumero;
	sChaineMAC += sPad;
	sChaineMAC += Cgi["date"];
	sChaineMAC += sPad;
	sChaineMAC += Cgi["montant"];
	sChaineMAC += sPad;
	sChaineMAC += Cgi["reference"];
	sChaineMAC += sPad;
	sChaineMAC += Cgi["texte-libre"];
	sChaineMAC += sPad;
	sChaineMAC += oTpe->sVersion;
	sChaineMAC += sPad;
	sChaineMAC += sCodeRetour;
	sChaineMAC += sPad;
	sChaineMAC += Cgi["cvx"];
	sChaineMAC += sPad;
	sChaineMAC += Cgi["vld"];
	sChaineMAC += sPad;
	sChaineMAC += Cgi["brand"];
	sChaineMAC += sPad;
	sChaineMAC += Cgi["status3ds"];
	sChaineMAC += sPad;
	sChaineMAC += Cgi["numauto"];
	sChaineMAC += sPad;
	sChaineMAC += Cgi["motifrefus"];
	sChaineMAC += sPad;
	sChaineMAC += Cgi["originecb"];
	sChaineMAC += sPad;
	sChaineMAC += Cgi["bincb"];
	sChaineMAC += sPad;
	sChaineMAC += Cgi["hpancb"];
	sChaineMAC += sPad;
	sChaineMAC += Cgi["ipclient"];
	sChaineMAC += sPad;
	sChaineMAC += Cgi["originetr"];
	sChaineMAC += sPad;
	sChaineMAC += Cgi["veres"];
	sChaineMAC += sPad;
	sChaineMAC += Cgi["pares"];
	sChaineMAC += sPad;
	
        cout << "Pragma: no-cache" <<  "Content-type: text/plain" << endl << endl; 

	if (oMac->isValidHmac(sChaineMAC, sMAC)) {
		if (sCodeRetour.compare("Annulation") == 0) {
			// Payment has been refused
                        // put your code here (email sending / Database update)
                        // Attention : an autorization may still be delivered for this payment

		}
		else if (sCodeRetour.compare("payetest") == 0) {
                        // Payment has been accepted on the test server
                        // put your code here (email sending / Database update)

		}
		else if (sCodeRetour.compare("paiement") == 0) {
                        // Payment has been accepted on the production server
                        // put your code here (email sending / Database update)

		}

		/*** ONLY FOR MULTIPART PAYMENT ***/
		else if ((sCodeRetour.compare("paiement_pf2") == 0) || (sCodeRetour.compare("paiement_pf3") == 0) || (sCodeRetour.compare("paiement_pf4") == 0)) {
			// Payment has been accepted on the productive server for the part #N
			// return code is like paiement_pf[#N]
			// put your code here (email sending / Database update)
			// You have the amount of the payment part in CGI['montantech']
		}

		else if ((sCodeRetour.compare("Annulation_pf2") == 0) || (sCodeRetour.compare("Annulation_pf3") == 0) || (sCodeRetour.compare("Annulation_pf4") == 0)) {
			// Payment has been refused on the productive server for the part #N
			// return code is like Annulation_pf[#N]
			// put your code here (email sending / Database update)
			// You have the amount of the payment part in CGI['montantech']
		}

		sResult = MAC_OK;
	}
	else {

	        // traitement en cas de HMAC incorrect
        	// your code if the HMAC doesn't match

		sResult = MAC_NOT_OK;
		sResult += "\n";
		sResult += sChaineMAC;
	}

//-----------------------------------------------------------------------------
// Send receipt to CMCIC server
//-----------------------------------------------------------------------------

	cout << "version=2\ncdr=" << sResult;

        return 0;
}
