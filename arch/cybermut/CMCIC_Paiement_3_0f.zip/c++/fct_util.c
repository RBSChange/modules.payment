/*****************************************************************************
 *
 * "Open source" kit for CM-CIC P@iement (TM)
 *
 * File "fct_util.c":
 *
 * Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.04
 * Date     : 01/01/2009
 *
 * Copyright: (c) 2009 Euro-Information. All rights reserved.
 * License  : see attached document "License.txt".
 *
 *****************************************************************************/

#include "fct_util.h"

/*----------------------------------------------------------------------------*
 * char * StrAllocation (const int nbr)
 *
 * Cette fonction alloue un pointeur de chaine de nbr octets.
 *
 * Param�tre en sortie :
 *   result : pointeur de chaine
 *
 *---------------------------------------------------------------------------*/

char * StrAllocation (const int nbr)
{
    char* result;

    result = (char*) malloc (nbr * sizeof(char)+1);
    if (result == NULL) {
            fputs ("Probleme d'allocation memoire.\n", stderr);
            exit (1);
    }
    return result;
}


/*----------------------------------------------------------------------------*
 * char * GetDateCommerce ()
 *
 * Cette fonction renvoie la date au format attendu par le serveur bancaire.
 *
 * Param�tre en sortie :
 *   result : pointeur de chaine
 *
 *---------------------------------------------------------------------------*/

char * GetDateCommerce ()
{
    time_t     now;
    struct tm* tm;
    char *     cdate;

    cdate = StrAllocation(TIMESTAMP_LENGTH);

    now = time (NULL);
    tm  = localtime (&now);
    sprintf (cdate,
             "%02d/%02d/%04d:%02d:%02d:%02d",
              tm->tm_mday,
              tm->tm_mon+1,
              tm->tm_year + 1900,
              tm->tm_hour,
              tm->tm_min,
              tm->tm_sec);

    return cdate;
}

/*----------------------------------------------------------------------------*
 * char * GetReference ()
 *
 * Cette fonction renvoie une r�f�rence arbitraire de type "ref" + heuresminutessecondes.
 *
 * Param�tre en sortie :
 *   result : pointeur de chaine
 *
 *---------------------------------------------------------------------------*/

char * GetReference ()
{
    time_t     now;
    struct tm* tm;
    char *     ref;

    ref = StrAllocation(REF_LENGTH);

    now = time (NULL);
    tm  = localtime (&now);
    sprintf (ref,
             "ref%02d%02d%02d",
              tm->tm_hour,
              tm->tm_min,
              tm->tm_sec);

    return ref;
}

/*----------------------------------------------------------------------------*
 * char * GetNextMonth (const int nbrMonth)
 *
 * Cette fonction renvoie la date + N mois.
 *
 * Param�tre en sortie :
 *   result : pointeur de chaine
 *
 *---------------------------------------------------------------------------*/

char * GetNextMonth (const int nbrMonth)
{
    time_t     tt;
    struct tm* dt;
    struct tm* dtResult;
    char *     cdate;

    cdate = StrAllocation(TIMESTAMP_LENGTH);

    tt = time(NULL);
    dt = localtime(&tt);

    dt->tm_mon += nbrMonth;

    tt = mktime(dt);
    dtResult = localtime(&tt);

    sprintf (cdate,
             "%02d/%02d/%02d",
              dtResult->tm_mday,
              dtResult->tm_mon+1,
              dtResult->tm_year + 1900);

    return cdate;
}
