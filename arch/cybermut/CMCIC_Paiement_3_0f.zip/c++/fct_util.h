/*****************************************************************************
 *
 * "Open source" kit for CM-CIC P@iement (TM)
 *
 * File "fct_util.h":
 *
 * Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.04
 * Date     : 01/01/2009
 *
 * Copyright: (c) 2009 Euro-Information. All rights reserved.
 * License  : see attached document "License.txt".
 *
 *****************************************************************************/

#ifndef FCT_UTIL_H_
#define FCT_UTIL_H_

#include <stdio.h>
#include <string>

using namespace std;

#define TIMESTAMP_LENGTH 19
#define REF_LENGTH 10

char * StrAllocation (const int );
char * GetNextMonth (const int );
char * GetDateCommerce ();
char * GetReference ();

#endif
