#==============================================================================
#
# "Open source" kit for P@iement CM-CIC(TM).
# Integration sample in a merchant site for C++
#
# Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
# Version  : 1.0
# Date     : 01/01/2009
#
# Copyright: (c) 2009 Euro-Information. All rights reserved.
#
#==============================================================================

Files included in this example package :
CMCIC.css               : Cascaded Style Sheet file
fond.gif                : background image of the php pages
logocmcicpaiement.gif   : CMCIC P@iement logo
Phase1Aller.C           : Form example to connect to the payment page
Phase1Aller.H           : Header file for Phase1Aller.C
Phase2Retour.C          : Callback example to return an acknowledgment to the bank server
Phase2Retour.H          : Header file for Phase2Retour.C
CMCIC_Tpe.C             : TPE Class used in this example
CMCIC_Tpe.H             : Header file for CMCIC_Tpe.H
CMCIC_Hmac.C            : HMAC Class used in this example
CMCIC_Hmac.H            : Header file for CMCIC_Hmac.H
CMCIC_Config.H          : Key file. WARNING ! You have to protect this file with all the mechanism available in your development environment. 
CMCIC_Cgi.C             : CGI management implementation
CMCIC_Cgi.H             : Header file for CMCIC_Cgi.C
fct_util.c              : Functions used in this example
fct_util.h              : header file for fct_util.c
Makefile                : Building batch
License.txt             : Usage conditions of the previous files
readme.txt              : This current file
