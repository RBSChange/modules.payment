/*****************************************************************************
 *
 * "Open source" kit for CM-CIC P@iement (TM)
 *
 * File "Phase1Aller.java":
 *
 * Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.04
 * Date     : 01/01/2009
 *
 * Copyright: (c) 2009 Euro-Information. All rights reserved.
 * License  : see attached document "License.txt".
 *
 *****************************************************************************/

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


 public class Phase1Aller extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
	 
	final static long serialVersionUID = 1L;
	
	public Phase1Aller() {
		super();
	}   	
	
	/*-----------------------------------------------------------------------*
     * french style date format 
     *-----------------------------------------------------------------------*/
    final private static String datePaiement(String sFormat, int nbMonth) {
        SimpleDateFormat formatter = new SimpleDateFormat (sFormat);
        Date now = new Date();
		now = deplacerDate(now, nbMonth);
        return formatter.format(now);
    }
	
 
	/*-----------------------------------------------------------------------*
     * arbitrary reference 
     *-----------------------------------------------------------------------*/  
    final private static String refPaiement() {
    	SimpleDateFormat formatter = new SimpleDateFormat("HHmmss");
    	Date now = new Date();
    	
    	return "ref" + formatter.format(now);
    }
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
		
		// ----------------------------------------------------------------------------
		//  CheckOut Stub setting fictitious Merchant and Order data.
		//  That's your job to set actual order fields. Here is a stub.
		// -----------------------------------------------------------------------------	
			
		// Reference: unique, alphaNum (A-Z a-z 0-9), 12 characters max	
		String sReference = refPaiement();
		
		// Language of the company code		
		String sLangue = request.getParameter("Langue");
		
		// Amount : format  "xxxxx.yy" (no spaces)
		String sMontant = "1.01";
		
		// Currency : ISO 4217 compliant
		String sDevise = "EUR";
		
		// free texte : a bigger reference, session context for the return on the merchant website
		String sTexteLibre = "Texte Libre";
		
		// transaction date : format dd/mm/yyyy:hh:mm:ss
		String sDate = datePaiement("dd/MM/yyyy:HH:mm:ss", 0); 
		
		// customer email
		String sEmail = "test@test.zz";
		
		// ----------------------------------------------------------------------------
		// Paiement fractionn�
		
		
		// between 2 and 4
		//String sNbrEch = "4";
		String sNbrEch = "";

		// date echeance 1 - format dd/mm/yyyy
		String sDateEcheance1 = "";

		// montant �ch�ance 1 - format  "xxxxx.yy" (no spaces)
		//String sMontantEcheance1 = "0.26" + sDevise;
		String sMontantEcheance1 = "";

		// date echeance 2 - format dd/mm/yyyy
		String sDateEcheance2 = "";

		// montant �ch�ance 2 - format  "xxxxx.yy" (no spaces)
		//String sMontantEcheance2 = "0.25" + sDevise;
		String sMontantEcheance2 = "";

		// date echeance 3 - format dd/mm/yyyy
		String sDateEcheance3 = "";

		// montant �ch�ance 3 - format  "xxxxx.yy" (no spaces)
		//String sMontantEcheance3 = "0.25" + sDevise;
		String sMontantEcheance3 = "";

		// date echeance 4 - format dd/mm/yyyy
		String sDateEcheance4 = "";

		// montant �ch�ance 4 - format  "xxxxx.yy" (no spaces)
		//String sMontantEcheance4 = "0.25" + sDevise;
		String sMontantEcheance4 = "";

		// ---------------------------------------------------------------------------------
		
		String sOptions = "";
		
		CMCIC_Tpe oTpe = new CMCIC_Tpe(sLangue);
		CMCIC_Hmac oMac = new CMCIC_Hmac(oTpe);
		
		/*-----------------------------------------------------------------------*
	     * control string needed by support
	     *-----------------------------------------------------------------------*/
		String sChaineDebug = "V1.04.sha1.java--[CtlHmac" + oTpe.sVersion + oTpe.sNumero + "]-" + oMac.computeHmac("CtlHmac" + oTpe.sVersion + oTpe.sNumero);
		
		/*-----------------------------------------------------------------------*
	     * data string for hmac
	     *-----------------------------------------------------------------------*/
		String sChaineMAC = oTpe.sNumero +"*"+ sDate +"*"+ sMontant + sDevise +"*"+ sReference +"*"+ sTexteLibre +"*"+ oTpe.sVersion +"*"+ oTpe.sLangue +"*"+ oTpe.sCodeSociete +"*"+ sEmail +"*"
							+ sNbrEch +"*"+ sDateEcheance1 +"*"+ sMontantEcheance1 +"*"+ sDateEcheance2 +"*"+ sMontantEcheance2 +"*"+ sDateEcheance3 +"*"+ sMontantEcheance3 +"*"+ sDateEcheance4 +"*"+ sMontantEcheance4 +"*"+ sOptions;
		
		
		response.setHeader("Pragma","no-cache");
        response.setHeader("Cache-Control","no-cache");
        response.setDateHeader("Expires",0);
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        // ----------------------------------------------------------------------------
        // Your Page displaying payment button to be customized  
        // ----------------------------------------------------------------------------
        
		out.println("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">\n"
					+ "<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"fr\" lang=\"fr\">\n"
					+ "<head>\n"
					+ "<meta http-equiv=\"content-type\" content=\"text/html; charset=ISO-8859-1\" />\n"
					+ "<meta http-equiv=\"cache-control\" content=\"no-store, no-cache, must-revalidate, post-check=0, pre-check=0\" />\n"
					+ "<meta http-equiv=\"Expires\" content=\"Mon, 26 Jul 1997 05:00:00 GMT\" />\n"
					+ "<meta http-equiv=\"pragma\" content=\"no-cache\" />\n"
					+ "<title>Connexion au serveur de paiement</title>\n"
					+ "<link type=\"text/css\" rel=\"stylesheet\" href=\"CMCIC.css\" />\n"
					+ "</head>\n"
					+ "<body>\n"
					+ "<div id=\"header\">\n"
			        + "<a href=\"http://www.cmcicpaiement.fr\"><img src=\"logocmcicpaiement.gif\" alt=\"CM-CIC P@iement\" title=\"CM-CIC P@iement\" /></a>\n"
			        + "</div>\n"
			        + "<h1>Connexion au serveur de paiement / <span class=\"anglais\">Connecting the payment server</span></h1>\n"
			        + "<div id=\"presentation\">\n"
			        + "<p>\n"
			        + "Cette page g&eacute;n&egrave;re le formulaire de paiement avec des donn&eacute;es arbitraires.<br />\n"
			        + "<span class=\"anglais\">This page generates the payment form with some arbitrary data.</span>\n"
			        + "</p>\n"
			        + "</div>\n"
			        + "<div id=\"frm\">\n"
			        + "<p>\n"
			    	+ "Cliquez sur le bouton ci-dessous pour vous connecter au serveur de paiement.<br />\n"
			    	+ "<span class=\"anglais\">Click on the following button to be redirected to the payment server.</span>\n"
			    	+ "</p>\n"
			    	+ "<!-- FORMULAIRE TYPE DE PAIEMENT / PAYMENT FORM TEMPLATE -->\n"
			    	+ "<form action=\""+ oTpe.sUrlPaiement +"\" method=\"post\" id=\"PaymentRequest\">\n"
			    	+ "<p>\n"
			    	+ "<input type=\"hidden\" name=\"version\"		id=\"version\"        value=\"" + oTpe.sVersion + "\" />\n"
			    	+ "<input type=\"hidden\" name=\"TPE\"		id=\"TPE\"            value=\"" + oTpe.sNumero + "\" />\n"
			    	+ "<input type=\"hidden\" name=\"date\"		id=\"date\"           value=\"" + sDate + "\" />\n"
			    	+ "<input type=\"hidden\" name=\"montant\"		id=\"montant\"        value=\""+ sMontant + sDevise +"\" />\n"
			    	+ "<input type=\"hidden\" name=\"reference\"	id=\"reference\"      value=\""+ sReference +"\" />\n"
			    	+ "<input type=\"hidden\" name=\"MAC\"		id=\"MAC\"            value=\""+ oMac.computeHmac(sChaineMAC) +"\" />\n"
			    	+ "<input type=\"hidden\" name=\"url_retour\"	id=\"url_retour\"     value=\"" + oTpe.sUrlKo + "\" />\n"
			    	+ "<input type=\"hidden\" name=\"url_retour_ok\"	id=\"url_retour_ok\"  value=\"" + oTpe.sUrlOk + "\" />\n"
			    	+ "<input type=\"hidden\" name=\"url_retour_err\"	id=\"url_retour_err\" value=\"" + oTpe.sUrlKo + "\" />\n"
			    	+ "<input type=\"hidden\" name=\"lgue\"		id=\"lgue\"           value=\"" + oTpe.sLangue + "\" />\n"
			    	+ "<input type=\"hidden\" name=\"societe\"		id=\"societe\"        value=\"" + oTpe.sCodeSociete + "\" />\n"
			    	+ "<input type=\"hidden\" name=\"texte-libre\"	id=\"texte-libre\"    value=\"" + sTexteLibre + "\" />\n"
			    	+ "<input type=\"hidden\" name=\"mail\"		id=\"mail\"	      value=\"" + sEmail + "\" />\n"
			    	+ "<!-- Uniquement pour le Paiement fractionn&eacute; -->\n"
					+ "<input type=\"hidden\" name=\"nbrech\"         id=\"nbrech\"        value=\"" + sNbrEch + "\" />\n"
					+ "<input type=\"hidden\" name=\"dateech1\"       id=\"dateech1\"      value=\"" + sDateEcheance1 + "\" />\n"
					+ "<input type=\"hidden\" name=\"montantech1\"    id=\"montantech1\"   value=\"" + sMontantEcheance1 + "\" />\n"
					+ "<input type=\"hidden\" name=\"dateech2\"       id=\"dateech2\"      value=\"" + sDateEcheance2 + "\" />\n"
					+ "<input type=\"hidden\" name=\"montantech2\"    id=\"montantech2\"   value=\"" + sMontantEcheance2 + "\" />\n"
					+ "<input type=\"hidden\" name=\"dateech3\"	    id=\"dateech3\"      value=\"" + sDateEcheance3 + "\" />\n"
					+ "<input type=\"hidden\" name=\"montantech3\"    id=\"montantech3\"   value=\"" + sMontantEcheance3 + "\" />\n"
					+ "<input type=\"hidden\" name=\"dateech4\"	    id=\"dateech4\"      value=\"" + sDateEcheance4 + "\" />\n"
					+ "<input type=\"hidden\" name=\"montantech4\"    id=\"montantech4\"   value=\"" + sMontantEcheance4 + "\" />\n"
					+ "<!-- -->\n"
			    	+ "<input type=\"submit\" name=\"bouton\"		id=\"bouton\"         value=\"Connexion / Connection\" />\n"
			    	+ "</p>\n"
			    	+ "</form>\n"
			    	+ "<!-- FIN FORMULAIRE TYPE DE PAIEMENT / END PAYMENT FORM TEMPLATE -->\n"
			    	+ "</div>\n"
			    	+ "<div id=\"source\">\n"
			    	+ "<h2>Uniquement pour le d&eacute;bogage / <span class=\"anglais\">For debug purpose only</span></h2>\n"
			        + "<p>\n"
			    	+ "Code source du formulaire.  <br />\n"
			    	+ "<span class=\"anglais\">Form source code.</span>\n"
			        + "</p>\n"
			        + "<pre>\n"
			        + "&lt;form <span class=\"name\">action</span>=\"<span class=\"value\">"+ oTpe.sUrlPaiement +"\"</span> method=\"post\" id=\"PaymentRequest\"&gt;\n"
			        + "&lt;input type=\"hidden\" name=\"<span class=\"name\">version</span>\"          value=\"<span class=\"value\">" + oTpe.sVersion + "</span>\" /&gt;\n"
			        + "&lt;input type=\"hidden\" name=\"<span class=\"name\">TPE</span>\"              value=\"<span class=\"value\">" + oTpe.sNumero + "</span>\" /&gt;\n"
			        + "&lt;input type=\"hidden\" name=\"<span class=\"name\">date</span>\"             value=\"<span class=\"value\">" + sDate + "</span>\" /&gt;\n"
			        + "&lt;input type=\"hidden\" name=\"<span class=\"name\">montant</span>\"          value=\"<span class=\"value\">"+ sMontant + sDevise +"</span>\" /&gt;\n"
			        + "&lt;input type=\"hidden\" name=\"<span class=\"name\">reference</span>\"        value=\"<span class=\"value\">"+ sReference +"</span>\" /&gt;\n"
			        + "&lt;input type=\"hidden\" name=\"<span class=\"name\">MAC</span>\"              value=\"<span class=\"value\">"+ oMac.computeHmac(sChaineMAC) +"</span>\" /&gt;\n"
			        + "&lt;input type=\"hidden\" name=\"<span class=\"name\">url_retour</span>\"       value=\"<span class=\"value\">" + oTpe.sUrlKo + "</span>\" /&gt;\n"
			        + "&lt;input type=\"hidden\" name=\"<span class=\"name\">url_retour_ok</span>\"    value=\"<span class=\"value\">" + oTpe.sUrlOk + "</span>\" /&gt;\n"
			        + "&lt;input type=\"hidden\" name=\"<span class=\"name\">url_retour_err</span>\"   value=\"<span class=\"value\">" + oTpe.sUrlKo + "</span>\" /&gt;\n"
			        + "&lt;input type=\"hidden\" name=\"<span class=\"name\">lgue</span>\"             value=\"<span class=\"value\">" + oTpe.sLangue + "</span>\" /&gt;\n"
			        + "&lt;input type=\"hidden\" name=\"<span class=\"name\">societe</span>\"          value=\"<span class=\"value\">" + oTpe.sCodeSociete + "</span>\" /&gt;\n"
			        + "&lt;input type=\"hidden\" name=\"<span class=\"name\">texte-libre</span>\"      value=\"<span class=\"value\">" + sTexteLibre + "</span>\" /&gt;\n"
			        + "&lt;input type=\"hidden\" name=\"<span class=\"name\">mail</span>\"             value=\"<span class=\"value\">" + sEmail + "</span>\" /&gt;\n"
			        + "&lt;!-- Uniquement pour le Paiement fractionn&eacute; --&gt;\n"
					+ "&lt;input type=\"hidden\" name=\"<span class=\"name\">nbrech</span>\"           value=\"<span class=\"value\">" + sNbrEch + "</span>\" /&gt;\n"
					+ "&lt;input type=\"hidden\" name=\"<span class=\"name\">dateech1</span>\"         value=\"<span class=\"value\">" + sDateEcheance1 + "</span>\" /&gt;\n"
					+ "&lt;input type=\"hidden\" name=\"<span class=\"name\">montantech1</span>\"      value=\"<span class=\"value\">" + sMontantEcheance1 + "</span>\" /&gt;\n"
					+ "&lt;input type=\"hidden\" name=\"<span class=\"name\">dateech2</span>\"         value=\"<span class=\"value\">" + sDateEcheance2 + "</span>\" /&gt;\n"
					+ "&lt;input type=\"hidden\" name=\"<span class=\"name\">montantech2</span>\"      value=\"<span class=\"value\">" + sMontantEcheance2 + "</span>\" /&gt;\n"
					+ "&lt;input type=\"hidden\" name=\"<span class=\"name\">dateech3</span>\"         value=\"<span class=\"value\">" + sDateEcheance3 + "</span>\" /&gt;\n"
					+ "&lt;input type=\"hidden\" name=\"<span class=\"name\">montantech3</span>\"      value=\"<span class=\"value\">" + sMontantEcheance3 + "</span>\" /&gt;\n"
					+ "&lt;input type=\"hidden\" name=\"<span class=\"name\">dateech4</span>\"         value=\"<span class=\"value\">" + sDateEcheance4 + "</span>\" /&gt;\n"
					+ "&lt;input type=\"hidden\" name=\"<span class=\"name\">montantech4</span>\"      value=\"<span class=\"value\">" + sMontantEcheance4 + "</span>\" /&gt;\n"
					+ "&lt;!-- --&gt;\n"
			        + "&lt;input type=\"submit\" name=\"<span class=\"name\">bouton</span>\"           value=\"<span class=\"value\">Connexion / Connection</span>\" /&gt;\n"
			        + "&lt;/form&gt;\n"
			        + "</pre>\n"
			        + "</div>\n"
			    	+ "<div>\n"
			    	+ "<h2>Uniquement pour le d&eacute;bogage / <span class=\"anglais\">For debug purpose only</span></h2>\n"
			    	+ "<p>\n"
			    	+ "Cha&icirc;ne de contr&ocirc;le &agrave; fournir au support en cas de probl&egrave;mes <br />\n"
			    	+ "<span class=\"anglais\">Control string needed by support in case of problems</span>\n"
			    	+ "</p>\n"
			    	+ "<pre>"+ sChaineDebug +"</pre>\n"
			    	+ "<p>\n"
			    	+ "Cha&icirc;ne utilis&eacute;e pour le calcul du sceau HMAC <br />\n"
			    	+ "Num&eacute;ro de TPE*date*montant*r&eacute;f&eacute;rence*texte libre*version*code langue*code soci&eacute;t&eacute;*email*nombre &eacute;ch&eacute;ance*date &eacute;ch&eacute;ance1*montant &eacute;ch&eacute;ance1*date &eacute;ch&eacute;ance2*montant &eacute;ch&eacute;ance2*date &eacute;ch&eacute;ance3*montant &eacute;ch&eacute;ance3*date &eacute;ch&eacute;ance4*montant &eacute;ch&eacute;ance4*options<br />\n"
			    	+ "<span class=\"anglais\">String used to generate the HMAC<br />\n"
			    	+ "TPE number*date*amount*reference*free text*version*language code*company code*e-mail*nombre ech�ance*date �ch�ance1*montant �ch�ance1*date �ch�ance2*montant �ch�ance2*date �ch�ance3*montant �ch�ance3*date �ch�ance4*montant �ch�ance4*options</span>\n"
			    	+ "</p>\n"
			    	+ "<pre>" + sChaineMAC + "</pre>\n"
			    	+ "</p>\n"
			    	+ "</div>\n"
			    	+ "<div id=\"footer\">\n"
			        + "<p>\n"
			        + "Cette page est fournie comme un exemple d'impl&eacute;mentation de la solution de paiement CyberMUT.<br />\n"
			        + "Elle n'a pas pour but de r&eacute;pondre &agrave; toutes les configurations existantes. &copy; 2009 Euro Informations.<br />\n"
			        + "<span class=\"anglais\">This page is just an example of the use of CyberMUT payment solution.<br />\n"
			        + "Its main purpose is not to give an answer to every existing configurations. &copy; 2009 Euro Informations</span>\n"
			        + "</p>\n"
					+ "</div>\n"
					+ "</body>\n"
					+ "</html>");
		
		out.close();
		}
		
		catch (Exception e) {
			
			System.out.println("CMCIC-P@iement failed.");
            // Here you may use 'e' to get more information about the
            // incident, but be careful not showing it to the user since
            // it may contain confidential informations.
		}
						
	}
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}  	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}   	  	    
}
