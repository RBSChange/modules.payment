/*****************************************************************************
 *
 * "Open source" kit for CM-CIC P@iement (TM)
 *
 * File "Phase2Retour.java":
 *
 * Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.04
 * Date     : 01/01/2009
 *
 * Copyright: (c) 2009 Euro-Information. All rights reserved.
 * License  : see attached document "License.txt".
 *
 *****************************************************************************/

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


 public class Phase2Retour extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
	 
	final static long serialVersionUID = 1L;
	
	public Phase2Retour() {
		super();
	}   	
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
		CMCIC_Tpe oTpe = new CMCIC_Tpe();
		CMCIC_Hmac oMac = new CMCIC_Hmac(oTpe);
		String sResult;
		
		String montant          = (request.getParameter("montant")!= null) ?  request.getParameter("montant") : "";
		String reference        = (request.getParameter("reference")!= null) ?  request.getParameter("reference") : "";
		String MAC              = (request.getParameter("MAC")!= null) ?  request.getParameter("MAC") : "";
		String TexteLibre       = (request.getParameter("texte-libre")!= null) ?  request.getParameter("texte-libre") : "";
		String CodeRetour       = (request.getParameter("code-retour")!= null) ?  request.getParameter("code-retour") : "";
		String dateConfirmation = (request.getParameter("date")!= null) ?  request.getParameter("date") : "";
		String Cvx		 	 = (request.getParameter("cvx")!= null) ?  request.getParameter("cvx") : "";
		String Vld		 	 = (request.getParameter("vld")!= null) ?  request.getParameter("vld") : "";
		String Brand		 = (request.getParameter("brand")!= null) ?  request.getParameter("brand") : "";
		String Status3DS 	 = (request.getParameter("status3ds")!= null) ?  request.getParameter("status3ds") : "";
		String NumAuto 	 	 = (request.getParameter("numauto")!= null) ?  request.getParameter("numauto") : "";
		String MotifRefus	 = (request.getParameter("motifrefus") != null) ?  request.getParameter("motifrefus") : "";
		String OrigineCB	 = (request.getParameter("originecb")!= null) ?  request.getParameter("originecb") : "";
		String BinCB		 = (request.getParameter("bincb")!= null) ?  request.getParameter("bincb") : "";
		String HPanCB		 = (request.getParameter("hpancb")!= null) ?  request.getParameter("hpancb") : "";
		String IPClient	 	 = (request.getParameter("ipclient")!= null) ?  request.getParameter("ipclient") : "";
		String OrigineTr	 = (request.getParameter("originetr")!= null) ?  request.getParameter("originetr") : "";
		String VeRes		 = (request.getParameter("veres")!= null) ?  request.getParameter("veres") : "";
		String PaRes		 = (request.getParameter("pares")!= null) ?  request.getParameter("pares") : "";
		String MontantEch	 = (request.getParameter("montantech") != null) ? request.getParameter("montantech") : "";
		
		/*-----------------------------------------------------------------------*
	     * data string for hmac
	     *-----------------------------------------------------------------------*/
		String sChaineMAC = oTpe.sNumero + "*" + dateConfirmation + "*" + montant + "*" + reference + "*" + TexteLibre + "*" + oTpe.sVersion + "*" + CodeRetour + "*";
		sChaineMAC += Cvx + "*" + Vld + "*" + Brand + "*" + Status3DS + "*" + NumAuto + "*" + MotifRefus + "*";
		sChaineMAC += OrigineCB + "*" + BinCB + "*" + HPanCB + "*" + IPClient + "*" + OrigineTr + "*" + VeRes + "*" + PaRes + "*";
		
		response.setHeader("Pragma","no-cache");
        response.setHeader("Cache-Control","no-cache");
        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();
        
        if (oMac.isValidHmac(sChaineMAC, MAC) == true) {
        	
        	if (CodeRetour == "Annulation") {
        		
				/* Payment has been refused
				   put your code here (email sending / Database update)
				   Attention : an authorization may still be delivered later   */
        	}
        	else if (CodeRetour == "paiement") {
				/* Payment has been accepted on the test server
				   put your code here (email sending / Database update) */
        	}
        	else if (CodeRetour == "payetest") {
        		/* Payment has been accepted on the productive server
				   put your code here (email sending / Database update) */
        	}

		/*** ONLY FOR MULTIPART PAYMENT ***/
		else if ((CodeRetour == "paiement_pf2") || (CodeRetour == "paiement_pf3") || (CodeRetour == "paiement_pf4")) {
			/* Payment has been accepted on the productive server for the part #N
			   return code is like paiement_pf[#N]
			   put your code here (email sending / Database update)
			   You have the amount of the payment part in MontantEch */
		}

		else if ((CodeRetour == "Annulation_pf2") || (CodeRetour == "Annulation_pf3") || (CodeRetour == "Annulation_pf4")) {
			// Payment has been refused on the productive server for the part #N
			// return code is like Annulation_pf[#N]
			// put your code here (email sending / Database update)
			// You have the amount of the payment part in MontantEch
		}
        	
        	sResult = "0";
        }
        else {
        	sResult = "1\n" + sChaineMAC;
        }
        
    	/*-----------------------------------------------------------------------*
         * Acknowledgment message
         *-----------------------------------------------------------------------*/
        out.println("version=2\ncdr=" + sResult);
		out.close();
		}
		
		catch (Exception e) {
			
			System.out.println("CMCIC-P@iement failed.");
            // Here you may use 'e' to get more information about the
            // incident, but be careful not showing it to the user since
            // it may contain confidential informations.
		}
						
	}
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				processRequest(request, response);
	}  	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			processRequest(request, response);
	}   	  	    
}
