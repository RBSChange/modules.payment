#==============================================================================
#
# "Open source" kit for P@iement CM-CIC(TM).
# Integration sample in a merchant site for Java
#
# Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
# Version  : 1.0
# Date     : 01/01/2009
#
# Copyright: (c) 2009 Euro-Information. All rights reserved.
#
#==============================================================================

Files included in this example package :
CMCIC.css               : Cascaded Style Sheet file
fond.gif                : background image of the php pages
logocmcicpaiement.gif   : CMCIC P@iement logo
Phase1Aller.java        : Form example to connect to the payment page
Phase2Retour.java       : Callback example to return an acknowledgment to the bank server
CMCIC_Tpe.java          : TPE Class used in this example
CMCIC_Hmac.java         : HMAC Class used in this example
CMCIC_Config.java       : Key file. WARNING ! You have to protect this file with all the mechanism available in your development environment. 
License.txt             : Usage conditions of the previous files
readme.txt              : This current file
