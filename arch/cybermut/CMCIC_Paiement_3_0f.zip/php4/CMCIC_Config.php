<?php
/***************************************************************************************
* Warning !! CMCIC_Config contains the key, you have to protect this file with all     *   
* the mechanism available in your development environment.                             *
* You may for instance put this file in another directory and/or change its name       *
***************************************************************************************/

define ("CMCIC_CLE", "12345678901234567890123456789012345678P0");
define ("CMCIC_TPE", "0000001");
define ("CMCIC_VERSION", "3.0");
define ("CMCIC_SERVEUR", "https://paiement.creditmutuel.fr/test/");
define ("CMCIC_CODESOCIETE", "yours");
define ("CMCIC_URLOK", "http://www.google.fr");
define ("CMCIC_URLKO", "http://www.google.nz");
?>
