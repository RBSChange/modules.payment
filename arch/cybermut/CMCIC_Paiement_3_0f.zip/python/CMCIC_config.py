########################################################################################
# Warning !! CMCIC_Config contains the key, you have to protect this file with all     #   
# the mechanism available in your development environment.                             #
# You may for instance put this file in another directory and/or change its name       #
########################################################################################

CMCIC_CLE = "12345678901234567890123456789012345678P0"
CMCIC_TPE = "0000001"
CMCIC_VERSION = "3.0"
CMCIC_SERVEUR = "https://paiement.creditmutuel.fr/test/"
CMCIC_CODESOCIETE = "yours"
CMCIC_URLOK = "http://www.google.fr"
CMCIC_URLKO = "http://www.google.nz"
