#!/usr/bin/python
#-*- coding: iso8859-1 -*-

print "Content-type: text/html\n\n"

# *****************************************************************************
#
# "Open source" kit for CM-CIC P@iement (TM)
# 
# File "Phase1Aller.py":
# 
# Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
# Version  : 1.04
# Date     : 01/01/2009
# 
# Copyright: (c) 2009 Euro-Information. All rights reserved.
# License  : see attached document "License.txt".
# 
# *****************************************************************************/


import datetime
import mx.DateTime as dt

from CMCIC_Tpe import *


# ----------------------------------------------------------------------------
#  CheckOut Stub setting fictious Merchant and Order datas.
#  That's your job to set actual order fields. Here is a stub.
# -----------------------------------------------------------------------------

# Reference: unique, alphaNum (A-Z a-z 0-9), 12 characters max
sReference = "ref" + datetime.datetime.now().strftime("%H%M%S");

# Amount : format  "xxxxx.yy" (no spaces)
sMontant = "1.01"

# Currency : ISO 4217 compliant
sDevise  = "EUR"

# free texte : a bigger reference, session context for the return on the merchant website
sTexteLibre = "Texte Libre"

# transaction date : format dd/mm/yyyy:hh:mm:ss
sDate = datetime.datetime.now().strftime("%d/%m/%Y:%H:%M:%S")

# Language of the company code
sLangue   = "FR"

# Email de l'internaute
sEmail = "test@test.zz"

# ----------------------------------------------------------------------------

# between 2 and 4
#sNbrEch = "4"
sNbrEch = ""

# date echeance 1 - format dd/mm/yyyy
sDateEcheance1 = ""

# montant �ch�ance 1 - format  "xxxxx.yy" (no spaces)
#sMontantEcheance1 = "0.26" + sDevise
sMontantEcheance1 = ""

# date echeance 2 - format dd/mm/yyyy
sDateEcheance2 = ""

# montant �ch�ance 2 - format  "xxxxx.yy" (no spaces)
#sMontantEcheance2 = "0.25" + sDevise
sMontantEcheance2 = ""

# date echeance 3 - format dd/mm/yyyy
sDateEcheance3 = ""

# montant �ch�ance 3 - format  "xxxxx.yy" (no spaces)
#sMontantEcheance3 = "0.25" + sDevise
sMontantEcheance3 = ""

# date echeance 4 - format dd/mm/yyyy
sDateEcheance4 = ""

# montant �ch�ance 4 - format  "xxxxx.yy" (no spaces)
#sMontantEcheance4 = "0.25" + sDevise
sMontantEcheance4 = ""

# ----------------------------------------------------------------------------
sOptions = ""

oTpe = CMCIC_Tpe(sLangue)
oMac = CMCIC_Hmac(oTpe)

# Control String for support
sChaineDebug = "V1.04.sha1.py--[CtlHmac" + oTpe.sVersion + oTpe.sNumero + "]-" + oMac.computeHMACSHA1("CtlHmac" + oTpe.sVersion + oTpe.sNumero)

# Data to certify
sChaineMAC = oTpe.sNumero +"*"+ sDate +"*"+ sMontant + sDevise +"*"+ sReference +"*"+ sTexteLibre +"*"+ oTpe.sVersion +"*"+ sLangue +"*"+ oTpe.sCodeSociete + "*" + sEmail + "*"+ sNbrEch +"*"+ sDateEcheance1 +"*"+ sMontantEcheance1 +"*"+ sDateEcheance2 +"*"+ sMontantEcheance2 +"*"+ sDateEcheance3 +"*"+ sMontantEcheance3 +"*"+ sDateEcheance4 +"*"+ sMontantEcheance4 +"*"+ sOptions


html = '''
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" />
<meta http-equiv="cache-control" content="no-store, no-cache, must-revalidate, post-check=0, pre-check=0" />
<meta http-equiv="Expires" content="Mon, 26 Jul 1997 05:00:00 GMT" />
<meta http-equiv="pragma" content="no-cache" />
<title>Connexion au serveur de paiement</title>
<link type="text/css" rel="stylesheet" href="CMCIC.css" />
</head>

<body>
<div id="header">
        <a href="http://www.cmcicpaiement.fr"><img src="logocmcicpaiement.gif" alt="CM-CIC P@iement" title="CM-CIC P@iement" /></a>
</div>
<h1>Connexion au serveur de paiement / <span class="anglais">Connecting the payment server</span></h1>
<div id="presentation">
	<p>
	Cette page g&eacute;n&egrave;re le formulaire de paiement avec des donn&eacute;es arbitraires.<br />
	<span class="anglais">This page generates the payment form with some arbitrary data.</span>
	</p>
</div>
<div id="frm">
<p>
        Cliquez sur le bouton ci-dessous pour vous connecter au serveur de paiement.<br />
        <span class="anglais">Click on the following button to be redirected to the payment server.</span>
</p>
<!-- FORMULAIRE TYPE DE PAIEMENT / PAYMENT FORM TEMPLATE -->
<form action="''' + oTpe.sUrlPaiement + '''" method="post" id="PaymentRequest">
<p>
        <input type="hidden" name="version"         id="version"        value="''' + oTpe.sVersion + '''" />
        <input type="hidden" name="TPE"             id="TPE"            value="''' + oTpe.sNumero + '''" />
        <input type="hidden" name="date"            id="date"           value="''' + sDate + '''" />
        <input type="hidden" name="montant"         id="montant"        value="''' + sMontant + sDevise + '''" />
        <input type="hidden" name="reference"       id="reference"      value="''' + sReference + '''" />
        <input type="hidden" name="MAC"             id="MAC"            value="''' + oMac.computeHMACSHA1(sChaineMAC) + '''" />
        <input type="hidden" name="url_retour"      id="url_retour"     value="''' + oTpe.sUrlKo + '''" />
        <input type="hidden" name="url_retour_ok"   id="url_retour_ok"  value="''' + oTpe.sUrlOk + '''" />
        <input type="hidden" name="url_retour_err"  id="url_retour_err" value="''' + oTpe.sUrlKo + '''" />
        <input type="hidden" name="lgue"            id="lgue"           value="''' + sLangue + '''" />
        <input type="hidden" name="societe"         id="societe"        value="''' + oTpe.sCodeSociete + '''" />
        <input type="hidden" name="texte-libre"     id="texte-libre"    value="''' + sTexteLibre + '''" />
        <input type="hidden" name="mail"            id="mail"           value="''' + sEmail + '''" />
	<!-- Uniquement pour le Paiement fractionn&eacute; -->
	<input type="hidden" name="nbrech"          id="nbrech"        value="''' + sNbrEch + '''" />
	<input type="hidden" name="dateech1"        id="dateech1"      value="''' + sDateEcheance1 + '''" />
	<input type="hidden" name="montantech1"     id="montantech1"   value="''' + sMontantEcheance1 + '''" />
	<input type="hidden" name="dateech2"        id="dateech2"      value="''' + sDateEcheance2 + '''" />
	<input type="hidden" name="montantech2"     id="montantech2"   value="''' + sMontantEcheance2 + '''" />
	<input type="hidden" name="dateech3"	    id="dateech3"      value="''' + sDateEcheance3 + '''" />
	<input type="hidden" name="montantech3"     id="montantech3"   value="''' + sMontantEcheance3 + '''" />
	<input type="hidden" name="dateech4"	    id="dateech4"      value="''' + sDateEcheance4 + '''" />
	<input type="hidden" name="montantech4"     id="montantech4"   value="''' + sMontantEcheance4 + '''" />
	<!-- -->
        <input type="submit" name="bouton"          id="bouton"         value="Connexion / Connection" />
</p>
</form>
<!-- FIN FORMULAIRE TYPE DE PAIEMENT / END PAYMENT FORM TEMPLATE -->
</div>
<div id="source">
	<h2>Uniquement pour le d&eacute;bogage / <span class="anglais">For debug purpose only</span></h2>
        <p>
	Code source du formulaire.  <br />
	<span class="anglais">Form source code.</span>
       </p>
<pre>
&lt;form <span class="name">action</span>="<span class="value">''' + oTpe.sUrlPaiement + '''"</span> method="post" id="PaymentRequest"&gt;
&lt;input type="hidden" name="<span class="name">version</span>"          value="<span class="value">''' + oTpe.sVersion + '''</span>" /&gt;
&lt;input type="hidden" name="<span class="name">TPE</span>"              value="<span class="value">''' + oTpe.sNumero + '''</span>" /&gt;
&lt;input type="hidden" name="<span class="name">date</span>"             value="<span class="value">''' + sDate + '''</span>" /&gt;
&lt;input type="hidden" name="<span class="name">montant</span>"          value="<span class="value">''' + sMontant + sDevise + '''</span>" /&gt;
&lt;input type="hidden" name="<span class="name">reference</span>"        value="<span class="value">''' + sReference + '''</span>" /&gt;
&lt;input type="hidden" name="<span class="name">MAC</span>"              value="<span class="value">''' + oMac.computeHMACSHA1(sChaineMAC) + '''</span>" /&gt;
&lt;input type="hidden" name="<span class="name">url_retour</span>"       value="<span class="value">''' + oTpe.sUrlKo + '''</span>" /&gt;
&lt;input type="hidden" name="<span class="name">url_retour_ok</span>"    value="<span class="value">''' + oTpe.sUrlOk + '''</span>" /&gt;
&lt;input type="hidden" name="<span class="name">url_retour_err</span>"   value="<span class="value">''' + oTpe.sUrlKo + '''</span>" /&gt;
&lt;input type="hidden" name="<span class="name">lgue</span>"             value="<span class="value">''' + sLangue + '''</span>" /&gt;
&lt;input type="hidden" name="<span class="name">societe</span>"          value="<span class="value">''' + oTpe.sCodeSociete + '''</span>" /&gt;
&lt;input type="hidden" name="<span class="name">texte-libre</span>"      value="<span class="value">''' + sTexteLibre + '''</span>" /&gt;
&lt;input type="hidden" name="<span class="name">mail</span>"             value="<span class="value">''' + sEmail + '''</span>" /&gt;
&lt;!-- Uniquement pour le Paiement fractionn&eacute; --&gt;
&lt;input type="hidden" name="<span class="name">nbrech</span>"           value="<span class="value">''' + sNbrEch + '''</span>" /&gt;
&lt;input type="hidden" name="<span class="name">dateech1</span>"         value="<span class="value">''' + sDateEcheance1 + '''</span>" /&gt;
&lt;input type="hidden" name="<span class="name">montantech1</span>"      value="<span class="value">''' + sMontantEcheance1 + '''</span>" /&gt;
&lt;input type="hidden" name="<span class="name">dateech2</span>"         value="<span class="value">''' + sDateEcheance2 + '''</span>" /&gt;
&lt;input type="hidden" name="<span class="name">montantech2</span>"      value="<span class="value">''' + sMontantEcheance2 + '''</span>" /&gt;
&lt;input type="hidden" name="<span class="name">dateech3</span>"         value="<span class="value">''' + sDateEcheance3 + '''</span>" /&gt;
&lt;input type="hidden" name="<span class="name">montantech3</span>"      value="<span class="value">''' + sMontantEcheance3 + '''</span>" /&gt;
&lt;input type="hidden" name="<span class="name">dateech4</span>"         value="<span class="value">''' + sDateEcheance4 + '''</span>" /&gt;
&lt;input type="hidden" name="<span class="name">montantech4</span>"      value="<span class="value">''' + sMontantEcheance4 + '''</span>" /&gt;
&lt;!-- --&gt;
&lt;input type="submit" name="<span class="name">bouton</span>"           value="<span class="value">Connexion / Connection</span>" /&gt;
&lt;/form&gt;
</pre>
</div>
<div>
	<p>
	Cha&icirc;ne de contr&ocirc;le &agrave; fournir au support en cas de probl&egrave;mes <br />
	<span class="anglais">Control string needed by support in case of problems</span>
	</p>
        <pre>''' + sChaineDebug + '''</pre>
        <p>
        Cha&icirc;ne utilis&eacute;e pour le calcul du sceau HMAC <br />
        Num&eacute;ro de TPE*date*montant*r&eacute;f&eacute;rence*texte libre*version*code langue*code soci&eacute;t&eacute;*email*nombre ech&eacute;ance*date &eacute;ch&eacute;ance1*montant &eacute;ch&eacute;ance1*date &eacute;ch&eacute;ance2*montant &eacute;ch&eacute;ance2*date &eacute;ch&eacute;ance3*montant &eacute;ch&eacute;ance3*date &eacute;ch&eacute;ance4*montant &eacute;ch&eacute;ance4*options<br />
        <span class="anglais">String used to generate the HMAC<br />
        TPE number*date*amount*reference*free text*version*language code*company code*e-mail*nombre ech�ance*date �ch�ance1*montant �ch�ance1*date �ch�ance2*montant �ch�ance2*date �ch�ance3*montant �ch�ance3*date �ch�ance4*montant �ch�ance4*options</span>
        </p>
        <pre>''' + sChaineMAC + '''</pre>
</div>
<div id="footer">
        <p>
        Cette page est fournie comme un exemple d'impl&eacute;mentation de la solution de paiement CyberMUT.<br />
        Elle n'a pas pour but de r&eacute;pondre &agrave; toutes les configurations existantes. &copy; 2009 Euro Informations.<br />
        <span class="anglais">This page is just an example of the use of CyberMUT payment solution.<br />
        Its main purpose is not to give an answer to every existing configurations. &copy; 2009 Euro Informations</span>
        </p>
</div>
</body>
</html>
'''

print html
