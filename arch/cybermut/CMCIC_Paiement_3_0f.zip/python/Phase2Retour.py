#!/usr/bin/python
# -*- coding: iso8859-1 -*-

# *****************************************************************************
#
# "Open source" kit for CM-CIC P@iement (TM)
# 
# File "Phase2Retour.py":
# 
# Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
# Version  : 1.04
# Date     : 01/01/2009
# 
# Copyright: (c) 2009 Euro-Information. All rights reserved.
# License  : see attached document "License.txt".
# 
# *****************************************************************************/
 
import cgi
from CMCIC_Tpe import *

params = cgi.FieldStorage()

oTpe = CMCIC_Tpe()
oHmac = CMCIC_Hmac(oTpe)

Certification = {'MAC' : "", 'date' : "", 'montant' : "", 'reference' : "", 'texte-libre' : "", 'code-retour' : "", 'cvx' : "", 'vld' : "", 'brand' : "", 'status3ds' : "", 'numauto' : "", 'motifrefus' : "", 'originecb' : "", 'bincb' : "", 'hpancb' : "", 'ipclient' : "", 'originetr' : "", 'veres' : "", 'pares' : "", 'montantech' : ""}

for key in Certification.keys():
        if params.has_key(key):
                Certification[key] = params[key].value

sChaineMAC = oTpe.sNumero + "*" + Certification["date"] + "*" + Certification['montant'] + "*" + Certification['reference'] + "*" + Certification['texte-libre'] + "*" + oTpe.sVersion + "*" + Certification['code-retour'] + "*" + Certification['cvx'] + "*" + Certification['vld'] + "*" + Certification['brand'] + "*" + Certification['status3ds'] + "*" + Certification['numauto'] + "*" + Certification['motifrefus'] + "*" + Certification['originecb'] + "*" + Certification['bincb'] + "*" + Certification['hpancb'] + "*" + Certification['ipclient'] + "*" + Certification['originetr'] + "*" + Certification['veres'] + "*" + Certification['pares'] + "*";

if oHmac.bIsValidHmac(sChaineMAC, Certification['MAC']):
        if Certification['code-retour'] == "Annulation":
                # Payment has been refused
		# The payment may be accepted later
                # put your code here (email sending / Database update)
                pass

        elif Certification['code-retour'] == "payetest":
                # Payment has been accepeted on the test server
                # put your code here (email sending / Database update)
                pass 

        elif Certification['code-retour'] == "paiement":
                # Payment has been accepeted on the productive server
                # put your code here (email sending / Database update)
                pass 


	#*** ONLY FOR MULTIPART PAYMENT ***#
	elif Certification['code-retour'] == "paiement_pf2" or Certification['code-retour'] == "paiement_pf3" or Certification['code-retour'] == "paiement_pf4":
		# Payment has been accepted on the productive server for the part #N
		# return code is like paiement_pf[#N]
		# put your code here (email sending / Database update)
		# You have the amount of the payment part in Certification['montantech']
		pass

	elif Certification['code-retour'] == "Annulation_pf2" or Certification['code-retour'] == "Annulation_pf3" or Certification['code-retour'] == "Annulation_pf4":
		# Payment has been refused on the productive server for the part #N
		# return code is like Annulation_pf[#N]
		# put your code here (email sending / Database update)
		# You have the amount of the payment part in Certification['montantech']
		pass

        sResult = "0"
else : 
        # your code if the HMAC doesn't match
        sResult = "1\n" + sChaineMAC

#-----------------------------------------------------------------------------
# Send receipt to CMCIC server
#-----------------------------------------------------------------------------
print "Pragma: no-cache\nContent-type: text/plain\n\nversion=2\ncdr=" + sResult
