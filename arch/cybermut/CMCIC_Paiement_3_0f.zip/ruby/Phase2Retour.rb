#!/usr/bin/ruby

#puts "Content-type: text/plain\n\n"

# *****************************************************************************
#
# "Open source" kit for CM-CIC P@iement (TM)
# 
# File "Phase2Retour.rb":
# 
# Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
# Version  : 1.04
# Date     : 01/01/2009
# 
# Copyright: (c) 2009 Euro-Information. All rights reserved.
# License  : see attached document "License.txt".
# 
# *****************************************************************************
 
require 'cgi'

# TPE Settings
# Warning !! CMCIC_Config contains the key, you have to protect this file with all the mechanism available in your development environment.
# You may for instance put this file in another directory and/or change its name. If so, don't forget to adapt the include path below.
require 'CMCIC_Config'

require 'CMCIC_Tpe'

params = CGI.new

oTpe = CMCIC_Tpe.new()
oHmac = CMCIC_Hmac.new(oTpe)

sChaineMAC = [oTpe.sNumero, params["date"], params['montant'], params['reference'], params['texte-libre'], oTpe.sVersion, params['code-retour'], params['cvx'], params['vld'], params['brand'], params['status3ds'], params['numauto'], params['motifrefus'], params['originecb'], params['bincb'], params['hpancb'], params['ipclient'], params['originetr'], params['veres'], params['pares']].join('*') + "*";

if oHmac.isValidHmac?(sChaineMAC, params['MAC'])
	case params['code-retour']
		when "Annulation" :
			# Payment has been refused
			# put your code here (email sending / Database update)
			# Attention : an autorization may still be delivered for this payment

		when "payetest":
			# Payment has been accepted on the test server
			# put your code here (email sending / Database update)

		when "paiement":
			# Payment has been accepted on the productive server
			# put your code here (email sending / Database update)

		#*** ONLY FOR MULTIPART PAYMENT ***#
		when "paiement_pf2":
		when "paiement_pf3":
		when "paiement_pf4":
			# Payment has been accepted on the productive server for the part #N
			# return code is like paiement_pf[#N]
			# put your code here (email sending / Database update)
			# You have the amount of the payment part in params['montantech']
			break;

		when "Annulation_pf2":
		when "Annulation_pf3":
		when "Annulation_pf4":
			# Payment has been refused on the productive server for the part #N
			# return code is like Annulation_pf[#N]
			# put your code here (email sending / Database update)
			# You have the amount of the payment part in params['montantech']
			break;

	end
	sResult = "0"
else
	# your code if the HMAC doesn't match
	sResult = "1\n" + sChaineMAC
end

#-----------------------------------------------------------------------------
# Send receipt to CMCIC server
#-----------------------------------------------------------------------------
puts "Pragma: no-cache\nContent-type: text/plain\n\nversion=2\ncdr=" + sResult

