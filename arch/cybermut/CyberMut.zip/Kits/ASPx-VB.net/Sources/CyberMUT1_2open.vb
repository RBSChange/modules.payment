'==============================================================================
'
' CM_CIC_Paiement: "open source" kit for CyberMUT-P@iement(TM) and
'                  P@iementCIC(TM).
' Integration sample in a merchant site for ASPX/VB.Net.
'
' Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
' Version  : 1.03
' Date     : 18/12/2003
'
' Copyright: (c) 2003 Euro-Information. All rights reserved.
'
'==============================================================================

' Redistribution and use in source and binary forms, with or without
' modification, are permitted provided that the following conditions are
' met:
'  - Redistributions of source code must retain the above copyright
'    notice and the following disclaimer.
'  - Redistributions in binary form must reproduce the above copyright
'    notice and the following disclaimer in the documentation and/or
'    other materials provided with the distribution.
'  - Neither the name of Euro-Information nor the names of its
'    contributors may be used to endorse or promote products derived
'    from this software without specific prior written permission.
'
' THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
' "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
' LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
' A PARTICULAR PURPOSE ARE DISCLAIMED.
' IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR
' ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
' DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
' GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
' INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
' IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
' OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN If
' ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

' Note      : Euro-Information does not provide person-to-person technical
'             support for tryout of CM_CIC_Paiement kits. We do however
'             welcome your feedback which can be sent to <centrecom@e-i.com>.
'
'==============================================================================

Imports System
Imports System.data
Imports System.Security.Cryptography
Imports Microsoft.VisualBasic

Namespace CyberMUT

'==============================================================================

Public NotInheritable Class myTpeHmac
    Inherits CyberMUT1_2openVB

    Public Sub New(Byval TPE as String, Byval How2Get1stKey as String)
        me.Tpe     =  TPE
        me.TpeUrl  = "https://payment.somebank.net/paymentdir/paiement.cgi"
        me.TpeHmac = _1stPartOfKey(How2Get1stKey) ' // first part of the Merchant key
    end Sub

    Public ReadOnly Property TpeNum() as String
        Get
            Return me.Tpe
        end Get
    end Property

    Public Property bankUrl as String
        Get
            Return me.TpeUrl
        end Get
        Set(Byval bankServer as String)
            me.TpeUrl  = "https://" & bankServer & "paiement.cgi"
        end Set
    end Property

    Public Function finalizeKey(Byval finalPart as String) as Boolean
        me.TpeHmac = finalPart      ' // second part of Key
        Return me.TpeXor            ' // final key is Xor of both
    end Function

    Public ReadOnly Property CtlHmac() as String
        Get
            Return me.TpeHmac
        end Get
    end Property

    Private Function _1stPartOfKey(Byval How2Get1stKey as String) as String
        ' ---------------------------------------------------------------------
        '* Retrieves the first part of the key, field "PassPhrase" from the
        '* extract2HmacSha1 UI
        '* Ram�ne la 1�re partie de la Cl�, champ "Phrase Cle" de
        '* extract2HmacSha1

        '* A personnaliser avec vos outils d'administration de cl�s.
        '* CentreCom vous fournira une cl� commer�ant (secret partag�, associ�
        '* � une m�thode de hachage).  Il vous appartiendra de la prot�ger
        '* selon vos r�gles et outils de s�curit�.
        '* Gardez � l'esprit qu'une cl� secr�te doit �tre secr�te !
        '* ------
        '* To be personnalized with your KeyStore administration Tools.
        '* CentreCom will provide you a merchant key (shared secret,
        '* associated with hash method).  You have to store and retrieve its
        '* value according to your security rules and tools.
        '* Keep in mind that a SecretKey must be Secret !
        '*  -----
            ' for instance :
            ' Return a key value from your Key management Tool
            ' Return a Registry value related to the internal Key
            ' Return an environment variable
            ' Return a DB/SQL field
            ' Return part of file content with internal Key value
            ' ...........
        ' ---------------------------------------------------------------------

        '===========================================================================================
        ' PassPhrase optional custom Area  --  Zone de personnalisation optionnelle de la PhraseCle

        Return How2Get1stKey                        ' <<<--- Return YourWay2Get(How2Get1stKey)

        ' End of PassPhrase optional custom Area -- Fin de personnalisation optionnelle de PhraseCle
        '============================================================================================
    end Function

end Class

'==============================================================================
' Beyond there is nothing to change. Rien n'est � changer au-del�
'==============================================================================

Public Class CyberMUT1_2openVB

    Public ReadOnly TpeVersion as String = "1.2open"

    ' -------------------------------------------------------------------------
    ' function encodeStr2HTML
    '
    ' IN:  Cha�ne � encoder / String to encode
    ' OUT: Cha�ne encod�e / Encoded string
    '
    ' Description: Encode special characters to HTML format
    '              Encodage des caract�res sp�ciaux au format HTML
    ' -------------------------------------------------------------------------
    Private Function encodeStr2HTML(Source as String) as String
        Dim i as integer = 0
        Dim encoded as String = ""
        Dim RESERVED_CHARS as String = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890._-"

        Dim SourceA as Char() = source.ToCharArray()

        For i = 0 To SourceA.Length - 1
            If Strings.Asc(SourceA(i))<=127 Then
                If RESERVED_CHARS.IndexOf(SourceA(i))<>-1 Then
                    encoded = encoded & SourceA(i)
                Else
                    encoded = encoded & "&#x" & Conversion.Hex(Strings.Asc(SourceA(i))) & ";"
                end If
            Else
                encoded = encoded & SourceA(i)
            end If
        Next

        Return encoded
    end Function

    ' -------------------------------------------------------------------------
    ' function CreerFormulaireHmac
    '
    ' Description : Formatting payment form
    '               Cr�er le formulaire de paiement
    ' -------------------------------------------------------------------------
    Public Function CreerFormulaireHmac( _
        Byval NomFormulaire  as String, _
        Byval Montant        as String, _
        Byval Reference      as String, _
        Byval TexteLibre     as String, _
        Byval UrlRetourOk    as String, _
        Byval UrlRetourNok   as String, _
        Byval ContexteRetour as String, _
        Byval Langue         as String, _
        Byval Societe        as String, _
        Byval TexteBouton    as String ) as String

        Dim dtPaiement  as String = datePaiement()
        Dim MacChamps   as String =   me._tpe       & "*" _
                                    & dtPaiement    & "*" _
                                    & Montant       & "*" _
                                    & Reference     & "*" _
                                    & TexteLibre    & "*" _
                                    & me.tpeVersion & "*" _
                                    & Langue        & "*" _
                                    & Societe       & "*"
        Dim champMAC    as String = calculerMAC(MacChamps)

        Dim myInputType as String = """>" & Microsoft.VisualBasic.ControlChars.CrLf & "<INPUT TYPE="""

        Dim formulaire  as String = "<FORM METHOD=""post"" target=""_top"" NAME=""" _
            & encodeStr2HTML(NomFormulaire.toString()) & """ ACTION=""" & encodeStr2HTML(me._TpeUrl) _
            & myInputType & "hidden"" NAME=""version""        VALUE=""" & encodeStr2HTML(me.tpeVersion) _
            & myInputType & "hidden"" NAME=""TPE""            VALUE=""" & encodeStr2HTML(me._Tpe) _
            & myInputType & "hidden"" NAME=""date""           VALUE=""" & encodeStr2HTML(dtPaiement) _
            & myInputType & "hidden"" NAME=""montant""        VALUE=""" & encodeStr2HTML(Montant) _
            & myInputType & "hidden"" NAME=""reference""      VALUE=""" & encodeStr2HTML(Reference) _
            & myInputType & "hidden"" NAME=""MAC""            VALUE=""" & encodeStr2HTML(champMAC) _
            & myInputType & "hidden"" NAME=""url_retour""     VALUE=""" & encodeStr2HTML(UrlRetourNok & ContexteRetour) _
            & myInputType & "hidden"" NAME=""url_retour_ok""  VALUE=""" & encodeStr2HTML(UrlRetourOk & ContexteRetour) _
            & myInputType & "hidden"" NAME=""url_retour_err"" VALUE=""" & encodeStr2HTML(UrlRetourNok & ContexteRetour) _
            & myInputType & "hidden"" NAME=""lgue""           VALUE=""" & encodeStr2HTML(Langue) _
            & myInputType & "hidden"" NAME=""societe""        VALUE=""" & encodeStr2HTML(Societe) _
            & myInputType & "hidden"" NAME=""texte-libre""    VALUE=""" & encodeStr2HTML(TexteLibre) _
            & myInputType & "submit"" NAME=""bouton""         VALUE=""" & encodeStr2HTML(TexteBouton) & """></FORM>"
        Return formulaire
    end Function

    ' -------------------------------------------------------------------------
    ' function TesterHmac
    '
    ' Description : Testing confirmation MAC
    '               V�rifier le MAC de la confirmation
    ' -------------------------------------------------------------------------
    Public Function TesterHmac( _
        Byval MAC              as String, _
        Byval DateConfirmation as String, _
        Byval Montant          as String, _
        Byval Reference        as String, _
        Byval TexteLibre       as String, _
        Byval CodeRetour       as String, _
        Byval retourPLUS       as String) as String

        Dim MacChamps as String =   retourPLUS             _
                                  & me._tpe          & "+" _
                                  & DateConfirmation & "+" _
                                  & Montant          & "+" _
                                  & Reference        & "+" _
                                  & TexteLibre       & "+" _
                                  & me.tpeVersion    & "+" _
                                  & CodeRetour       & "+"
        If (MAC.ToLower().equals(calculerMAC(MacChamps))) Then
            Return "1"
        Else
            Return ("0-" & MacChamps)
        end If
    end Function

    ' -------------------------------------------------------------------------
    ' function CreerAccuseReception
    '
    ' Description : Formatting a receipt/response to the confirmation message
    '               sent by bank server.
    '               Cr�er un accus� de r�ception en r�ponse au message de
    '               confirmation �mis par la banque.
    ' -------------------------------------------------------------------------
    Public Function CreerAccuseReception( _
        Byval MacOk as String) as String

        Dim Reponse = " Version:1 "
        If (MacOk.equals("1")) Then
            Reponse &= ("OK ")
        Else
            Reponse &=("Document falsifie ")
        end If
        Reponse &= datePaiement()
        Return Reponse.toString()
    end Function

    Public Function isMsgAuth(Byval MacOk as String) as Boolean
        Return MacOk.startsWith("1")
    end Function

    Public Function isPayment(Byval CodeRetour as String) as Boolean
        Return CodeRetour.Equals("paiement")
    end Function

    Public Function isTestPayment(Byval CodeRetour as String) as Boolean
        Return CodeRetour.Equals("payetest")
    end Function

    ' -------------------------------------------------------------------------
    ' function calculerMAC
    '
    ' Description : Computing Hmac for CyberMUT-P@iement(TM) compliant payment
    '               messages
    ' -------------------------------------------------------------------------
    Public Function calculerMAC(Byval MacChamps as String) as String
        If me._KeyOk Then
            me._TpeHmac.Initialize()
            Dim champs as Byte() = System.Text.Encoding.ASCII.GetBytes(MacChamps)
            Dim result as Byte() = me._TpeHmac.ComputeHash(champs)
            Return(byteArrayToHexString(result))
        Else
            Return ("Pas de Cle - No Key")
        end If
    end Function

    Public Readonly Property TpeOk() as Boolean
        Get
            Return me._KeyOk
        end Get
    end Property

    Public Readonly Property TpeXor() as Boolean
        Get
            Return me._KeyXor
        end Get
    end Property

    ' -----------------------------------------------------------------
    ' - Protected
    ' -----------------------------------------------------------------

    Protected Property TpeHmac() as String
        Get
            Dim LibV as String = "CyberMUT4VB.Net - " & datePaiement() & " - V1.03 - " _
                & "isKeyXor = " & me._KeyXor.toString & " - <br> " _
                & "CtlHmac-" & me.TpeVersion & "-[" & me._Tpe & "] = 0x"
            Dim MAC  as String = ""
            MAC = calculerMAC("CtlHmac" & me.TpeVersion & me._Tpe) '// CyberMUT test deck
            Return (LibV & MAC & " --;")
        end Get

        Set (ByVal Cle As String)
            Dim i as integer = 0

            me._KeyXor = False
            If Cle.StartsWith("0x") then
                Dim bCleX as Byte() = me.hexStringToByteArray(Cle)
                If me._KeyOk   = False Then
                    me._TpeHmac = new HMACSHA1(bCleX)
                Else
                    If me._TpeHmac.Key.length = bCleX.length then 'xor bCleX
                        For i = 0 To bCleX.Length - 1
                            bCleX(i) = bCleX(i) Xor me._TpeHmac.Key(i)
                        Next i
                        me._KeyXor = True
                    end If
                    me._TpeHmac.Key = bclex
                end If
            Else
                Dim hash  as HashAlgorithm = new SHA1Managed()
                Dim bCleC as Byte() = hash.ComputeHash(System.Text.Encoding.ASCII.GetBytes(Cle))

                If me._KeyOk   = False Then
                    me._TpeHmac = new HMACSHA1(bCleC)
                Else
                    If me._TpeHmac.Key.length = bCleC.length then 'xor bCleC
                        For i = 0 To bCleC.Length - 1
                            bCleC(i) = bCleC(i) Xor me._TpeHmac.Key(i)
                        Next i
                        me._KeyXor = True
                    end If
                    me._TpeHmac.Key = bcleC
                end If
            end If

            me._KeyOk = True
        end Set
    end Property

    Protected Property Tpe() as String
        Get
            Return me._Tpe
        end Get
        Set (ByVal TPE As String)
            me._Tpe = TPE
        end Set
    end Property

    Protected Property TpeUrl() as String
        Get
            Return me._TpeUrl
        end Get
        Set (ByVal Url As String)
            me._TpeUrl = Url
        end Set
    end Property

    Protected Sub New()
        me._Tpe = "Pas de Tpe"
    end Sub

    ' -----------------------------------------------------------------
    ' - Privates
    ' -----------------------------------------------------------------

    Private Function datePaiement() as String
        Dim dt as DateTime = DateTime.Now
        Dim dtP as String = dt.ToString("dd/MM/yyyy:HH:mm:ss")
        Return dtP
    end Function

    Private Function byteArrayToHexString(ByVal ba() as [Byte])
        Dim i as Integer
        Dim s as String = ""
        For i = 0 To ba.Length - 1
            s = s & ba(i).toString("x2")
        Next i
        Return s
    end Function

    Private Function hexStringToByteArray(ByVal hs as String)
        Dim xs as String = ""
        If hs.startsWith("0x") Then
            xs &= hs.Substring(2,hs.length-2)
        Else
            xs &= hs
        end If
        Dim bal as Integer = xs.Length/2
        If xs.Length <> 2*bal then
            xs = "0" & xs
        end If
        Dim ba((xs.Length/2)-1) as Byte
        Dim i as Integer
        For i = 0 To ba.Length - 1
            ba(i) = System.convert.ToByte(xs.Substring(2*i,2),16)
        Next i
        Return CType(ba.Clone(), Byte())
    end Function

    Private _Tpe     as String
    Private _TpeUrl  as String
    Private _KeyOk   as Boolean = False
    Private _KeyXor  as Boolean = False
    Private _TpeHmac as HMACSHA1

end Class

end Namespace
