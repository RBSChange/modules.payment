CyberMUT Paiement(TM) - Paiement CIC(TM).
Integration sample in a merchant site. Version 1.03
Copyright (c) Euro-Information 2003 (centrecom@e-i.com).  All rights reserved.

After compilation (vbc), please transfer generated ".netmodule" and
".dll" from "Sources\bin" onto your Web server, within your
application "bin" directory.
