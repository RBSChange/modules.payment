'==============================================================================
'
' CM_CIC_Paiement: "open source" kit for CyberMUT-P@iement(TM) and
'                  P@iementCIC(TM).
' Integration sample in a merchant site for ASPX/VB.Net.
'
' Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
' Version  : 1.03
' Date     : 18/12/2003
'
' Copyright: (c) 2003 Euro-Information. All rights reserved.
'
'==============================================================================

' Redistribution and use in source and binary forms, with or without
' modification, are permitted provided that the following conditions are
' met:
'  - Redistributions of source code must retain the above copyright
'    notice and the following disclaimer.
'  - Redistributions in binary form must reproduce the above copyright
'    notice and the following disclaimer in the documentation and/or
'    other materials provided with the distribution.
'  - Neither the name of Euro-Information nor the names of its
'    contributors may be used to endorse or promote products derived
'    from this software without specific prior written permission.
'
' THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
' "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
' LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
' A PARTICULAR PURPOSE ARE DISCLAIMED.
' IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE FOR
' ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
' DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
' GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
' INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
' IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
' OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN If
' ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

' Note: Euro-Information does not provide person-to-person technical support
'       for tryout of CM_CIC_Paiement kits. We do however welcome your
'       feedback which can be sent to <centrecom@e-i.com>.
'
'==============================================================================

'******************************************************************************
'* This sample shows how to build RFC2104 compliant messages with
'* .Net System.Security.Cryptography in order to prepare
'* CyberMUT P@iement / P@iementCIC authenticated forms.
'* Please refer to your Security Officers to implement appropriate
'* administration for shared SecretKey, using as well as possible your
'* technical resources.
'*
'* Cet exemple montre comment cr�er des messages RFC2104 avec
'* .Net System.Security.Cryptography dans le but de produire des formulaires
'* authentifi�s CyberMUT-P@iement(TM) / PaiementCIC (TM).
'* Reportez-vous � vos responsables S�curit� Informatique pour administrer
'* de fa�on appropri�e des cl�s secr�tes partag�es au mieux de vos ressources
'* techniques.
'******************************************************************************

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.data

Imports CyberMUT

Namespace myCyberMUT

'==============================================================================

Public Class myPaymentPage

'==============================================================================
' Begin Page Custom area - D�but de la zone de personnalisation Page <<<---
'==============================================================================

    Inherits Page                                        ' <<<--- Inherits yourPage

    Protected myTpe as myTpeHmac = _
        new myTpeHmac("1234567", "YouGotThisPassPhrase") ' <<<--- Tpe, PassPhrase
                     '"7654321", "ThePassPhraseContent"
                     '"TPE_NUM", yourWay2GetTheContent()

'==============================================================================
' End of base custom area -- Fin de la zone de personnalisation de base
'= = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
' Begin optional Page Custom Area -- D�but de la zone optionnelle de personnalisation de page
'==============================================================================


    Private Function _2ndHexKey(Byval IPSP as String) as String

        Dim app2ndHexKey as String = me._Internal2ndHexKey & _
                            Application(IPSP & "_" & myTpe.TpeNum & "_2ndHexKey")

        ' seconde partie de cl� : 40 chiffres hexad�cimaux pr�fix�s par "0x"
        ' second part of key: 40 hex digits prefixed by "0x"

        If app2ndHexKey.startsWith("0x") Then
            Return app2ndHexKey.PadRight(42,"0").Substring(0,42)
        Else
            Return "0x" & app2ndHexKey.PadRight(40,"0").Substring(0,40)
        end If


        ' <<-- Optional Custom : Return yourWay2GetThe2ndKey(...)

        ' ---------------------------------------------------------------------
        '* Retrieves the second part of the key, field "2nd Part(hexa)" from
        '* the extract2HmacSha1 UI.
        '* Ram�ne la  seconde partie de la cl�, champ "2nde partie (hexa)" de
        '* extract2HmacSha1.
        '* ------
        '* To be customized with your KeyStore administration Tools.
        '* CentreCom will provide you a merchant key (shared secret,
        '* associated with hash method).  You have to store and retrieve its
        '* value according to your security rules and tools.
        '* Keep in mind that a SecretKey must be Secret !
        '* ------
        '* A personnaliser avec vos outils d'administration de cl�s.
        '* CentreCom vous fournira une cl� commer�ant (secret partag�, associ�
        '* � une m�thode de hachage).  Il vous appartiendra de la prot�ger
        '* selon vos r�gles et outils de s�curit�.
        '* Gardez � l'esprit qu'une cl� secr�te doit �tre secr�te !
        '*  -----
                ' for instance :
                ' Return a key value from your Key management Tool
                ' Return a Registry value related to the internal Key
                ' Return an environment variable
                ' Return a DB/SQL field
                ' Return part of file content with internal Key value
                ' ...........

        '* --->>> Si vous d�cidez de stocker la seconde partie de votre cl�
        '*        dans votre global.asax
        '* --->>> If you want to store the second part of your key in your
        '*        global.asax

        '     Dim app2ndHexKey as String = "" & _
        '                         Application(IPSP & "_" & myTpe.TpeNum & "_2ndHexKey")
        ' ---------------------------------------------------------------------

    end Function

'==============================================================================
' End of optional Page custom Area - Fin de la zone optionnelle de personnalisation de page
'==============================================================================

    Protected Property myFinalTpe() as String
        Get
            Return myTpe.CtlHmac()
        end Get
        Set (Byval IPSP as String)
            myTpe.bankUrl = Application(IPSP & "_Server") & Application(IPSP & "_Dir")
            If myTpe.TpeXor = false then    ' // is TPE fully initialized ?
                Dim bXor as boolean = myTpe.finalizeKey(_2ndHexKey(IPSP))
            end If
        end Set
    end Property

    Public ReadOnly Property MacOK as String
        Get
            Return me._MacOk
        end Get
    end Property

    Public ReadOnly Property MsgAuth as Boolean
        Get
            Return myTpe.isMsgAuth(me._MacOk)
        end Get
    end Property

    Public ReadOnly Property CodeRetour as String
        Get
            Return me._CodeRetour
        end Get
    end Property

    Public ReadOnly Property Payment as Boolean
        Get
            Return myTpe.isPayment(me._CodeRetour)
        end Get
    end Property

    Public ReadOnly Property TestPayment as Boolean
        Get
            Return myTpe.isTestPayment(me._CodeRetour)
        end Get
    end Property

    Protected WriteOnly Property Internal2ndHexKey as String
        Set (Byval KeyPart as String)
            _Internal2ndHexKey=KeyPart
        end Set
    end Property

    Protected _Reponse    as String
    Protected _MacOk      as String
    Protected _CodeRetour as String

    Private _Internal2ndHexKey as String = ""

End Class

End Namespace
