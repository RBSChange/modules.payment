/*****************************************************************************
 *
 * CM_CIC_Paiement: kit "open source" pour CyberMUT-P@iement(TM) et
 *                  P@iementCIC(TM).
 * Exemple d'int�gration dans un site marchand en langage C/C++.
 *
 * Fichier "cgi1_commercant.c" : exemple de programme CGI � cr�er pour la
 *            phase "aller" du paiement (CGI1).
 *
 * Auteur   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.0
 * Date     : 18/12/2003
 *
 * Copyright: (c) 2003 Euro-Information. Tous droits r�serv�s.
 * Consulter le document de licence "Licence.txt" joint.
 *
 *****************************************************************************/

/*---------------------------------------------------------------------------*
 * Exemple de programme CGI � cr�er pour la phase "aller" du paiement (CGI1)
 *---------------------------------------------------------------------------*
 *
 * Ce programme g�n�re un formulaire HTML dans lequel sont plac�es (en champs
 * cach�s) les informations de la commande (montant, r�f�rence, URL de retour
 * etc.).
 *
 *---------------------------------------------------------------------------*
 * Explications :
 *---------------------------------------------------------------------------*
 *
 * Pour le client d�sirant payer, la seule partie visible de ce formulaire est
 * le bouton "Paiement par carte bancaire".
 *
 * Ce bouton "Paiement par carte bancaire" agit comme charni�re entre la phase
 * de commande, qui a lieu sur le serveur du commer�ant, et la phase de
 * paiement, qui a lieu sur le serveur de paiement s�curis� de la banque.
 *
 * Lorsqu'il clique sur le bouton "Paiement par carte bancaire", le client est
 * redirig� sur le serveur s�curis� de la banque.
 *
 *---------------------------------------------------------------------------*
 *
 * Ce programme d'exemple vous indique la d�marche � suivre pour utiliser
 * la fonction "CreerFormulaireHmac()".
 *
 * La fonction de hachage "HMAC()" utilis�e dans cet exemple est impl�ment�e
 * dans la biblioth�que "openssl" (http://www.openssl.org/).
 *
 * Vous pouvez aussi utiliser une autre fonction de hachage qui respecte la
 * RFC 2104.
 *
 *---------------------------------------------------------------------------*
 *
 * Le CGI1 doit r�aliser quatre traitements principaux :
 *
 * 1/ Extraire du contexte d'ex�cution les informations permettant de
 *    rechercher les informations relatives � la commande.
 *    Dans de cet exemple de test, le montant a une valeur fixe.
 *
 *    Notez que pour des raisons imp�ratives de s�curit�
 *    (falsification possible), le montant (et a fortiori la cl� de hachage)
 *    ne doit pas �tre transmis au CGI par l'interm�diaire de la Query String.
 *
 *    A ce stade, la commande du client doit exister dans une base de donn�es
 *    permanente du site commer�ant. Cette base de donn�es fournit les donn�es
 *    n�cessaires au calcul du montant et permet de retracer l'historique du
 *    paiement depuis le d�but de la phase de paiement (avant le CGI1)
 *    jusqu'au d�nouement (apr�s le CGI2).
 *
 * 2/ G�n�rer le formulaire HTML du bouton de paiement en appelant la fonction
 *    "CreerFormulaireHmac()".
 *
 *    Sur la base des informations relatives au contexte de la commande et au
 *    TPE, la fonction "CreerFormulaireHmac()" g�n�re alors le source du
 *    formulaire HTML permettant d'initier la demande de paiement.
 *
 *    La fonction "CreerFormulaireHmac()" appelle la fonction "ComputeHmac()"
 *    afin de renseigner le champ MAC dans le formulaire de demande de
 *    paiement.
 *
 *    Le champ MAC est calcul� � partir de la cl� et de la m�thode de hachage
 *    qui sont des �l�ments essentiels dans le processus d'authentification du
 *    commer�ant par la banque. Pour des raisons de s�curit� �videntes,
 *    la cl� de hachage doit �tre stock�e dans un environnement s�curis�.
 *
 *    Cette cl� est transmise par Euro-Information de fa�on s�curis�e sous la
 *    forme d'un fichier texte.  Ce fichier comporte en g�n�ral 4 lignes non
 *    modifiables.
 *
 *    Le nom du fichier est "num�ro de tpe.key" (par exemple "1234567.key").
 *
 *       Exemple de contenu de fichier cl� :
 *
 *       VERSION 1 1DCF3D6F296528F723202B59119C6710437128F0
 *       HMAC-SHA1-1234567-CF7F20
 *       #
 *       11d809f5a99d2e9cb9da49db4bd185ba4deaf6ee
 *
 *       Ici, la m�thode � utiliser est "HMAC-SHA1" et la cl� de hachage (qui
 *       devra �tre rendue par l'utilitaire de prise en charge des cl�s) est
 *       "1DCF3D6F296528F723202B59119C6710437128F0".
 *
 * 3/ Afficher le formulaire.
 *
 *   Il suffit ensuite d'afficher ce formulaire HTML pour pr�senter le bouton
 *   "Paiement par carte bancaire" au client.
 *
 *---------------------------------------------------------------------------*
 *
 * Lors du d�veloppement de votre propre CGI de demande de paiement "CGI1",
 * veuillez vous reporter � la documentation technique ci-jointe.
 *
 *---------------------------------------------------------------------------*/

/*===========================================================================*
 *                             Fichiers inclus
 *===========================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifndef MACOS
#  include <malloc.h>
#  include <sys/types.h>
#  include <sys/stat.h>
#endif

/* fonctions communes aux cgi1 et cgi2 */
#include "fcts_util.h"
#include "fcts_cgi.h"
#include "fcts_tpe.h"
#include "fcts_commercant.h"


/*===========================================================================*
 *                           D�finitions des constantes
 *===========================================================================*/

#define REFERENCE_SIZE 12                     /* Taille du champ "reference" */

/* Pour afficher les traces en phase de test, d�commenter la ligne suivante  */
/*
#define DEBUG
*/


/*===========================================================================*
 *                             D�finitions des types
 *===========================================================================*/

/*---------------------------------------------------------------------------*
 * La structure ContextePaiement est pr�vue pour contenir les informations
 * relatives au contexte du paiement.
 * Le commer�ant doit g�rer sa propre m�thode de r�cup�ration de ces donn�es.
 *---------------------------------------------------------------------------*/

typedef struct
{
    char *tpe;          /* Num�ro de TPE fourni par Euro-Information         */
    char *reference;    /* R�f�rence de la commande calcul�e par le marchand */
    char *montant;      /* Montant   de la commande calcul�  par le marchand */
    char *textelibre;   /* Zone libre : typiquement, une r�f�rence longue    */
    char *textebouton;  /* Texte du bouton de paiement                       */
    char *url_serveur;  /* URL du serveur de la banque                       */
    char *url_hp;       /* URL de la page principale du site marchand        */
    char *url_ok;       /* URL de la page "paiement accept�" du site marchand*/
    char *url_err;      /* URL de la page "paiement refus�"  du site marchand*/
    char *langue;       /* Langue choisie par le payeur                      */
    char *societe;      /* Le code soci�t� param�tr� chez Euro-Information   */
} ContextePaiement;



/*===========================================================================*
 *
 *                          Fonctions utilitaires
 *
 *===========================================================================*/

/*---------------------------------------------------------------------------*
 * static int GetContextePaiement (ContextePaiement* param)
 *
 * Cette fonction permet de retrouver les informations relatives au
 * contexte du paiement.
 *
 * Le commer�ant doit g�rer la m�thode de recherche de ces donn�es.
 *
 * Reportez vous � la documentation technique pour conna�tre la taille
 * et le format � respecter pour chaque champ.
 *
 * Param�tre en entr�e :
 *   param : pointeur sur une structure de type ContextePaiement.
 *
 * Retourne TRUE si le contexte est renseign� ou FALSE en cas de probl�me.
 *---------------------------------------------------------------------------*/

static int GetContextePaiement(ContextePaiement* param)
{
    time_t     now;
    struct tm* tm;

    param->url_serveur = StrDup("https://ServeurDeLaBanque/test/paiement.cgi");

    /*
     * Les param�tres tpe, soci�t� et langue doivent �tre d�finis
     * sur le serveur de la banque.
     */
    param->tpe         = StrDup(GetTpeNumber());
    param->langue      = StrDup("FR");
    param->societe     = StrDup("mywebsite");
    param->textebouton = StrDup("Paiement par carte bancaire");

    /*
     * Par d�faut, les URL utilis�es sont celles d�finies sur le serveur
     * de la banque.
     */
    param->url_hp      = StrDup("http://www.monSite.com/myHomePage.html");
    param->url_ok      = StrDup("http://www.monSite.com/myPageOK.html");
    param->url_err     = StrDup("http://www.monSite.com/myPageErr.html");

    /* Le commer�ant doit recalculer le montant */
    param->montant     = StrDup("10.75EUR");

    /* Dans l'exemple la r�f�rence est aliment�e avec l'heure syst�me */
    param->reference   = StrAllocation(REFERENCE_SIZE);
    now = time (NULL);
    tm  = localtime (&now);
    sprintf (param->reference,
             "ref%02d%02d%02d",
             tm->tm_hour,
             tm->tm_min,
             tm->tm_sec);

    /* Le champ textelibre ne doit en aucun cas se substituer aux donn�es
     * permanentes de la base du commer�ant.                                 */
    param->textelibre  = StrDup("par_exemple_reference_interne_longue");

    /* La taille maxi de textelibre est de 3200 caract�res                   */
    if (strlen(param->textelibre) >= 3200)
         return FALSE;

    return TRUE;
}


/*---------------------------------------------------------------------------*
 * static void ExitError (const char* const txt)
 *
 * Cette fonction affiche un message et arr�te le programme avec le code
 * retour 1.
 *
 * Le commer�ant peut adapter cette fonction � ses besoins.
 *
 * Param�tre en entr�e :
 *   txt : message d'erreur � afficher
 *---------------------------------------------------------------------------*/

static void ExitError (const char* const txt)
{
    printf ("<H2>ERREUR %s</H2>\n</TD></TR></TABLE></BODY></HTML>",
            HtmlEncode(txt));

    exit(1);
}


/*===========================================================================*
 *
 *                            Programme principal
 *
 *===========================================================================*/

/*---------------------------------------------------------------------------*
 * int main (int argc, char *argv[])
 *
 * G�n�ration et affichage du formulaire HTML permettant d'effectuer une
 * demande de paiement au serveur de paiement s�curis� de la banque.
 *
 * Retourne 0 si le programme se termine normalement et 1 sinon.
 *
 * ATTENTION : EN CAS DE PROBLEME D'ALLOCATION MEMOIRE DANS LES FONCTIONS
 * Malloc() ou StrAllocation(), LE PROGRAMME S'ARRETE IMMEDIATEMENT AVEC LE
 * CODE RETOUR 1.
 *---------------------------------------------------------------------------*/

int main (int argc, char* argv[])
{
    ContextePaiement context_pai;

    char* formulaire_paiement = NULL;
    char  error_msg[512];
    int   res;

    printf ("Pragma: no-cache\n");
    printf ("Cache-Control: no-cache\n");
    printf ("Expires: -1\n");
    printf ("Content-type: text/html\n\n");

    printf ("<HTML><HEAD>");
    printf ("<TITLE>Test de Paiement en C</TITLE>");
    printf ("</HEAD><BODY>");
    printf ("<TABLE WIDTH=800 HEIGHT=50 BORDER=\"0\" >");
    printf ("<TR><TD COLSPAN=2 >");
    printf ("<H3>Connexion avec le Serveur Bancaire</H3>");
    printf ("<br></TD></TR>");

    /*-----------------------------------------------------------------------*
     * PREMIER TRAITEMENT
     *
     * Rechercher les informations relatives au contexte du paiement
     *-----------------------------------------------------------------------*/
    if (!GetContextePaiement(&context_pai))
    {
        ExitError ("DETERMINATION DU CONTEXTE DU PAIEMENT");
    }

#ifdef DEBUG
    /*-----------------------------------------------------------------------*
     * Affichage pour information des param�tres du paiement au cours de la
     * phase de test.
     *-----------------------------------------------------------------------*/
    printf ("<TR><TD>url_serveur</TD><TD>[%s]</TD></TR>\n",
            HtmlEncode(context_pai.url_serveur));

    printf ("<TR><TD>tpe</TD><TD>[%s]</TD></TR>\n",
            HtmlEncode(context_pai.tpe));

    printf ("<TR><TD>reference</TD><TD>[%s]</TD></TR>\n",
            HtmlEncode(context_pai.reference));

    printf ("<TR><TD>montant</TD><TD>[%s]</TD></TR>\n",
            HtmlEncode(context_pai.montant));

    printf ("<TR><TD>url_hp</TD><TD>[%s]</TD></TR>\n",
            HtmlEncode(context_pai.url_hp));

    printf ("<TR><TD>url_ok</TD><TD>[%s]</TD></TR>\n",
            HtmlEncode(context_pai.url_ok));

    printf ("<TR><TD>url_err</TD><TD>[%s]</TD></TR>\n",
            HtmlEncode(context_pai.url_err));

    printf ("<TR><TD>texte libre encode</TD><TD>[%s]</TD></TR>\n",
            HtmlEncode(context_pai.textelibre));

    printf ("<TR><TD>url_err</TD><TD>[%s]</TD></TR>\n",
            HtmlEncode(context_pai.url_err));

    printf ("<TR><TD>langue</TD><TD>[%s]</TD></TR>\n",
            HtmlEncode(context_pai.langue));

    printf ("<TR><TD>societe</TD><TD>[%s]</TD></TR>\n",
            HtmlEncode(context_pai.societe));
#endif

   /*------------------------------------------------------------------------*
     * DEUXIEME TRAITEMENT
     *
     * G�n�ration du formulaire contenant les champs cach�s � l'aide de la
     * fonction "CreerFormulaireHmac()".
     *-----------------------------------------------------------------------*/

    res = CreerFormulaireHmac (context_pai.url_serveur,
                               VERSION,
                               context_pai.tpe,
                               context_pai.montant,
                               context_pai.reference,
                               context_pai.textelibre,
                               context_pai.url_hp,
                               context_pai.url_ok,
                               context_pai.url_err,
                               context_pai.langue,
                               context_pai.societe,
                               context_pai.textebouton,
                               &formulaire_paiement);

    if ((res <= 0) || !formulaire_paiement)
    {
         sprintf(error_msg,"CreerFormulaireHmac() code erreur:%d\n",res);
         ExitError (error_msg);
    }

    /*-----------------------------------------------------------------------*
     * TROISIEME TRAITEMENT
     *
     * Affichage du formulaire HTML du bouton de paiement
     *-----------------------------------------------------------------------*/
    printf ("<TR><TD><br>Cliquer sur le bouton</TD><TD><br>%s</TD></TR>",
             formulaire_paiement);


    /*-----------------------------------------------------------------------*
     * FIN DES TRAITEMENTS
     *
     * Fin des affichages
     * Lib�ration des zones m�moires allou�es dynamiquement
     *-----------------------------------------------------------------------*/

    printf ("</TABLE></BODY></HTML>");

    Free (formulaire_paiement);
    Free (context_pai.tpe);
    Free (context_pai.reference);
    Free (context_pai.montant);
    Free (context_pai.textelibre);
    Free (context_pai.textebouton);
    Free (context_pai.url_serveur);
    Free (context_pai.url_hp);
    Free (context_pai.url_ok);
    Free (context_pai.url_err);
    Free (context_pai.langue);
    Free (context_pai.societe);

    return 0;
}


/*===========================================================================*/
