/*****************************************************************************
 *
 * CM_CIC_Paiement: kit "open source" pour CyberMUT-P@iement(TM) et
 *                  P@iementCIC(TM).
 * Exemple d'int�gration dans un site marchand en langage C/C++.
 *
 * Fichier "cgi2_commercant.c" : exemple de programme CGI � cr�er pour la
 *            phase "retour" du paiement (CGI2).
 *
 * Auteur   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.0
 * Date     : 18/12/2003
 *
 * Copyright: (c) 2003 Euro-Information. Tous droits r�serv�s.
 * Consulter le document de licence "Licence.txt" joint.
 *
 *****************************************************************************/

/*---------------------------------------------------------------------------*
 * Exemple de programme CGI a cr�er pour la phase "retour" du paiement (CGI2)
 *---------------------------------------------------------------------------*
 *
 * Le but de ce programme est de recevoir et de traiter la confirmation de
 * paiement �mise par le serveur de paiement.
 *
 * L'URL de ce CGI2 doit �tre indiqu�e � Euro-Information au moment de la
 * mise en place du syst�me.
 *
 *---------------------------------------------------------------------------*
 * Explications :
 *---------------------------------------------------------------------------*
 *
 * Lors de la phase "retour" du paiement, le serveur de la banque �met une
 * requ�te HTTP ou HTTPS sur l'URL de confirmation.
 *
 * Cette requ�te contient un champ "code-retour" contenant lui-m�me le
 * r�sultat du paiement, ainsi qu'un certain nombre d'informations, permettant
 * d'identifier la commande (num�ro de TPE, montant, r�f�rence de commande,
 * descriptif, etc).  Optionnellement, un champ "retourPLUS" pr�cise les
 * conditions du paiement.
 *
 * La Query String re�ue est de la forme suivante :
 *  "TPE=<numero_TPE>&date=<date>&montant=<montant>&
 *  reference=<reference_commande>&MAC=<code_MAC>&
 *  texte-libre=<texte_libre>&code-retour=<code_retour>[&retourPLUS=<options>]"
 *
 * Par exemple :
 * "TPE=1234567&date=09%2f10%2f1996%5fa%5f15%3a51%3a46&montant=10%2e75&
 *  reference=0000234&MAC=e4359a2c18d86cf2e4b0e646016c202e89947b04&
 *  texte-libre=test&code-retour=paiement"
 *
 * Lors de cette phase de retour, vous devez utiliser les fonctions
 * "TesterHmac()" et "CreerAccuseReception()" d�finies dans le fichier
 * "fcts_commercant.c".
 *
 * La fonction "TesterHmac()" doit �tre utilis�e au d�but du CGI de
 * confirmation.  Elle prend en compte les aspects de s�curit� de la solution,
 * en garantissant l'int�grite du message de confirmation re�u et en
 * identifiant l'�metteur de ce message (la banque).
 *
 * La fonction "CreerAccuseReception()" doit �tre utilis�e pour renvoyer � la
 * banque l'accus� de bonne r�ception du message de confirmation.  Cette
 * fonction g�n�re la totalit� du message d'accus� de r�ception, qu'il
 * suffit d'afficher sur la sortie standard.
 *
 * Vous pouvez ensuite effectuer vos traitements sp�cifiques.
 *---------------------------------------------------------------------------*
 *
 * Ce CGI doit r�aliser cinq traitements principaux :
 *
 * 1/ Extraire de la QUERY_STRING :
 *    * le HMAC et les autres variables permettant de v�rifier l'int�grit�
 *      des donn�es entre le serveur de la banque et le serveur du commer�ant
 *    * le code-retour de paiement afin de savoir si le paiement a �t�
 *      accept� ou refus�.
 *
 * 2/ Tester le HMAC afin de v�rifier l'int�grite des donn�es.
 *
 *    La fonction TesterHmac() appelle la fonction ComputeHmac() afin de
 *    recalculer le champ MAC fourni dans la requ�te.
 *
 *    Le champ MAC est calcul� � partir de la cl� et de la m�thode de hachage
 *    qui sont des �l�ments essentiels dans le processus d'authentification du
 *    commer�ant par la banque. Pour des raisons de s�curit� �videntes,
 *    la cl� de hachage doit �tre stock�e dans un environnement s�curis�.
 *
 *    Cette cl� est transmise par Euro-Information de fa�on s�curis�e sous la
 *    forme d'un fichier texte.  Ce fichier comporte en g�n�ral 4 lignes non
 *    modifiables.
 *    Le nom du fichier est "num�ro de tpe.key" (par exemple "1234567.key").
 *
 *       Exemple de contenu de fichier cl� :
 *
 *       VERSION 1 1DCF3D6F296528F723202B59119C6710437128F0
 *       HMAC-SHA1-1234567-CF7F20
 *       #
 *       11d809f5a99d2e9cb9da49db4bd185ba4deaf6ee
 *
 *       Ici, la m�thode � utiliser est "HMAC-SHA1" et la cl� de hachage (qui
 *       devra �tre rendue par l'utilitaire de prise en charge des cl�s) est
 *       "1DCF3D6F296528F723202B59119C6710437128F0".
 *
 * 3/ Composer l'accus� de r�ception � destination de la banque.
 *
 *    REMARQUE IMPORTANTE : L'accus� de r�ception du CGI2 ne d�pend pas de
 *                          l'acceptation ou du refus de paiement mais
 *                          d�pend uniquement de l'int�grit� des donn�es
 *                          re�ues.
 *
 * 4/ Tester et prendre en compte le retour de paiement.
 *
 *    Ce traitement est adaptable � souhait par le commer�ant.
 *    Exemples : Envoi d'un mail de commande au commer�ant.
 *               Mise � jour de base de donn�es commandes du commer�ant.
 *               etc.
 *               Noter que la commande doit �tre persistante d�s l'appel
 *               du CGI1 pour pouvoir piloter toutes les phases du paiement.
 *
 * 5/ Afficher l'accus� de r�ception.
 *
 *---------------------------------------------------------------------------*
 *
 * Rappel :
 *
 * Ce programme vous est fourni � titre d'exemple pour traiter la confirmation
 * des paiements �mise par la banque.
 *
 * Lors du d�veloppement de votre propre CGI de confirmation des paiements
 * "CGI2", veuillez vous reporter � la documentation technique ci-jointe.
 *
 *---------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef MACOS
#  include <malloc.h>
#  include <sys/types.h>
#  include <sys/stat.h>
#endif

/* fonctions communes aux cgi1 et cgi2 */
#include "fcts_util.h"
#include "fcts_cgi.h"
#include "fcts_tpe.h"
#include "fcts_commercant.h"


/*===========================================================================*
 *                           D�finitions des constantes
 *===========================================================================*/

/* Pour afficher les traces en phase de test, d�commenter la ligne suivante  */
/*
#define DEBUG
*/


/*===========================================================================*
 *
 *                          Fonctions utilitaires
 *
 *===========================================================================*/

/*---------------------------------------------------------------------------*
 * static void ExitError (const char* const txt)
 *
 * Cette fonction �crit un message sur stderr et arr�te le programme avec un
 * code retour 1.
 *
 * Param�tre en entr�e :
 *   txt : message d'erreur � afficher.
 *---------------------------------------------------------------------------*/

static void ExitError (const char* const txt)
{
    fputs (HtmlEncode (txt), stderr);
    exit(1);
}


/*===========================================================================*
 *
 *                            Programme principal
 *
 *===========================================================================*/

/*---------------------------------------------------------------------------*
 * int main (int argc, char *argv[])
 *
 * R�cup�ration de la confirmation du paiement avec contr�le du message re�u,
 * puis envoi de l'accus� de r�ception � la banque.
 *
 * Retourne 0 si le programme se termine normalement et 1 sinon.
 *
 * ATTENTION : EN CAS DE PROBLEME D'ALLOCATION MEMOIRE DANS LES FONCTIONS
 * Malloc() ou StrAllocation(), LE PROGRAMME S'ARRETE IMMEDIATEMENT AVEC LE
 * CODE RETOUR 1. *----------------------------------------------------------------------------*/

int main (int argc, char *argv[])
{
    CgiParam *params;   /* contient les diff�rents champs de la QUERY_STRING */
    int   num_params;   /* contient le nombre de champs dans la QUERY_STRING */
    char* TPE;
    char* montant;
    char* reference;
    char* date_commande;
    char* MAC;
    char* textelibre;
    char* coderetour;
    char* retourPLUS;
    char  error_msg[512];      /* tampon utilis� pour les messages d'erreur  */
    char* accuse_reception;    /* Accus� de r�ception � renvoyer � la banque */
    int   res_auth = 0;
    int   res      = 0;
#ifdef DEBUG
    int   i;
#endif

#ifdef _WIN32
    printf ("Pragma: no-cache\r\n");
    printf ("Cache-Control: no-cache\r\n");
    printf ("Expires: -1\r\n");
    printf ("Content-type: text/plain\r\n\r\n");
#else
    printf ("Pragma: no-cache\n");
    printf ("Cache-Control: no-cache\n");
    printf ("Expires: -1\n");
    printf ("Content-type: text/plain\n\n");
#endif


    /*-----------------------------------------------------------------------*
     * PREMIER TRAITEMENT
     *
     * Extraire de la QUERY_STRING le code-retour du paiement ainsi que les
     * autres variables permettant de v�rifier le HMAC.
     *-----------------------------------------------------------------------*/

    num_params = GetFieldsFromQuery (&params);
    if (num_params <= 0)
    {
        sprintf (error_msg, "GetFieldsFromQuery code erreur %d.\n",num_params);
        ExitError(error_msg);
    }


    /*
     * R�cup�ration des informations de la commande contenues dans le
     * formulaire
     */

    if ( !(TPE = GetFieldFromFormByName (params, "TPE")) )
        ExitError ("GetFieldFromFormByName probl�me champ TPE.\n");

    if ( !(date_commande = GetFieldFromFormByName (params, "date")) )
        ExitError ("GetFieldFromFormByName probl�me champ date.\n");

    if ( !(montant = GetFieldFromFormByName (params, "montant")) )
        ExitError ("GetFieldFromFormByName probl�me champ montant.\n");

    if ( !(reference = GetFieldFromFormByName (params, "reference")) )
        ExitError ("GetFieldFromFormByName probl�me champ reference.\n");

    if ( !(textelibre = GetFieldFromFormByName (params, "texte-libre")) )
        ExitError ("GetFieldFromFormByName probl�me champ texte-libre.\n");

    if ( !(MAC = GetFieldFromFormByName (params, "MAC")) )
        ExitError ("GetFieldFromFormByName probl�me champ MAC.\n");

    if ( !(coderetour = GetFieldFromFormByName (params, "code-retour")) )
        ExitError ("GetFieldFromFormByName probl�me champ code-retour.\n");

    if ( !(retourPLUS = GetFieldFromFormByName (params, "retourPLUS")) )
        retourPLUS = StrDup(NULL);                        /* champ optionnel */


    /* Contr�le de la coh�rence du num�ro de TPE */
    if (strcmp (GetTpeNumber(), TPE) != 0)
        ExitError ("Probl�me TPE re�u diff�rent du TPE programm�.\n");


    /*-----------------------------------------------------------------------*
     * DEUXIEME TRAITEMENT
     *
     * Tester le HMAC afin de v�rifier l'int�grit� des donn�es.
     *-----------------------------------------------------------------------*/

    res = TesterHmac (MAC,
                      VERSION,
                      TPE,
                      date_commande,
                      montant,
                      reference,
                      textelibre,
                      coderetour,
                      retourPLUS,
                      &res_auth);

    if (!res)
    {
        sprintf (error_msg, "TesterHmac code erreur %d.\n", res);
        ExitError(error_msg);
    }


    /*-----------------------------------------------------------------------*
     * TROISIEME TRAITEMENT
     *
     * Composer l'accus� de r�ception � destination de la banque selon le
     * r�sultat du test du HMAC.
     *-----------------------------------------------------------------------*/

    res = CreerAccuseReception (res_auth, &accuse_reception);

    if (res <= 0)
    {
        sprintf (error_msg, "CreerAccuseReception code erreur %d.\n", res);
        ExitError(error_msg);
    }

#ifdef DEBUG
    printf ("Contenu des champs de la requ�te :\n");
    for (i = 0; i < num_params; i++)
        printf ("[%s] = [%s]\n", params[i].name, params[i].value);
#endif


    /*-----------------------------------------------------------------------*
     * QUATRIEME TRAITEMENT
     *
     * Tester les informations de retour de paiement.
     *
     * ATTENTION : le champ "code-retour" prend des valeurs diff�rentes en
     *             TEST et en PRODUCTION.
     *
     * Le champ "code-retour" contient le r�sultat de la demande de paiement.
     * Le champ "retourPLUS", optionnel, contient des donn�es compl�mentaires
     * d�pendant du type de contrat du commer�ant et pr�cisant le code de
     * retour.
     *-----------------------------------------------------------------------*
     * VOUS DEVEZ INSERER VOS TRAITEMENTS SPECIFIQUES ICI.
     * Par exemple : Envoi d'un mail de commande au commer�ant.
     *               Mise � jour de base de donn�es commandes du commer�ant.
     *               etc.
     *-----------------------------------------------------------------------*/

    if (res_auth == AUTHENTIFICATION_OK)
    {
         if (strcmp (coderetour, PAIEMENT_PROD_ACCEPTE) == 0)
         {
            /* ------------------------------------------------------------- */
            /* -- Paiement accept� en PRODUCTION et message int�gr�.      -- */
            /* ------------------------------------------------------------- */
            /* -- Il faut mettre � jour la commande de la base commer�ant -- */
            /* -- de PRODUCTION, �ventuellement scorer la commande        -- */
            /* -- et d�clencher la cha�ne logistique.                     -- */
            /* ------------------------------------------------------------- */
         }
         else if (strcmp (coderetour, PAIEMENT_TEST_ACCEPTE) == 0)
         {
            /* ------------------------------------------------------------- */
            /* -- Paiement accept� en TEST et message int�gr�.            -- */
            /* ------------------------------------------------------------- */
            /* -- Il faut mettre � jour la commande de la base commer�ant -- */
            /* -- de TEST.                                                -- */
            /* ------------------------------------------------------------- */
        }
        else
        {
            /* ------------------------------------------------------------- */
            /* -- Paiement refus� par la banque.                          -- */
            /* ------------------------------------------------------------- */
        }
    }
    else
    {
        /* --------------------------------------------------------------- */
        /* --  Falsification ou probl�me de transfert de donn�es.       -- */
        /* --------------------------------------------------------------- */
        /* -- Le paiement doit �tre v�rifi� par le commer�ant dans son  -- */
        /* -- gestionnaire de paiements avant de lancer la logistique.  -- */
        /* --------------------------------------------------------------- */
    }


    /*-----------------------------------------------------------------------*
     * CINQUIEME TRAITEMENT
     *
     * Afficher l'accus� de r�ception.
     *-----------------------------------------------------------------------*/

    printf ("%s\n", accuse_reception);


    /*-----------------------------------------------------------------------*
     * FIN DES TRAITEMENTS
     *-----------------------------------------------------------------------*/

    Free (params);
    Free (accuse_reception);

    return 0;
}


/*===========================================================================*/
