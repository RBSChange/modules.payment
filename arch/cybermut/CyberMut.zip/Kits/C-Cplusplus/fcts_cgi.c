/*****************************************************************************
 *
 * CM_CIC_Paiement: kit "open source" pour CyberMUT-P@iement(TM) et
 *                  P@iementCIC(TM).
 * Exemple d'int�gration dans un site marchand en langage C/C++.
 *
 * Fichier "fcts_cgi.c" : fonctions relatives � l'interface CGI.
 *
 * Auteur   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.0
 * Date     : 18/12/2003
 *
 * Copyright: (c) 2003 Euro-Information. Tous droits r�serv�s.
 * Consulter le document de licence "Licence.txt" joint.
 *
 *****************************************************************************/

/*===========================================================================*
 *                               Fichiers inclus
 *===========================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#ifndef MACOS
#  include <malloc.h>
#  include <sys/types.h>
#  include <sys/stat.h>
#endif

#include "fcts_util.h"
#include "fcts_cgi.h"


/*===========================================================================*
 *                           D�finitions des constantes
 *===========================================================================*/

#define MAX_SIZE_QUERY  5000    /* Nombre maximum de caract�res accept�s pour
                                 * les param�tres de la requ�te HTTP         */
#define NB_MAX_PARAMS     20    /* Nombre maximum de champs dans les
                                 * param�tres de la requ�te HTTP (en entr�e
                                 * de CGI2)                                  */

/* Liste des caract�res qui ne sont pas encod�s dans la fonction HtmlEncode()*/
#define SAFE_CHARS      "ABCDEFGHIJKLMNOPQRSTUVWXYZ"         \
                        "abcdefghijklmnopqrstuvwxyz"         \
                        "0123456789_.-"


/*===========================================================================*
 *                     D�claration des fonctions locales
 *===========================================================================*/

static int  ReadQueryFromServer    (char**    query);
static int  ReadQueryFromServer    (char**    query);
static int  GetFieldsFromForm      (char*     query, CgiParam** params);
static int  ParseAndUrlDecodeParam (CgiParam* p);
static void UrlDecode              (char*     url);


/*===========================================================================*
 *
 *        Fonctions pour r�cup�rer et d�coder les param�tres d'un CGI
 *
 *===========================================================================*/

/*----------------------------------------------------------------------------*
 * int GetFieldsFromQuery (CgiParam** params)
 *
 * Cette fonction lit les param�tres de la requ�te HTTP (que la m�thode
 * utilis�e soit GET ou POST) et range les couples (nom, valeur) de chaque
 * champs dans un tableau de structures de type CgiParam.
 * Le dernier couple du tableau est positionn� � (NULL,NULL).
 *
 * Param�tre en sortie :
 *   params : pointeur de pointeur vers le tableau de couples (nom, valeur).
 *
 * Retourne le nombre de couples trouv�s dans la requ�te ou une valeur
 * n�gative en cas d'erreur. Les codes d'erreur possibles sont:
 *   PB_REQUEST_METHOD1 : variable d'environnement REQUEST_METHOD non definie.
 *   PB_REQUEST_METHOD2 : m�thode d'appel diff�rente de GET et de POST.
 *   PB_QUERY_STRING    : variable d'environnement QUERY_STRING non d�finie
 *                        en m�thode GET.
 *   PB_REQUEST_POST    : probl�me de lecture rencontr� en m�thode POST.
 *   PB_SIZE_QUERY      : taille de la requ�te sup�rieure � MAX_SIZE_QUERY.
 *   PB_INVALID_REQUEST : requ�te invalide.
 *   PB_NB_MAX_PARAMS   : nombre de param�tres sup�rieur � NB_MAX_PARAMS.
 *---------------------------------------------------------------------------*/

int GetFieldsFromQuery (CgiParam** params)
{
    char* query_string;
    int   return_code;

    /* on r�cup�re les param�tres de la requ�te HTTP... */
    return_code = ReadQueryFromServer (&query_string);
    if (return_code > 0)
    {
        /* ... et on la traite pour en extraire les couples (nom, valeur) */
        return_code = GetFieldsFromForm (query_string, params);
    }
    return return_code;
}


/*----------------------------------------------------------------------------*
 * static int ReadQueryFromServer (char** query)
 *
 * Lecture d'une requ�te HTTP transmise en POST ou en GET.
 *
 * Param�tre en sortie :
 *   query : pointeur de pointeur vers la requ�te re�ue.
 *
 * Retourne la taille de la requ�te ou une valeur n�gative en cas d'erreur
 * (cf. fonction GetFieldsFromQuery()).
 *---------------------------------------------------------------------------*/

static int ReadQueryFromServer (char** query)
{
    char* p_method;
    char* p_query;
    int   query_size = 0;    /* Variable retourn�e */

    if ((p_method = getenv ("REQUEST_METHOD")) != NULL)
    {
        if (!strcmp (p_method, "GET"))
        {
            p_query = getenv("QUERY_STRING");
            if (p_query != NULL)
            {
                query_size = Strlen (p_query);
                if (query_size > MAX_SIZE_QUERY)
                    return PB_SIZE_QUERY;
                *query = StrDup (p_query);
            }
            else
                return PB_QUERY_STRING;
        }
        else if (!strcmp (p_method, "POST"))
        {
            *query = StrAllocation (MAX_SIZE_QUERY);
            query_size = fread (*query, 1, MAX_SIZE_QUERY, stdin);
            if (query_size < 0)
            {
                Free(*query);
                return PB_REQUEST_POST;
            }
            if (query_size >= MAX_SIZE_QUERY)
            {
                Free(*query);
                return PB_SIZE_QUERY;
            }
            (*query)[query_size] = '\0';
        }
        else
            /* M�thode d'appel non g�r�e */
            return PB_REQUEST_METHOD2;
    }
    else
        /* Variable d'environnement REQUEST_METHOD non d�finie */
        return PB_REQUEST_METHOD1;

    return query_size;
}


/*----------------------------------------------------------------------------*
 * static int GetFieldsFromForm (char* query, param** params)
 *
 * Cette fonction initialise un tableau de structures form�es par
 * des pointeurs sur le nom et la valeur de chaque champ.
 * Le dernier couple (nom,valeur) du tableau est positionn� � (NULL,NULL).
 *
 * Param�tre en entr�e :
 *   query : cha�ne de caract�res qui contient les param�tres de la requ�te.
 *
 * Param�tre en sortie :
 *   params : pointeur de pointeur vers le tableau de couples (nom,valeur).
 *
 * Retourne le nombre de couples trouv�s dans la requ�te ou une valeur
 * n�gative en cas d'erreur (cf. fonction GetFieldsFromQuery()).
 *---------------------------------------------------------------------------*/

static int GetFieldsFromForm (char* query, CgiParam** params)
{
    CgiParam* p_params;
    char*     p_separateur;
    int       res;
    int       nbr_params = 0;    /* Variable retourn�e */

    if (query == NULL)
        return PB_INVALID_REQUEST;

    *params  = (CgiParam*) Malloc ((NB_MAX_PARAMS + 1) * sizeof(CgiParam));
    p_params = *params;

    p_params->name = query;
    /* D�coupage des couples "champ=valeur&" */
    while ( (p_separateur = strchr (p_params->name, '&')) )
    {
        /* Positionner une fin de cha�ne � la place du '&' de "champ=valeur&"*/
        *p_separateur = '\0';

        if ( !(res = ParseAndUrlDecodeParam (p_params)) )
            return PB_INVALID_REQUEST;

        nbr_params++;
        if (nbr_params >= NB_MAX_PARAMS)
        {
            free (*params);
            return PB_NB_MAX_PARAMS;
        }

        /* Couple suivant */
        p_params++;
        p_params->name = p_separateur + 1;
    }

    /* Traitement du dernier couple */
    if ( !(res = ParseAndUrlDecodeParam (p_params)) )
        return PB_INVALID_REQUEST;

    nbr_params++;
    p_params++;
    p_params->name = p_params->value = NULL;
    return nbr_params;
}


/*----------------------------------------------------------------------------*
 * static int ParseAndUrlDecodeParam (CgiParam* p)
 *
 * Cette fonction modifie une structure CgiParam de la forme ("nom=valeur",
 * NULL) en ("nom", "valeur") et UrlD�code les deux champs.
 * Exemple : p->name="TPE=1234567" devient p->name="TPE", p->value="1234567".
 *
 * Param�tre en entr�e/sortie :
 *   p : pointeur sur une structure CgiParam.
 *
 * Retourne FALSE en cas d'erreur (si "p->name" ne contient pas de signe "=")
 * et TRUE sinon.
 *---------------------------------------------------------------------------*/

static int ParseAndUrlDecodeParam (CgiParam* p)
{
    if ( !(p->value = strchr(p->name, '=')) )
        return FALSE;

    /* Positionner la fin du nom et le d�but de la valeur */
    *(p->value) = '\0';
    p->value++;

    UrlDecode (p->name);
    UrlDecode (p->value);
    return TRUE;
}


/*----------------------------------------------------------------------------*
 * static void UrlDecode (char* url)
 *
 * Cette fonction d�code une cha�ne de caract�res encod�e sous la forme URL
 * (ie. dont certains caract�res ont �t� remplac�s par "%xx").
 *
 * Param�tre en entr�e/sortie :
 *   url : la cha�ne de caract�res � d�coder. La cha�ne doit �tre valide.
 *
 * ATTENTION : si la cha�ne contient "%00", la cha�ne r�sultante est tronqu�e.
 *             Les valeurs unicode ne sont pas support�es.
 *---------------------------------------------------------------------------*/

static void UrlDecode (char* url)
{
    int length, x, y;

    if (!url)
        return;

    length = strlen (url);
    for(x=0, y=0; url[y]; x++, y++)
    {
        if ( (url[x] = url[y]) == '%' )
        {
            /* on ne d�code pas une valeur non conforme ou apr�s le '\0' */
            if (   (y < (length-2))
                && isxdigit (url[y+1])
                && isxdigit (url[y+2]) )
            {
                url[x] = x2c(&url[y+1]);
                y+=2;
            }
        }
        else if (url[x] == '+')
            url[x] = ' ';
    }
    url[x] = '\0';
}


/*----------------------------------------------------------------------------*
 * char* GetFieldFromFormByName (const CgiParam* params, const char* name)
 *
 * Recherche la valeur d'un champ dans un tableau de couples (nom, valeur).
 *
 * Param�tres en entr�e :
 *   params : pointeur sur un tableau de couples de type CgiParams se
 *            terminant par (NULL, NULL).
 *   name   : nom du champ � rechercher.
 *
 * Retourne un pointeur sur la valeur de l'�l�ment recherch� ou NULL si
 * l'�l�ment n'a pas ete trouv�.
 *---------------------------------------------------------------------------*/

char* GetFieldFromFormByName (const CgiParam* params, const char* name)
{
    if (name == NULL)
        return NULL;

    /* Recherche le couple correspondant � "name" dans le tableau "params" en
     * s'arr�tant sur (NULL, NULL) */
    while ( (params->name) && (strcmp(params->name,name)) )
        ++params;

    return params->value;
}



/*===========================================================================*
 *
 *        Fonctions utilis�es dans l'�criture des pages HTML par un CGI
 *
 *===========================================================================*/

/*----------------------------------------------------------------------------*
 * char* HtmlEncode (const char* const source)
 *
 * Cette fonction encode la cha�ne source en codant les caract�res douteux en
 * HTML.
 *
 * Param�tre en entr�e :
 *   source : pointeur sur la cha�ne de caract�res � encoder.
 *
 * Retourne un pointeur sur la cha�ne de caract�res encod�e.
 * Retourne un pointeur sur une cha�ne vide si source est NULL.
 *
 * ATTENTION : si vous utilisez des caract�res au del� de ASCII 127,
 *             encodez la cha�ne en entr�e en Base64 avant d'appeler
 *             cette fonction afin d'obtenir un sceau MAC correct.
 *
 * Remarque  : le tampon allou� par cette fonction fait 6 fois
 *             la taille de la cha�ne en entr�e, car les caract�res
 *             sont encod�s sous la forme "&#xhh;".
 *---------------------------------------------------------------------------*/

char* HtmlEncode (const char* const source)
{
    int           length;
    int           i;
    unsigned char cc;
    char*         ptr;
    char*         encoded;    /* Variable retourn�e */

    length  = Strlen(source);

    /* Pire cas : tous les caract�res sont cod�s sous la forme "&#xhh;" */
    encoded = StrAllocation (length * 6);

    /* Parcours de la cha�ne source et copie ou encodage des caract�res au
     * fur et � mesure */
    ptr = encoded;
    for (i = 0; i < length; i++)
    {
        cc = (unsigned char) source[i];
        if ( (strchr (SAFE_CHARS, source[i])) || (cc > 127) )
        {
            *ptr = source[i];
            ptr++;
        }
        else
            ptr += sprintf (ptr,"&#x%02x;", cc);
    }
    *ptr = '\0';

    return encoded;
}


/*===========================================================================*/
