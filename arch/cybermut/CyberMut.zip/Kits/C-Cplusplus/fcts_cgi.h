/*****************************************************************************
 *
 * CM_CIC_Paiement: kit "open source" pour CyberMUT-P@iement(TM) et
 *                  P@iementCIC(TM).
 * Exemple d'int�gration dans un site marchand en langage C/C++.
 *
 * Fichier "fcts_cgi.h" : prototypes des fonctions relatives � l'interface
 *            CGI. Le code source de ces fonctions et les commentaires
 *            associ�s se trouvent dans le fichier "fcts_cgi.c".
 *
 * Auteur   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.0
 * Date     : 18/12/2003
 *
 * Copyright: (c) 2003 Euro-Information. Tous droits r�serv�s.
 * Consulter le document de licence "Licence.txt" joint.
 *
 *****************************************************************************/

#ifndef FCTS_CGI_H
#define FCTS_CGI_H


/*===========================================================================*
 *                             Fichiers inclus
 *===========================================================================*/

/* Ce fichier n�cessite les inclusions suivantes:
 *    #include "fcts_util.h"                    \* pour BEGIN_EXTERN_C, etc. *\
 */


/*===========================================================================*
 *                           D�finitions des constantes
 *===========================================================================*/

/*----------------------------------------------------------------------------*
 * Code de retour des fonctions utilis�es par CGI1 et CGI2
 *---------------------------------------------------------------------------*/

#define PB_SIZE_QUERY        -1    /* Taille de la requ�te sup�rieure �
                                    * MAX_SIZE_QUERY                         */
#define PB_QUERY_STRING      -2    /* Variable d'environnement QUERY_STRING
                                    * non d�finie en m�thode GET             */
#define PB_REQUEST_POST      -3    /* Erreur de lecture en m�thode POST      */
#define PB_REQUEST_METHOD1   -4    /* Variable d'environnement REQUEST_METHOD
                                    * non d�finie                            */
#define PB_REQUEST_METHOD2   -5    /* M�thode d'appel diff�rente de GET/POST */
#define PB_NB_MAX_PARAMS     -6    /* Plus de NB_MAX_PARAMS param�tres       */
#define PB_INVALID_REQUEST   -7    /* Requ�te invalide                       */


/*===========================================================================*
 *                           D�finitions des types
 *===========================================================================*/

typedef struct       /* Couples (nom du champ, valeur champ) d'un formulaire */
{
    char *name;
    char *value;
} CgiParam;


/*===========================================================================*
 *                          D�claration des fonctions
 *===========================================================================*/

BEGIN_EXTERN_C

int   GetFieldsFromQuery     (CgiParam** params);
char* GetFieldFromFormByName (const CgiParam* params, const char* name);
char* HtmlEncode             (const char* const source);

END_EXTERN_C


/*===========================================================================*/

#endif /* FCTS_CGI_H */

/*===========================================================================*/
