/*****************************************************************************
 *
 * CM_CIC_Paiement: kit "open source" pour CyberMUT-P@iement(TM) et
 *                  P@iementCIC(TM).
 * Exemple d'int�gration dans un site marchand en langage C/C++.
 *
 * Fichier "fcts_commercant.c" : fonctions communes aux programmes
 *            "cgi1_commercant.c" et "cgi2_commercant.c".
 *
 * Auteur   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.0
 * Date     : 18/12/2003
 *
 * Copyright: (c) 2003 Euro-Information. Tous droits r�serv�s.
 * Consulter le document de licence "Licence.txt" joint.
 *
 *****************************************************************************/

/* Remarque : La fonction de hachage "HMAC()" utilis�e dans cet exemple est
 *            impl�ment�e dans la bilioth�que "openssl"
 *            (http://www.openssl.org/).
 *            Vous pouvez aussi utiliser une autre fonction de hachage qui
 *            respecte la RFC 2104.
 */

/*===========================================================================*
 *                             Fichiers inclus
 *===========================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

#ifdef _WIN32
#  define WITH_ARG_ANSI
#  include <stdarg.h>
#endif
#ifdef __STDC__
#  define WITH_ARG_ANSI
#  include <stdarg.h>
#endif

#ifndef WITH_ARG_ANSI
#  include <varargs.h>
#endif

#ifndef MACOS
#  include <malloc.h>
#  include <sys/types.h>
#  include <sys/stat.h>
#endif

#include "openssl/hmac.h"               /* pour la fonction HMAC()
                                         * (ref: http://www.openssl.org/)    */

#include "fcts_util.h"                  /* Fonctions diverses                */
#include "fcts_cgi.h"                   /* pour la Fonction HtmlEncode()     */
#include "fcts_commercant.h"
#include "fcts_tpe.h"                   /* pour la fonction GetContexteTPE() */


/*===========================================================================*
 *                           D�finitions des constantes
 *===========================================================================*/

#define VERSION_REPONSE    "1" /* Num�ro de version de la r�ponse commer�ant */
#define TIMESTAMP_LENGTH   19  /* Longueur du format de date                 */


                 /* R�ponse au serveur de la banque lorsque les Hmac sont ...*/
#define DOCUMENT_OK        "OK"                            /* ... identiques */
#define DOCUMENT_FALSIFIE  "Document falsifie"             /* ... diff�rents */

                         /* *** NE PAS MODIFIER *** */
                         /* Format d'accus� de r�ception renvoy� par le CGI2 */
#ifdef _WIN32
#  define ACCUSE_RECEPTION "Date: %s\r\n"                       \
                           "Version: %s\r\n"                    \
                           "%s\r\n"
#else
#  define ACCUSE_RECEPTION "Date: %s\n"                         \
                           "Version: %s\n"                      \
                           "%s\n"
#endif

                  /* *** NE PAS MODIFIER *** */
                  /* Format du formulaire HTML envoy� au serveur de paiement */
#define  FORMAT_FORMULAIRE "\n<form action=\"%s\" name=\"PaymentRequest\"  " \
            "method=\"post\" target=\"_top\">"                               \
            "\n<input type=\"hidden\" name=\"version\"        value=\"%s\">" \
            "\n<input type=\"hidden\" name=\"TPE\"            value=\"%s\">" \
            "\n<input type=\"hidden\" name=\"date\"           value=\"%s\">" \
            "\n<input type=\"hidden\" name=\"montant\"        value=\"%s\">" \
            "\n<input type=\"hidden\" name=\"reference\"      value=\"%s\">" \
            "\n<input type=\"hidden\" name=\"MAC\"            value=\"%s\">" \
            "\n<input type=\"hidden\" name=\"url_retour\"     value=\"%s\">" \
            "\n<input type=\"hidden\" name=\"url_retour_ok\"  value=\"%s\">" \
            "\n<input type=\"hidden\" name=\"url_retour_err\" value=\"%s\">" \
            "\n<input type=\"hidden\" name=\"lgue\"           value=\"%s\">" \
            "\n<input type=\"hidden\" name=\"societe\"        value=\"%s\">" \
            "\n<input type=\"hidden\" name=\"texte-libre\"    value=\"%s\">" \
            "\n<input type=\"submit\"                         value=\"%s\">" \
            "\n</form>"

                 /* *** NE PAS MODIFIER *** */
                 /* Caract�res utilis�s dans la s�curisation des �changes... */
#define PAD_CHAR_M2B  '*'             /* ... du commer�ant vers la banque    */
#define PAD_CHAR_B2M  '+'             /* ... de la banque vers le commer�ant */


/*===========================================================================*
 *                     D�claration des fonctions locales
 *===========================================================================*/

static char*   GetDateCommerce ();
static int     ComputeHmac     (const char* const tpe,
                                const char* const data,
                                const int         data_size,
                                char**            hmac);
#ifdef WITH_ARG_ANSI
  static int   ConcatString    (const char pad, char **document, ... );
#else
  static int   ConcatString    (const char pad, va_alist ) va_dcl;
#endif


/*===========================================================================*
 *
 *                       Fonctions de CyberMUT-P@iement
 *
 *===========================================================================*/

/*----------------------------------------------------------------------------*
 * int CreerFormulaireHmac (const char* const url_serveur,
 *                          const char* const version,
 *                          const char* const tpe,
 *                          const char* const montant,
 *                          const char* const reference,
 *                          const char* const textelibre,
 *                          const char* const url_retour,
 *                          const char* const url_retour_ok,
 *                          const char* const url_retour_err,
 *                          const char* const langue,
 *                          const char* const societe,
 *                          const char* const textebouton,
 *                          char**            form)
 *
 * Cette fonction g�n�re le formulaire HTML du bouton de paiement.
 * Voir la documentation technique.
 *
 * Param�tres en entr�e :
 *   url_serveur     : URL de la page de paiement de la banque.
 *   version         : version de l'interface de paiement.
 *   tpe             : num�ro de TPE fourni par Euro-Information.
 *   montant         : montant et devise de la commande (ex: "123.45EUR").
 *   reference       : r�f�rence de la commande (max. 12 caract�res).
 *   textelibre      : zone libre pour le commer�ant (max. 3200 caract�res).
 *   url_retour      : url de la page principale sur le site commer�ant.
 *   url_retour_ok   : url de la page "paiement accept�" sur le site comm.
 *   url_retour_err  : url de la page d'erreur sur le site commer�ant.
 *   langue          : code langue ("FR", "EN", "DE", "ES" ou "IT").
 *   societe         : code soci�t�.
 *   textebouton     : texte du bouton de paiement.
 *
 * Param�tre en sortie :
 *   form            : adresse de l'adresse du formulaire HTML.
 *
 * Retourne la longueur du formulaire (sans le '\0' finale) ou une valeur
 * n�gative en cas d'erreur :
 *   PB_PARAM_NULL   : un des param�tres en entr�e est NULL.
 *   PB_STRING_HEX   : la cl� de hachage n'est pas valide.
 *   PB_ALGO_HMAC    : la m�thode de hachage n'est pas g�r�e.
 *   PB_CALCUL_HMAC  : une erreur est survenue lors du calcul du hmac.
 *   PB_CONTEXTE_TPE : une erreur est survenue lors de la r�cup�ration de la
 *                     cl� de hachage.
 *---------------------------------------------------------------------------*/

int CreerFormulaireHmac (const char* const url_serveur,
                         const char* const version,
                         const char* const tpe,
                         const char* const montant,
                         const char* const reference,
                         const char* const textelibre,
                         const char* const url_retour,
                         const char* const url_retour_ok,
                         const char* const url_retour_err,
                         const char* const langue,
                         const char* const societe,
                         const char* const textebouton,
                         char**            form)
{
    char* cdate;
    char* document;
    char* mac;
    char* hurl_serveur;
    char* hversion;
    char* htpe;
    char* hcdate;
    char* hmontant;
    char* hreference;
    char* htextelibre;
    char* hurl_retour;
    char* hurl_retour_ok;
    char* hurl_retour_err;
    char* hlangue;
    char* hsociete;
    char* htextebouton;
    char* hmac;
    int   length;
    int   res;
    int   lg  = 0;    /* Valeur retourn�e */

    *form = NULL;

    if (   (!url_serveur)
        || (!tpe)
        || (!montant)
        || (!reference)
        || (!url_retour)
        || (!url_retour_ok)
        || (!url_retour_err)
        || (!textelibre)
        || (!version)
        || (!langue)
        || (!societe)
        || (!textebouton)) {
        return PB_PARAM_NULL;
    }

    if (strncmp (url_serveur, "https://", 8) != 0) {
        /* url_serveur does not look like an URL of payement server: report an
         * error */
        return PB_PARAM_NULL;
    }      

    cdate = GetDateCommerce();

    /* Composer le document � hacher */
    length = ConcatString (PAD_CHAR_M2B,
                           &document,
                           "",
                           tpe,
                           cdate,
                           montant,
                           reference,
                           textelibre,
                           version,
                           langue,
                           societe,
                           NULL);

    /* Calculer le HMAC */
    res = ComputeHmac (tpe, document, length, &mac);
    if (res <= 0)
        return res;

    /* HTML-encoder les �l�ments du formulaire */
    hurl_serveur    = HtmlEncode (url_serveur);
    hversion        = HtmlEncode (version);
    htpe            = HtmlEncode (tpe);
    hcdate          = HtmlEncode (cdate);
    hmontant        = HtmlEncode (montant);
    hreference      = HtmlEncode (reference);
    hmac            = HtmlEncode (mac);
    hurl_retour     = HtmlEncode (url_retour);
    hurl_retour_ok  = HtmlEncode (url_retour_ok);
    hurl_retour_err = HtmlEncode (url_retour_err);
    hlangue         = HtmlEncode (langue);
    hsociete        = HtmlEncode (societe);
    htextelibre     = HtmlEncode (textelibre);
    htextebouton    = HtmlEncode (textebouton);

    /* Longueur totale du formulaire : cha�ne de format + champs.
     * La taille r�ellement n�cessaire est l�g�rement inf�rieure car,
     * pour etre exact, il faudrait soustraire la taille des �l�ments
     * de format "%s" de la cha�ne FORMAT_FORMULAIRE, mais le code est plus
     * simple (et plus s�r en cas de modificaiton du format) ainsi.
     */
    length =   strlen (hurl_serveur)
             + strlen (hversion)
             + strlen (htpe)
             + strlen (hcdate)
             + strlen (hmontant)
             + strlen (hreference)
             + strlen (hmac)
             + strlen (hurl_retour)
             + strlen (hurl_retour_ok)
             + strlen (hurl_retour_err)
             + strlen (hlangue)
             + strlen (hsociete)
             + strlen (htextelibre)
             + strlen (htextebouton)
             + strlen (FORMAT_FORMULAIRE);

    *form = StrAllocation (length);

    /* G�n�rer le formulaire HTML du bouton de paiement */
    lg = sprintf (*form, FORMAT_FORMULAIRE,
                         hurl_serveur,
                         hversion,
                         htpe,
                         hcdate,
                         hmontant,
                         hreference,
                         hmac,
                         hurl_retour,
                         hurl_retour_ok,
                         hurl_retour_err,
                         hlangue,
                         hsociete,
                         htextelibre,
                         htextebouton);

    Free (hurl_serveur);
    Free (hversion);
    Free (htpe);
    Free (hcdate);
    Free (hmontant);
    Free (hreference);
    Free (hmac);
    Free (hurl_retour);
    Free (hurl_retour_ok);
    Free (hurl_retour_err);
    Free (hlangue);
    Free (hsociete);
    Free (htextelibre);
    Free (htextebouton);

    Free (document);
    Free (cdate);
    Free (mac);

    return lg;
}


/*----------------------------------------------------------------------------*
 * int TesterHmac (const char* const HMAC,
 *                 const char* const version,
 *                 const char* const tpe,
 *                 const char* const date_commande,
 *                 const char* const montant,
 *                 const char* const reference,
 *                 const char* const textelibre,
 *                 const char* const coderetour,
 *                 const char* const retourPLUS,
 *                 int*              resultat)
 *
 * Cette fonction v�rifie le HMAC envoy� au cgi2_commercant par la banque.
 * Voir la documentation technique.
 *
 * Param�tres en entr�e :
 *  HMAC            : hmac re�u du serveur de la banque
 *  version         : version de l'interface de paiement
 *  tpe             : num�ro de TPE fourni par Euro-Information
 *  date_commande   : date de la commande fournie
 *  montant         : montant de la commande fournie
 *  reference       : r�f�rence de la commande fournie
 *  textelibre      : zone libre pour le commer�ant
 *  coderetour      : r�sultat du paiement
 *  retourPLUS      : informations compl�mentaires optionnelles
 *
 * Param�tres en sortie :
 *  resultat        : AUTHENTIFICATION_OK si les HMAC sont identiques.
 *
 * Retourne TRUE si le TesterMAC() est OK ou une valeur n�gative en cas
 * d'erreur :
 *  PB_PARAM_NULL   : un des param�tres en entr�e est NULL.
 *  PB_ALGO_HMAC    : la m�thode de hachage n'est pas g�r�e.
 *  PB_CONTEXTE_TPE : une erreur est survenue lors de la r�cup�ration de la
 *                    cl� de hachage.
 *  PB_STRING_HEX   : la cl� de hachage n'est pas valide.
 *  PB_CALCUL_HMAC  : une erreur est survenue lors du calcul du hmac.
 *---------------------------------------------------------------------------*/

int TesterHmac (const char* const HMAC,
                const char* const version,
                const char* const tpe,
                const char* const date_commande,
                const char* const montant,
                const char* const reference,
                const char* const textelibre,
                const char* const coderetour,
                const char* const retourPLUS,
                int*              resultat)
{
    char* document = NULL;
    char* hmac     = NULL;
    int   length;
    int   res;

    *resultat = FALSE;

    if (   (!version)
        || (!tpe)
        || (!date_commande)
        || (!montant)
        || (!reference)
        || (!textelibre)
        || (!coderetour)
        || (!retourPLUS)) {
        return PB_PARAM_NULL;
    }

    /* Composer le document � hacher � partir des informations envoy�es par le
     * serveur de la banque */
    length = ConcatString (PAD_CHAR_B2M,
                           &document,
                           retourPLUS,
                           tpe,
                           date_commande,
                           montant,
                           reference,
                           textelibre,
                           version,
                           coderetour,
                           NULL);

    /* Calculer le HMAC */
    res = ComputeHmac(tpe, document, length, &hmac);
    if (res <= 0)
        return res;

    /* Comparer les HMAC en ignorant la casse */
    if (!strcasecmp (HMAC,hmac)) {
        *resultat = AUTHENTIFICATION_OK;
    }

    Free (document);
    Free (hmac);

    return TRUE;
}


/*----------------------------------------------------------------------------*
 * int CreerAccuseReception (const int res_auth, char **reponse)
 *
 * Cette fonction compose le document d'accus� de r�ception � renvoyer � la
 * banque.
 * Voir la documentation technique.
 *
 * Param�tre en entr�e :
 *  res_auth   : r�sultat du contr�le de TesterHmac().
 *
 * Param�tre en sortie :
 *  reponse  : adresse de l'adresse du document � renvoyer.
 *
 * Retourne le nombre de caract�res de la r�ponse (sans le '\0' final).
 *---------------------------------------------------------------------------*/

int CreerAccuseReception (const int res_auth, char** reponse)
{
    int   nb;
    int   length;
    char* cdate;
    char* phrase;

    phrase = (res_auth == AUTHENTIFICATION_OK) ? DOCUMENT_OK
                                               : DOCUMENT_FALSIFIE;
    cdate  = GetDateCommerce();

    /* Majorant de la longueur totale de l'accus� r�ception: format + champs */
    length =   strlen (ACCUSE_RECEPTION)
             + strlen (cdate)
             + strlen (VERSION_REPONSE)
             + strlen (phrase);

    *reponse = StrAllocation(length);

    nb = sprintf(*reponse, ACCUSE_RECEPTION, cdate, VERSION_REPONSE, phrase);

    Free(cdate);
    return nb;
}


/*===========================================================================*
 *
 *                     Fonctions utilis�es dans ce fichier
 *
 *===========================================================================*/

/*----------------------------------------------------------------------------*
 * static char* GetDateCommerce()
 *
 * Cette fonction retourne un pointeur sur une cha�ne de caract�res contenant
 * la date et l'heure syst�me au format "JJ/MM/AAAA:HH:MM:SS".
 *
 * Le format � envoyer dans le champ "date_commerce" est impos� et ne doit pas
 * �tre modifi�.
 *
 * Retourne un pointeur sur une zone de 20 octets (19 caract�res + '\0' final).
 *---------------------------------------------------------------------------*/

static char* GetDateCommerce ()
{
    time_t     now;
    struct tm* tm;
    char*      cdate;    /* Variable retourn�e */

    cdate = StrAllocation(TIMESTAMP_LENGTH);

    /* Date syst�me au format JJ/MM/AAAA:HH:MM:SS  */
    now = time (NULL);
    tm  = localtime (&now);
    sprintf (cdate,
             "%02d/%02d/%04d:%02d:%02d:%02d",
             tm->tm_mday,
             tm->tm_mon+1,
             tm->tm_year + 1900,
             tm->tm_hour,
             tm->tm_min,
             tm->tm_sec);

    return cdate;
}


/*----------------------------------------------------------------------------*
 * static int ComputeHmac(const char* const tpe,
 *                        const char* const data,
 *                        const int         data_size,
 *                        char**            hmac)
 *
 * Cette fonction calcule le HMAC en utilisant la m�thode MD5 ou SHA1 � partir
 * d'un document et des param�tres d'authentification du TPE.
 * Voir la documentation RFC 2104 pour le calcul du HMAC.
 *
 * Param�tres en entr�e :
 *  tpe       : num�ro de TPE fourni par Euro-Information.
 *  data      : un pointeur sur le document � hacher.
 *  data_size : taille du document.
 *
 * Param�tres en sortie :
 *  hmac      : adresse de la cha�ne de caract�res qui contient le HMAC.
 *
 * Retourne la longueur de "hmac" (sans le '\0' final) ou une valeur n�gative
 * en cas d'erreur :
 *  PB_ALGO_HMAC    : la m�thode de hachage n'est pas g�r�e.
 *  PB_CONTEXTE_TPE : une erreur est survenue lors de la r�cup�ration de la
 *                    cl� de hachage.
 *  PB_CALCUL_HMAC  : une erreur est survenue lors du calcul du hmac.
 *---------------------------------------------------------------------------*/

static int ComputeHmac(const char* const tpe,
                       const char* const data,
                       const int         data_size,
                       char**            hmac)
{
    unsigned char  md[EVP_MAX_MD_SIZE];
    unsigned int   size_md;
    int            i;
    unsigned char* result;
    ContexteTPE    context_tpe;
    EVP_MD*        evp;
    int            lg;    /* Valeur retourn�e */

    if (!tpe)
       return PB_CONTEXTE_TPE;

    context_tpe.tpe           = StrDup(tpe);
    context_tpe.methode       = NULL;
    context_tpe.encrypted_key = NULL;

    /* Rechercher la cl� de hachage fournie par Euro-Information sous la
     * forme hexad�cimale */
    if (GetContexteTPE (&context_tpe) != TRUE)
        return PB_CONTEXTE_TPE;

    /* D�terminer la m�thode de MAC � utiliser */
    if (!strcmp (context_tpe.methode, "HMAC-SHA1"))
    {
        evp = EVP_sha1();
    }
    else if (!strcmp(context_tpe.methode,"HMAC-MD5"))
    {
        evp = EVP_md5();
    }
    else
        return PB_ALGO_HMAC;

    /* Appeler la fonction HMAC() de openssl avec le document compos�,
     * la cl� et la m�thode fournie par Euro-Information  */
    result = HMAC (EVP_sha1(),
                   context_tpe.key,
                   context_tpe.key_size,
                   (unsigned char*) data,
                   data_size,
                   md,
                   &size_md);

    /* Par mesure de s�curit�, on supprime imm�diatement la cl� de hachage de
     * la m�moire */
    memset (context_tpe.key, 0, context_tpe.key_size);

    if (!result)
        return PB_CALCUL_HMAC;

    lg    = size_md * 2;
    *hmac = StrAllocation(lg);

    /* Conversion de la cha�ne hexad�cimale en cha�ne de caract�res
     * Exemple : 0x1D 0xcf 0x12 ... devient "1DCF12..." */
    for (i = 0; i < (int)size_md; i++)
        sprintf( ((*hmac)+(i*2)), "%02X", md[i]);

    (*hmac)[lg] = '\0';

    Free (context_tpe.tpe);
    Free (context_tpe.methode);
    Free (context_tpe.encrypted_key);
    Free (context_tpe.key);

    return lg;
}



/*----------------------------------------------------------------------------*
 * static int ConcatString (const char pad, char** document, ... )
 *
 * Cette fonction concat�ne une liste de cha�nes de caract�res (termin�e par
 * NULL) dans la cha�ne "document" en intercalant un caract�re de s�paration
 * entre chaque sous-cha�ne, sauf entre la 1�re et la 2�me.
 *
 * Param�tres en entr�e :
 *   pad       : le caract�re de s�paration.
 *   ...       : la liste des pointeurs sur les cha�nes � concat�ner (le
 *               dernier argument doit �tre NULL).
 *
 * Param�tres en sortie :
 *   document  : un pointeur sur la cha�ne concat�n�e.
 *
 * Retourne la longueur totale de la cha�ne concat�n�e (sans le '\0' final).
 * Retourne une chaine vide si le premier argument apr�s "document" est NULL.
 *---------------------------------------------------------------------------*/

#ifdef WITH_ARG_ANSI
  static int ConcatString (const char pad, char **document, ... )
#else
  static int ConcatString (const char pad, va_alist ) va_dcl
#endif
{
    va_list pa;
    char*   argument;
    char*   init;
    char*   ptr;
    int     length  = 0;
    int     nb_args = 0;

    #ifdef WITH_ARG_ANSI
        va_start (pa, document);
    #else
        char** document;
        va_start (pa);
        document = va_arg(pa, char**);
    #endif

    /* Calculer la longueur de la cha�ne concat�n�e. */
    while ( (argument = va_arg(pa, char*)) ) {
        nb_args++;
        length += Strlen(argument);
        /* On ajoute un pour le pad � partir du deuxi�me argument */
        if(nb_args>1) length++;
    }

    va_end(pa);

    *document = StrAllocation(length);
    ptr       = *document;

    /* Concat�ner les arguments dans document */
    #ifdef WITH_ARG_ANSI
        va_start (pa, document);
    #else
        va_start (pa);
        document = va_arg (pa, char**);
    #endif

    /* Cha�ne d'initialisation (sans caract�re "pad" apr�s) */
    if ( (init = va_arg (pa, char*)) != NULL)
    {
        strcpy (ptr, init);
        ptr += strlen (init);
    }

    /* Arguments suivants */
    while ( (argument = va_arg (pa, char*)) != NULL)
    {
        strcpy (ptr, argument);
        ptr += strlen(argument);
        /* Ajouter le caract�re de s�paration */
        *ptr = pad;
        ptr++;
    }
    va_end (pa);

    *ptr = '\0';

    return (ptr - *document);
}


/*===========================================================================*/
