/*****************************************************************************
 *
 * CM_CIC_Paiement: kit "open source" pour CyberMUT-P@iement(TM) et
 *                  P@iementCIC(TM).
 * Exemple d'int�gration dans un site marchand en langage C/C++.
 *
 * Fichier "fcts_commercant.h" : prototypes des fonctions communes aux
 *            programmes "cgi1_commercant.c" et "cgi2_commercant.c".
 *            Le code source de ces fonctions et les commentaires associ�s se
 *            trouvent dans le fichier "fcts_commercant.c".
 *
 * Auteur   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.0
 * Date     : 18/12/2003
 *
 * Copyright: (c) 2003 Euro-Information. Tous droits r�serv�s.
 * Consulter le document de licence "Licence.txt" joint.
 *
 *****************************************************************************/

#ifndef FCTS_COMMERCANT_H
#define FCTS_COMMERCANT_H


/*===========================================================================*
 *                             Fichiers inclus
 *===========================================================================*/

/* Ce fichier n�cessite les inclusions suivantes:
 *    #include "fcts_util.h"                    \* pour BEGIN_EXTERN_C, etc. *\
 */


/*===========================================================================*
 *                           D�finitions des constantes
 *===========================================================================*/

/*----------------------------------------------------------------------------*
 * Valeurs possibles du code de retour envoy� � CGI2
 *---------------------------------------------------------------------------*/

#define PAIEMENT_PROD_ACCEPTE "paiement" /* Paiement de production accept�
                                          * par la banque                    */
#define PAIEMENT_TEST_ACCEPTE "payetest" /* Paiement de test accept� par la
                                          * banque                           */


/*----------------------------------------------------------------------------*
 * Code de retour des fonctions utilis�es par CGI1 et CGI2
 *---------------------------------------------------------------------------*/

#define PB_PARAM_NULL         -11        /* Param�tre NULL en entr�e de
                                          * TesterHmac()                     */
#define PB_ALGO_HMAC          -12        /* Algorithme de hachage non ger�   */
#define PB_CALCUL_HMAC        -13        /* Erreur lors du calcul du hmac    */
#define PB_DOC_HMAC           -14        /* Erreur lors de la composition du
                                          * document � hacher                */

/*----------------------------------------------------------------------------*
 * Constantes diverses
 *---------------------------------------------------------------------------*/

#define VERSION               "1.2open"  /* Num�ro de version de l'interface */
#define AUTHENTIFICATION_OK   1          /* Valeur du r�sultat de la fonction
                                          * TesterHmac() */


/*===========================================================================*
 *                          D�claration des fonctions
 *===========================================================================*/

BEGIN_EXTERN_C

/*---------------------------------------------------------------------------*
 * Fonctions CyberMUT-P@iement
 *
 *  1. CreerFormulaireHmac  (phase Aller)
 *  2. TesterHmac           (phase Retour)
 *  3. CreerAccuseReception (phase Retour)
 *---------------------------------------------------------------------------*/

int CreerFormulaireHmac  (const char* const url_serveur,
                          const char* const version,
                          const char* const tpe,
                          const char* const montant,
                          const char* const reference,
                          const char* const textelibre,
                          const char* const url_retour,
                          const char* const url_retour_ok,
                          const char* const url_retour_err,
                          const char* const langue,
                          const char* const societe,
                          const char* const textebouton,
                          char**            form);

int TesterHmac           (const char* const HMAC,
                          const char* const version,
                          const char* const tpe,
                          const char* const date_commande,
                          const char* const montant,
                          const char* const reference,
                          const char* const textelibre,
                          const char* const coderetour,
                          const char* const retourPLUS,
                          int*              resultat);

int CreerAccuseReception (const int res_auth, char** reponse);

END_EXTERN_C


/*===========================================================================*/

#endif /* FCTS_COMMERCANT_H */

/*===========================================================================*/
