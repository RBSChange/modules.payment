/*****************************************************************************
 *
 * CM_CIC_Paiement: kit "open source" pour CyberMUT-P@iement(TM) et
 *                  P@iementCIC(TM).
 * Exemple d'int�gration dans un site marchand en langage C/C++.
 *
 * Fichier "fcts_tpe.c" : informations et fonctions relatives au Terminal de
 *            Paiement Electronique (TPE) du commer�ant.
 *
 * Auteur   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.0
 * Date     : 18/12/2003
 *
 * Copyright: (c) 2003 Euro-Information. Tous droits r�serv�s.
 * Consulter le document de licence "Licence.txt" joint.
 *
 *****************************************************************************/

/*----------------------------------------------------------------------------*
 * Les informations relatives au TPE commer�ant contenues dans ce fichier sont
 * n�cessaires � l'authentification du commer�ant aupr�s de la banque.
 *
 * Pour des raisons de s�curit�, il est pr�f�rable de ne pas stocker la cl�
 * de hachage fournie par Euro-Information en clair dans le programme.
 *
 * Dans cet exemple la cl� de hachage fournie par Euro-Information est crypt�e
 * par la bo�te � outils OpenKits "Tools/HMAC-SHA1" qui effectue un "ou
 * exclusif" (xor) entre chaque caract�re de la cl� originale et une phrase de
 * meme longueur.  Le resultat du "ou exclusif" est une seconde cl�, crypt�e.
 *
 * Au moment du calcul du HMAC, la fonction GetCleHmac() est appel�e afin
 * d'obtenir la cl� de hachage fournie par Euro-Information.
 *
 * Par pr�caution, cette cl� est effac�e de la m�moire imm�diatement apr�s
 * avoir �t� utilis�e (dans le calcul du HMAC).
 *
 * Le commer�ant doit mettre en oeuvre sa propre m�thode d'obtention de la
 * cl� de hachage.
 *---------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "fcts_util.h"
#include "fcts_tpe.h"


#define NUMERO_DE_TPE          "1234567"
#define HASH_METHOD            "HMAC-SHA1"
#define ENCRYPTED_KEY          "6480480866315cbf6a735b1842cf175877307b95"

/*
 * Phrase/Mot de passe al�atoire de 20 caract�res affichables calcul�e dans la
 * bo�te � outils OpenKits "Tools/HMAC-SHA1".
 */
#define PASS_PHRASE            "yOugOTtHISpASSpH4ASe"


/*===========================================================================*
 *                     D�claration des fonctions locales
 *===========================================================================*/

static int   ConvertStringToHex (const char* const source,
                                 unsigned char**   result);
static int   IsStringHex        (const char* const source);
static char* GetEncryptedKey    ();
static char* GetPassPhrase      ();


/*===========================================================================*
 *
 *    Fonctions relatives � la r�cup�ration des informations du commer�ant
 *
 *===========================================================================*/

/* IMPORTANT: Dans cet exemple, les informations sont des constantes d�finies
 *            dans ce fichier. Il appartient au commer�ant de stocker en lieu
 *            s�r ces informations (ex: dans une base de donn�e s�curis�e) et
 *            de modifier les fonctions ci-dessous pour r�cup�rer ces
 *            informations en fonction des outils de stockage d'�l�ments de
 *            s�curit� qu'il peut mettre en oeuvre.
 */

/*----------------------------------------------------------------------------*
 * char* GetTpeNumber ()
 *
 * Cette fonction retourne le num�ro de TPE du commer�ant sous forme d'une
 * cha�ne de 7 caract�res.
 *---------------------------------------------------------------------------*/

char* GetTpeNumber (void)
{
    return NUMERO_DE_TPE;
}


/*----------------------------------------------------------------------------*
 * static char* GetEncryptedKey ()
 *
 * Cette fonction retourne la cl� du commer�ant sous forme encrypt�e.
 *---------------------------------------------------------------------------*/

static char* GetEncryptedKey ()
{
    return ENCRYPTED_KEY;
}


/*----------------------------------------------------------------------------*
 * static char* GetPassPhrase ()
 *
 * Cette fonction retourne la pass phrase du commer�ant.
 *---------------------------------------------------------------------------*/

static char* GetPassPhrase ()
{
    return PASS_PHRASE;
}


/*===========================================================================*
 *
 *                  Fonctions relatives � la cl� de hachage
 *
 *===========================================================================*/

/*----------------------------------------------------------------------------*
 * int GetContexteTPE (ContexteTPE *context_tpe)
 *
 * Cette fonction permet de retrouver la cl� de hachage fournie par
 * Euro-Information par d�cryptage des informations fournies par la bo�te �
 * outils OpenKits "Tools/HMAC-SHA1".
 *
 * Param�tre en entr�e / sortie :
 *  context_tpe : pointeur sur la structure � renseigner. Le champ "tpe" doit
 *                �tre renseign�.
 *
 * Retourne TRUE si les informations sont retrouv�es ou une valeur n�gative
 * en cas d'erreur :
 *  PB_CONTEXTE_TPE : probl�me relatif au num�ro de TPE.
 *---------------------------------------------------------------------------*/

int GetContexteTPE (ContexteTPE *context_tpe)
{
    char* pass_phrase;
    int   i = 0;

    if (context_tpe == NULL)
        return PB_CONTEXTE_TPE;

    /* Initialisation (pour avoir une strucure propre en cas de probl�me) */
    context_tpe->methode       = NULL;
    context_tpe->encrypted_key = NULL;
    context_tpe->key           = NULL;
    context_tpe->key_size      = 0;

    /* V�rification du num�ro de TPE */
    if ( (!context_tpe->tpe) || (strcmp(NUMERO_DE_TPE, context_tpe->tpe)) )
        return PB_CONTEXTE_TPE;

    /* Chargement des donn�es du commer�ant */
    context_tpe->methode       = StrDup (HASH_METHOD);
    context_tpe->encrypted_key = StrDup (GetEncryptedKey());
    pass_phrase                = GetPassPhrase();

    /* Convertir la cl� de hachage crypt�e en cha�ne hexad�cimale */
    context_tpe->key_size = ConvertStringToHex (context_tpe->encrypted_key,
                                                &context_tpe->key);

    if (context_tpe->key_size <= 0)
        return context_tpe->key_size;

    /* D�crypter avec le mot de passe afin d'obtenir la cl� primaire */
    while ( (i < context_tpe->key_size) && (pass_phrase[i]) )
    {
        context_tpe->key[i] ^= pass_phrase[i];
        i++;
    }

    return TRUE;
}


/*----------------------------------------------------------------------------*
 * static int ConvertStringToHex (const char* const source,
 *                                unsigned char**   result)
 *
 * Cette fonction convertit la cha�ne source en cha�ne hexad�cimale.
 * Exemple : "1D00CF12..." devient 0x1d 0x00 0xcf 0x12 ...
 *
 * Si la longueur de source est impaire alors le premier caract�re est
 * converti seul. Exemple : "ABC" devient 0x0a 0xbc.
 *
 * Param�tre en entr�e :
 *   source : pointeur sur la cha�ne � convertir.
 *
 * Param�tre en sortie :
 *   result : pointeur sur la cl� sous forme hexad�cimale.
 *
 * Retourne la longueur de la cha�ne hexad�cimale ou une valeur n�gative en
 * cas d'erreur :
 *   PB_STRING_HEX : la cha�ne en entr�e n'est pas hexad�cimale.
 *---------------------------------------------------------------------------*/

static int ConvertStringToHex (const char* const source,
                               unsigned char**   result)
{
    char cc[2];
    int  size_source;
    int  y;                   /* Indice sur la cha�ne source                */
    int  x;                   /* Indice sur la cha�ne hexad�cimale "result" */

    /* source est NULL ou non hexad�cimale */
    if ( !IsStringHex (source) )
        return PB_STRING_HEX;

    size_source = Strlen (source);

    /* Allouer (size_source / 2) +1 caract�res */
    *result  = (unsigned char*) StrAllocation (size_source / 2);

    /* size_source est impaire */
    if (size_source % 2)
    {
        /* Convertir le premier caract�re */
        cc[0] = source[0];
        cc[1] = '\0';
        **result = x2c(cc);
        /* Continuer la conversion � partir du caract�re suivant */
        x = y = 1;
    }
    else
        x = y = 0;

    /* Convertir les caract�res suivants par groupe de deux caract�res */
    for( ; y < size_source ; x++, y+=2)
        (*result)[x] = x2c(&source[y]);

    return x;
}


/*----------------------------------------------------------------------------*
 * static int IsStringHex (const char* const source)
 *
 * Cette fonction teste si la cha�ne de caract�res "source" est exclusivement
 * compos�e de chiffres hexadecimaux.
 *
 * Param�tres en entr�e :
 *   source : la cha�ne de caract�res � tester (doit �tre non NULL).
 *
 * Retourne TRUE si la cha�ne "source" est hexad�cimale et FALSE sinon.
 *---------------------------------------------------------------------------*/

static int IsStringHex (const char* const source)
{
    int length, x;

    if ( (length = Strlen(source)) == 0)
        return FALSE;

    for (x = 0; x < length; x++)
    {
        if (!isxdigit (source[x]))
            return FALSE;
    }
    return TRUE;
}


/*===========================================================================*/
