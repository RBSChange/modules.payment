/*****************************************************************************
 *
 * CM_CIC_Paiement: kit "open source" pour CyberMUT-P@iement(TM) et
 *                  P@iementCIC(TM).
 * Exemple d'int�gration dans un site marchand en langage C/C++.
 *
 * Fichier "fcts_tpe.h" : prototypes des fonctions relatives au Terminal de
 *            Paiement Electronique (TPE) du commer�ant.
 *            Le code source de ces fonctions et les commentaires associ�s se
 *            trouvent dans le fichier "fcts_tpe.c".
 *
 * Auteur   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.0
 * Date     : 18/12/2003
 *
 * Copyright: (c) 2003 Euro-Information. Tous droits r�serv�s.
 * Consulter le document de licence "Licence.txt" joint.
 *
 *****************************************************************************/

/* Pour des raisons de s�curit�, il est pr�f�rable de ne pas stocker la cl�
 * de hachage fournie par Euro-Information en clair dans le programme.
 *
 * Dans cet exemple la cl� de hachage fournie par Euro-Information est crypt�e
 * par la bo�te � outils "Tools/HMAC-SHA1" qui effectue un "ou exclusif" (xor)
 * entre chaque caract�re de la cl� originale (de 20 octets) et une phrase de
 * 20 caract�res. Le resultat du "ou exclusif" est une seconde cl�, crypt�e.
 *
 * Le commer�ant doit g�rer sa propre m�thode d'obtention de la cl� de
 * hachage.
 */


#ifndef FCTS_TPE_H
#define FCTS_TPE_H

/*===========================================================================*
 *                             Fichiers inclus
 *===========================================================================*/

/* Ce fichier n�cessite les inclusions suivantes:
 *    #include "fcts_util.h"                    \* pour BEGIN_EXTERN_C, etc. *\
 */


/*===========================================================================*
 *                           D�finitions des constantes
 *===========================================================================*/

/*----------------------------------------------------------------------------*
 * Code de retour des fonctions utilis�es par CGI1 et CGI2
 *---------------------------------------------------------------------------*/

#define PB_STRING_HEX         -21        /* Cl� de hachage non hexad�cimale  */
#define PB_CONTEXTE_TPE       -22        /* Erreur lors du d�cryptage de la
                                          * cl� de hachage                   */

/*===========================================================================*
 *                           D�finitions des types
 *===========================================================================*/

/*----------------------------------------------------------------------------*
 * La structure ContexteTPE contient les informations relatives au TPE.
 * Le commer�ant doit g�rer la m�thode d'obtention de ces donn�es.
 *---------------------------------------------------------------------------*/

typedef struct
{
    char*          tpe;         /* Num�ro de TPE virtuel */
    char*          methode;     /* M�thode de hachage: HMAC-SHA1 ou HMAC-MD5 */
    int            key_size;    /* Taille de la cl� hexad�cimale             */
    char*          encrypted_key;  /* Cl� de hachage crypt�e, "seconde cl�"  */
    unsigned char* key;         /* Cl� de hachage binaire                    */
} ContexteTPE;


/*===========================================================================*
 *                          D�claration des fonctions
 *===========================================================================*/

BEGIN_EXTERN_C

char* GetTpeNumber   ();
int   GetContexteTPE (ContexteTPE* context_tpe);

END_EXTERN_C


/*===========================================================================*/

#endif /* FCTS_TPE_H */

/*===========================================================================*/
