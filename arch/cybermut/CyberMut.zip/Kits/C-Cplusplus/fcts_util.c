/*****************************************************************************
 *
 * CM_CIC_Paiement: kit "open source" pour CyberMUT-P@iement(TM) et
 *                  P@iementCIC(TM).
 * Exemple d'int�gration dans un site marchand en langage C/C++.
 *
 * Fichier "fcts_util.c" : fonctions utilitaires diverses.
 *
 * Auteur   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.0
 * Date     : 18/12/2003
 *
 * Copyright: (c) 2003 Euro-Information. Tous droits r�serv�s.
 * Consulter le document de licence "Licence.txt" joint.
 *
 *****************************************************************************/

/*===========================================================================*
 *                             Fichiers inclus
 *===========================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

#ifndef MACOS
#  include <malloc.h>
#  include <sys/types.h>
#  include <sys/stat.h>
#endif

#include "fcts_util.h"


/*===========================================================================*
 *
 *                     Fonctions relatives � la m�moire
 *
 *===========================================================================*/

/*----------------------------------------------------------------------------*
 * char* Malloc (const int nbr)
 *
 * Cette fonction alloue un espace m�moire de "nbr" octets, comme malloc(),
 * mais elle v�rifie en plus que l'allocation s'est bien d�roul�.
 *
 * Param�tre en entr�e :
 *   nbr : nombre d'octets � allouer.
 *
 * Retourne un pointeur sur la zone m�moire allou�e.
 * ATTENTION : Arr�t du programme avec le code de retour 1 si l'allocation
 *             �choue.
 *---------------------------------------------------------------------------*/

char* Malloc (const int nbr)
{
    char* result;

    result = (char*) malloc (nbr);
    if (result == NULL)
    {
        fputs ("Probl�me d'allocation m�moire.\n", stderr);
        exit (1);
    }
    return result;
}



/*===========================================================================*
 *
 *                Fonctions relatives aux cha�nes de caract�res
 *
 *===========================================================================*/

/*----------------------------------------------------------------------------*
 * char* StrDup (const char* const txt)
 *
 * Cette fonction copie la cha�ne de caract�res point�e par "txt" dans une
 * nouvelle cha�ne de caract�res et retourne un pointeur dessus.
 * Si "txt" est NULL, StrDup() retourne un pointeur sur une cha�ne initialis�e
 * � '\0'.
 *
 * Param�tres en entr�e :
 *   txt : pointeur sur la cha�ne de caract�res � copier.
 *
 * Retourne un pointeur (toujours non NULL) sur la nouvelle cha�ne de
 * caract�res.
 *---------------------------------------------------------------------------*/

char* StrDup (const char* const txt)
{
    int   length;
    char* result;

    length = Strlen(txt);
    result = StrAllocation(length);

    if (length)
    {
        strcpy (result, txt);
    }
    else
    {
        result[0] = '\0';
    }

    return result;
}



/*===========================================================================*
 *
 *                  Fonctions relatives au codage hexad�cimal
 *
 *===========================================================================*/

/*----------------------------------------------------------------------------*
 * unsigned char x2c (const char* const what)
 *
 * Cette fonction convertit une cha�ne de un ou deux chiffres hexad�cimaux
 * en un entier sur un octet.
 * Les �ventuels caract�res suivants sont ignor�s.
 *
 * Param�tres en entr�e :
 *   what : pointeur sur les caract�res hexad�cimaux � convertir.
 *
 * Retourne la valeur correspondant au code hexad�cimal.
 * ATTENTION : retourne un espace si la cha�ne n'est pas valide.
 *---------------------------------------------------------------------------*/

unsigned char x2c (const char* const what)
{
    unsigned char digit;

    if ((!what) || (!isxdigit(what[0])))
        return ' ';

    digit = (what[0] >= 'A' ? (toupper(what[0]) - 'A')+10 : (what[0] - '0'));

    if (what[1] == '\0')
        return digit;

    if (!isxdigit(what[1]))
        return ' ';

    digit *= 16;
    digit += (what[1] >= 'A' ? (toupper(what[1]) - 'A')+10 : (what[1] - '0'));

    return (digit);
}


/*===========================================================================*/
