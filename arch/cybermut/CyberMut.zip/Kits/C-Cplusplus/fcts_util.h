/*****************************************************************************
 *
 * CM_CIC_Paiement: kit "open source" pour CyberMUT-P@iement(TM) et
 *                  P@iementCIC(TM).
 * Exemple d'int�gration dans un site marchand en langage C/C++.
 *
 * Fichier "fcts_util.h" : d�finition et prototypes de fonctions utilitaires
 *            diverses.
 *            Le code source de ces fonctions et les commentaires associ�s se
 *            trouvent dans le fichier "fcts_util.c".
 *
 * Auteur   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
 * Version  : 1.0
 * Date     : 18/12/2003
 *
 * Copyright: (c) 2003 Euro-Information. Tous droits r�serv�s.
 * Consulter le document de licence "Licence.txt" joint.
 *
 *****************************************************************************/

#ifndef FCTS_UTIL_H
#define FCTS_UTIL_H


/*===========================================================================*
 *                           D�finitions des constantes
 *===========================================================================*/

/*----------------------------------------------------------------------------*
 * Bool�ens
 *---------------------------------------------------------------------------*/

#ifndef FALSE
#  define FALSE                0
#endif
#ifndef TRUE
#  define TRUE                 1
#endif


/*===========================================================================*
 *                           D�finitions des macros
 *===========================================================================*/

/*----------------------------------------------------------------------------*
 * StrAllocation(): alloue un espace m�moire de n+1 caract�res pour une cha�ne
 *                  de n caract�res plus le '\0' final. Provoque l'arr�t du
 *                  programme si l'allocation �choue.
 *---------------------------------------------------------------------------*/
#define StrAllocation(n)      Malloc(n * sizeof(char) + 1)


/*----------------------------------------------------------------------------*
 * Strlen(): retourne la longueur de la cha�ne en entr�e comme strlen(),
 *           mais retourne 0 si le pointeur en entr�e est NULL.
 *---------------------------------------------------------------------------*/
#define Strlen(s)             s == NULL ? 0 : strlen (s)


/*----------------------------------------------------------------------------*
 * Free(): effectue une lib�ration de la m�moire comme free(), mais fonctionne
 *         m�me si p est NULL.
 *---------------------------------------------------------------------------*/
#define Free(p)               if (p != NULL) free(p)


/*----------------------------------------------------------------------------*
 * D�finitions relatives � la compatiblit� avec C++
 *---------------------------------------------------------------------------*/

#ifdef __cplusplus
#  define BEGIN_EXTERN_C      extern "C" {
#  define END_EXTERN_C        }
#else
#  define BEGIN_EXTERN_C
#  define END_EXTERN_C
#endif


/*----------------------------------------------------------------------------*
 * Correction du nom d'une fonction qui est diff�rent sous Windows et Unix.
 *---------------------------------------------------------------------------*/

#ifdef _WIN32
#  define strcasecmp stricmp
#endif


/*===========================================================================*
 *                          D�claration des fonctions
 *===========================================================================*/

BEGIN_EXTERN_C

char*         Malloc (const int nbr);
char*         StrDup (const char* const txt);
unsigned char x2c    (const char* const what);

END_EXTERN_C


/*===========================================================================*/

#endif /* FCTS_UTIL_H */

/*===========================================================================*/
