#
# Reads STDIN input and sends it to CGI2
# usage:
#      cat <filename> | perl test.pl
#   or echo "request" | perl test.pl
#   or make test
#
use HTTP::Request::Common;
use LWP::UserAgent;

my $url      = 'http://localhost/cgi-bin/cgi2_commercant.cgi';
my $ua       = LWP::UserAgent->new();
my $body     = join "", <STDIN>;
my $document = $url . '?' . $body;
my $request  = HTTP::Request->new('GET', $document);
my $response = $ua->request($request);
print $response->content;
