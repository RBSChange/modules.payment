#!/bin/sh
#

export REQUEST_METHOD=GET
export QUERY_STRING=$1
# echo QUERY_STRING=$QUERY_STRING

echo 
./cgi2_commercant.cgi
echo 
echo 

