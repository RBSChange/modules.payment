#==============================================================================
#
# CM_CIC_Paiement: "open source" kit for CyberMUT-P@iement(TM) and
#                  P@iementCIC(TM).
# Integration samples for PHP4 environment.
#
# Author   : Euro-Information/e-Commerce (contact: centrecom@e-i.com)
# Version  : 1.0
# Date     : 18/12/2003
#
# Copyright: (c) 2003 Euro-Information. All rights reserved.
# License  : see attached document "License.txt".
#
#==============================================================================

Message Authentication Code RFC2104 compliant 
(http://www.ietf.org/rfc/rfc2104.txt).
Underlying Hash Method: SHA1, requires PHP >= 4.3.0

#------------------------------------------------------------------------------

That is Merchant's responsibility to store provided keys safe and
secure. If necessary, before production step, the merchant will ask
Euro-Information for a new Key generation.

#------------------------------------------------------------------------------

===========
PHP samples
===========

Please Refer to "Specifications Techniques" (in french, attached).
"Tools" folder contains a tool to help you for customing this kit.

After customization :
  - Transfer (FTP) "www" directory content on your Web Server
  - Transfer "php-include" content in your include directory 


CAUTION: After FTP transfer:

  - Rename "aRenommerResultat.php" into "somethingYouWant.php".
    Make sure the directory where you put it is not browsable by the
    server.

  - Customize the ".inc.php" files with your own configuration (refer
    to "Tools" folder).

Nothing else to do for a first test play.
Page "CheckoutStub.html" will target the payment page.

After such a successfull stand-alone payment, in a second step, you
will reuse this customized code to add payment button to your basket
application :
  
  - Get order datas from your context
  - Get config datas : 
    you have to rewrite some ".inc.php" code to get critical datas
    from merchant database instead of source initialization.
  - Call form builder (including hmac-sha1 authentication function).
  - Write the HTML form which will offer the visible "Payment" button.

Our server will post payment result datas to URL targeting the script
(to be renamed) "aRenommerResultat.php": don't change these datas.
Insert your code after the RFC2104 authentication steps, when
$Verified_Result value has been set.

#==============================================================================
Copyright (c) 2003 Euro-Information (centrecom@e-i.com). All rights reserved.