
 This is the 1.03j version of "CM_CIC_Paiement" interface.



 - Choose your sample Kit in the corresponding folder, depending on the 
   programming language supported by your e-commerce server. 

   Please read carefully, documentation and licenses.


 - Download your merchant key from download link sent by e-mail, 
   for SSL download with user authentication, and then use :

       extract2hmacSha1.html from "Tools/HMAC-SHA1" folder

    or extract2hmacMd5.html  from "Tools/HMAC-MD5"  folder

   depending on SHA1 or MD5 Key underlying hash method.


 - Configure your kit for an instant test.



 Without merchant key, you may evaluate the complete integration
 process (with the "try with a dummy key" option) but not inter-operate
 with our test servers.

 For a production integration, you must refer to the Technical
 Documentation (in French).

 Note: Euro-Information does not provide person-to-person technical
       support for tryout of CM_CIC_Paiement kits. We do however
       welcome your feedback which can be sent to <centrecom@e-i.com>.
