This .zip file contains the SHA-1 .dll file and some sample scripts to use SHA1 for your online payments. Please note that these have been made for a windows2000 server using ASP. Due to the fact that there are many possible combinations of operating systems (version-numbers/patches) and programming languages we can't be held responsible for any errors on your server during installation and/or processing. 

These files are supplied 'as is' without any support.

