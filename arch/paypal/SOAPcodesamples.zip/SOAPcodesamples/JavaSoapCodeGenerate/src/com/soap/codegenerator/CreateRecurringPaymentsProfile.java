/*
 * Copyright 2005, 2008 PayPal, Inc. All Rights Reserved.
 */

import java.util.Calendar;

import com.paypal.sdk.exceptions.PayPalException;
import com.paypal.sdk.profiles.APIProfile;
import com.paypal.sdk.profiles.ProfileFactory;
import com.paypal.sdk.services.CallerServices;
import com.paypal.soap.api.*;

/**
 * PayPal Java SDK sample application
 */
public class CreateRecurringPaymentsProfile {
	CallerServices caller;

    public static void main(String[] args) {
    	try {
    		CreateRecurringPaymentsProfile sample = new CreateRecurringPaymentsProfile();
    		sample.run();
		}
    	catch (Exception e) {
    		System.out.println("ERROR: " + e.getMessage());
		}
    }

    public CreateRecurringPaymentsProfile() throws PayPalException {
    	caller = new CallerServices();

    	/*
    	 WARNING: Do not embed plaintext credentials in your application code.
    	 Doing so is insecure and against best practices.
    	 Your API credentials must be handled securely. Please consider
    	 encrypting them for use in any production environment, and ensure
    	 that only authorized individuals may view or modify them.
    	 */

    	APIProfile profile = ProfileFactory.createSignatureAPIProfile();
		profile.setAPIUsername("sdk-three_api1.sdk.com");
		profile.setAPIPassword("QFZCWN5HZM8VBG7Q");
		profile.setSignature("AVGidzoSQiGWu.lGj3z15HLczXaaAcK6imHawrjefqgclVwBe8imgCHZ");
		profile.setEnvironment("sandbox");
    	caller.setAPIProfile(profile);
    }

    public void run() throws PayPalException {

		callCreateRecurringPaymentsProfileAPI();
		System.out.println("\nDone...");
    }



    public void callCreateRecurringPaymentsProfileAPI() throws PayPalException {
    	System.out.println("\n########## Starting CreateRecurringPaymentsProfile ##########\n");

    	//Replace the token value by actual value returned vy SetCustomerBillingAgreementAPI call
        String token="RP-8P463231B6009345R";
        String amount ="25.00";
        int BF=1;
        BillingPeriodType BP = BillingPeriodType.Day;

    	CreateRecurringPaymentsProfileRequestType request=new CreateRecurringPaymentsProfileRequestType();
    	CreateRecurringPaymentsProfileResponseType response=new CreateRecurringPaymentsProfileResponseType();
    	request.setVersion("51.0");
		request.setCreateRecurringPaymentsProfileRequestDetails(new CreateRecurringPaymentsProfileRequestDetailsType())  ;
		request.getCreateRecurringPaymentsProfileRequestDetails().setToken(token);
		request.getCreateRecurringPaymentsProfileRequestDetails().setRecurringPaymentsProfileDetails(new RecurringPaymentsProfileDetailsType());

		Calendar start_date = Calendar.getInstance();
		start_date.set(2008,5,30);

		request.getCreateRecurringPaymentsProfileRequestDetails().getRecurringPaymentsProfileDetails().setBillingStartDate(start_date);
		request.getCreateRecurringPaymentsProfileRequestDetails().setScheduleDetails(new ScheduleDetailsType());
		request.getCreateRecurringPaymentsProfileRequestDetails().getScheduleDetails().setPaymentPeriod(new BillingPeriodDetailsType());
		request.getCreateRecurringPaymentsProfileRequestDetails().getScheduleDetails().setDescription("RP-Test- Java SOAP SDK");
		request.getCreateRecurringPaymentsProfileRequestDetails().getScheduleDetails().getPaymentPeriod().setAmount(new BasicAmountType());
		request.getCreateRecurringPaymentsProfileRequestDetails().getScheduleDetails().getPaymentPeriod().getAmount().set_value(amount) ;
		request.getCreateRecurringPaymentsProfileRequestDetails().getScheduleDetails().getPaymentPeriod().getAmount().setCurrencyID(CurrencyCodeType.USD);
		request.getCreateRecurringPaymentsProfileRequestDetails().getScheduleDetails().getPaymentPeriod().setBillingFrequency(BF);
		request.getCreateRecurringPaymentsProfileRequestDetails().getScheduleDetails().getPaymentPeriod().setBillingPeriod(BP);

		response = (CreateRecurringPaymentsProfileResponseType) caller.call("CreateRecurringPaymentsProfile", request);

		if (!response.getAck().equals(AckCodeType.Success) && !response.getAck().equals(AckCodeType.SuccessWithWarning)) {
			// do error processing
			System.out.println("\n########## CreateRecurringPaymentsProfile call failed ##########\n");
		} else {
			//success
			System.out.println("\n########## CreateRecurringPaymentsProfile call passed ##########\n");
		}


    }


}