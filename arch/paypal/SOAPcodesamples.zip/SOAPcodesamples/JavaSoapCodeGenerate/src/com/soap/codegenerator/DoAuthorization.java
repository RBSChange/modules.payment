/*
 * Copyright 2005, 2008 PayPal, Inc. All Rights Reserved.
 *
 * DoAuthorization SOAP example; last modified 08MAY23. 
 *
 * Authorize a payment.  
 */
package com.soap.codegenerator;

import com.paypal.sdk.profiles.APIProfile;
import com.paypal.sdk.profiles.ProfileFactory;
import com.paypal.soap.api.BasicAmountType;
import com.paypal.soap.api.CurrencyCodeType;
import com.paypal.soap.api.DoAuthorizationRequestType;
import com.paypal.soap.api.DoAuthorizationResponseType;
import com.paypal.sdk.services.CallerServices;
/**
 * PayPal Java SDK sample code
 */
public class DoAuthorization 
{
	
	public String DoAuthorizationCode(String orderId, String value, String currencyId)
	{
	
		String responseValue = null;
		try
		{
			CallerServices caller = new CallerServices();
			APIProfile profile = ProfileFactory.createSignatureAPIProfile();
			/*
			 WARNING: Do not embed plaintext credentials in your application code.
			 Doing so is insecure and against best practices.
			 Your API credentials must be handled securely. Please consider
			 encrypting them for use in any production environment, and ensure
			 that only authorized individuals may view or modify them.
			 */

		// Set up your API credentials, PayPal end point, and API version.
			profile.setAPIUsername("sdk-three_api1.sdk.com");
			profile.setAPIPassword("QFZCWN5HZM8VBG7Q");
			profile.setSignature("AVGidzoSQiGWu.lGj3z15HLczXaaAcK6imHawrjefqgclVwBe8imgCHZ");
			profile.setEnvironment("sandbox");
			caller.setAPIProfile(profile);
			
			DoAuthorizationRequestType pp_request = new DoAuthorizationRequestType();
			pp_request.setVersion("51.0");

		// Add request-specific fields to the request.
			DoAuthorizationResponseType pp_response=new DoAuthorizationResponseType();
			pp_request.setTransactionID(orderId);
			BasicAmountType amtType = new BasicAmountType();
			amtType.set_value(value);
			amtType.setCurrencyID(CurrencyCodeType.fromString(currencyId));
			pp_request.setAmount(amtType);

		// Execute the API operation and obtain the response.
			pp_response= (DoAuthorizationResponseType) caller.call("DoAuthorization", pp_request);
			responseValue = pp_response.getAck().toString();
			
		}catch (Exception ex)
		{
			ex.printStackTrace();
		}
		return responseValue;
		
	}
}
