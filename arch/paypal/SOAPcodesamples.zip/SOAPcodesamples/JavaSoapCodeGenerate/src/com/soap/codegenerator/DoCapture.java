/*
 * Copyright 2005, 2008 PayPal, Inc. All Rights Reserved.
 *
 * DoCapture SOAP example; last modified 08MAY23. 
 *
 * Capture a payment.  
 */
package com.soap.codegenerator;

import com.paypal.sdk.profiles.APIProfile;
import com.paypal.sdk.profiles.ProfileFactory;
import com.paypal.sdk.services.CallerServices;
import com.paypal.soap.api.BasicAmountType;
import com.paypal.soap.api.CompleteCodeType;
import com.paypal.soap.api.CurrencyCodeType;
import com.paypal.soap.api.DoCaptureRequestType;
import com.paypal.soap.api.DoCaptureResponseType;
/**
 * PayPal Java SDK sample code
 */

public class DoCapture 
{
	
	public String DoCaptureCode(String authorizationId, String note, String value,
								String currencyId, String invoiceId, String completeCodeType)
	{
		String responseValue = null;
		
		try
		{
			CallerServices caller = new CallerServices();
			APIProfile profile = ProfileFactory.createSignatureAPIProfile();
			/*
			 WARNING: Do not embed plaintext credentials in your application code.
			 Doing so is insecure and against best practices.
			 Your API credentials must be handled securely. Please consider
			 encrypting them for use in any production environment, and ensure
			 that only authorized individuals may view or modify them.
			 */

		// Set up your API credentials, PayPal end point, and API version.
			profile.setAPIUsername("sdk-three_api1.sdk.com");
			profile.setAPIPassword("QFZCWN5HZM8VBG7Q");
			profile.setSignature("AVGidzoSQiGWu.lGj3z15HLczXaaAcK6imHawrjefqgclVwBe8imgCHZ");
			profile.setEnvironment("sandbox");
			caller.setAPIProfile(profile);
	
			DoCaptureRequestType pp_request = new DoCaptureRequestType();
			pp_request.setVersion("51.0");

		// Add request-specific fields to the request.
			DoCaptureResponseType pp_response =new DoCaptureResponseType();
			pp_request.setAuthorizationID(authorizationId);
			pp_request.setNote(note);
			BasicAmountType amtType = new BasicAmountType();
			amtType.set_value(value);
			amtType.setCurrencyID(CurrencyCodeType.fromString(currencyId));
			pp_request.setAmount(amtType);
			pp_request.setInvoiceID(invoiceId);
			pp_request.setCompleteType(CompleteCodeType.fromString(completeCodeType));

		// Execute the API operation and obtain the response.
			pp_response= (DoCaptureResponseType)  caller.call("DoCapture", pp_request);
			responseValue = pp_response.getAck().toString();
			
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		return responseValue;
		 
	}

	
}
