/*
 * Copyright 2005, 2008 PayPal, Inc. All Rights Reserved.
 *
 * GetExpressCheckoutDetails SOAP example; last modified 08MAY23. 
 *
 * Get information about an Express Checkout transaction.  
 */
package com.soap.codegenerator;

import com.paypal.sdk.profiles.APIProfile;
import com.paypal.sdk.profiles.ProfileFactory;
import com.paypal.sdk.services.CallerServices;
import com.paypal.soap.api.GetExpressCheckoutDetailsRequestType;
import com.paypal.soap.api.GetExpressCheckoutDetailsResponseType;
/**
 * PayPal Java SDK sample code
 */
public class ECGetExpressCheckout 
{
	
	public String ECGetExpressCheckoutCode(String token)
	{
		String responseValue = null;
		CallerServices caller = new CallerServices();
		try 
		{
			APIProfile profile = ProfileFactory.createSignatureAPIProfile();
			/*
			 WARNING: Do not embed plaintext credentials in your application code.
			 Doing so is insecure and against best practices.
			 Your API credentials must be handled securely. Please consider
			 encrypting them for use in any production environment, and ensure
			 that only authorized individuals may view or modify them.
			 */

		// Set up your API credentials, PayPal end point, and API version.
			profile.setAPIUsername("sdk-three_api1.sdk.com");
			profile.setAPIPassword("QFZCWN5HZM8VBG7Q");
			profile.setSignature("AVGidzoSQiGWu.lGj3z15HLczXaaAcK6imHawrjefqgclVwBe8imgCHZ");
			profile.setEnvironment("sandbox");
			caller.setAPIProfile(profile);
			
			GetExpressCheckoutDetailsRequestType pprequest = new GetExpressCheckoutDetailsRequestType();
			pprequest.setVersion("51.0");

		// Add request-specific fields to the request.
			pprequest.setToken(token); // Pass the token value returned in SetExpressCheckout.

		// Execute the API operation and obtain the response.
			GetExpressCheckoutDetailsResponseType ppresponse = (GetExpressCheckoutDetailsResponseType)caller.call("GetExpressCheckoutDetails", pprequest);
			responseValue = ppresponse.getAck().toString();
				
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return responseValue;
	}
}
