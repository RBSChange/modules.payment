/*
 * Copyright 2005, 2008 PayPal, Inc. All Rights Reserved.
 */
package com.soap.codegenerator;

import com.paypal.sdk.profiles.APIProfile;
import com.paypal.sdk.profiles.ProfileFactory;
import com.paypal.sdk.services.CallerServices;
import com.paypal.soap.api.GetBalanceRequestType;
import com.paypal.soap.api.GetBalanceResponseType;
/**
 * PayPal Java SDK sample code
 */
public class GetBalance 
{

		
	public String GetBalanceCode()
	{
		CallerServices caller = new CallerServices();
		String responseValue = null;
		
		try
		{
			
			APIProfile profile = ProfileFactory.createSignatureAPIProfile();
			/*
			 WARNING: Do not embed plaintext credentials in your application code.
			 Doing so is insecure and against best practices.
			 Your API credentials must be handled securely. Please consider
			 encrypting them for use in any production environment, and ensure
			 that only authorized individuals may view or modify them.
			 */
			profile.setAPIUsername("sdk-three_api1.sdk.com");
			profile.setAPIPassword("QFZCWN5HZM8VBG7Q");
			profile.setSignature("AVGidzoSQiGWu.lGj3z15HLczXaaAcK6imHawrjefqgclVwBe8imgCHZ");
			profile.setEnvironment("sandbox");
			caller.setAPIProfile(profile);			
			GetBalanceRequestType pp_request=new GetBalanceRequestType();
			pp_request.setVersion("51.0");
			GetBalanceResponseType pp_response=new GetBalanceResponseType();
			pp_response= (GetBalanceResponseType) caller.call("GetBalance", pp_request);
			responseValue = pp_response.getAck().toString();
			
		}catch (Exception ex)
		{
			ex.printStackTrace();
		}
			return responseValue;
	}
}
