/*
 * Copyright 2005, 2008 PayPal, Inc. All Rights Reserved.
 *
 * GetTransactionDetails SOAP example; last modified 08MAY23. 
 *
 * Get detailed information about a single transaction.  
 */
package com.soap.codegenerator;

import com.paypal.sdk.profiles.APIProfile;
import com.paypal.sdk.profiles.ProfileFactory;
import com.paypal.sdk.services.CallerServices;
import com.paypal.soap.api.GetTransactionDetailsRequestType;
import com.paypal.soap.api.GetTransactionDetailsResponseType;
/**
 * PayPal Java SDK sample code
 */
public class GetTransactionDetails 
{

	public String getTransactionDetailsCode(String transactionId)
	{
		CallerServices caller = new CallerServices();
		String responseValue = null;
		try {
				
			APIProfile profile = ProfileFactory.createSignatureAPIProfile();
			/*
			 WARNING: Do not embed plaintext credentials in your application code.
			 Doing so is insecure and against best practices.
			 Your API credentials must be handled securely. Please consider
			 encrypting them for use in any production environment, and ensure
			 that only authorized individuals may view or modify them.
			 */

		// Set up your API credentials, PayPal end point, and API version.
			profile.setAPIUsername("sdk-three_api1.sdk.com");
			profile.setAPIPassword("QFZCWN5HZM8VBG7Q");
			profile.setSignature("AVGidzoSQiGWu.lGj3z15HLczXaaAcK6imHawrjefqgclVwBe8imgCHZ");
			profile.setEnvironment("sandbox");
			caller.setAPIProfile(profile);
			
			GetTransactionDetailsRequestType pprequest = new GetTransactionDetailsRequestType();
			pprequest.setVersion("51.0");

		// Add request-specific fields to the request.
			pprequest.setTransactionID(transactionId);

		// Execute the API operation and obtain the response.
			GetTransactionDetailsResponseType ppresponse = 
			(GetTransactionDetailsResponseType) caller.call("GetTransactionDetails", pprequest);
			responseValue = ppresponse.getAck().toString();
				
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		return responseValue;
	}
}


