/*
 * Copyright 2005, 2008 PayPal, Inc. All Rights Reserved.
 *
 * MassPay SOAP example; last modified 08MAY23. 
 *
 * Pay one or more recipients.  
 */
package com.soap.codegenerator;

import com.paypal.sdk.profiles.APIProfile;
import com.paypal.sdk.profiles.ProfileFactory;
import com.paypal.sdk.services.CallerServices;
import com.paypal.soap.api.BasicAmountType;
import com.paypal.soap.api.CurrencyCodeType;
import com.paypal.soap.api.MassPayRequestItemType;
import com.paypal.soap.api.MassPayRequestType;
import com.paypal.soap.api.MassPayResponseType;
import com.paypal.soap.api.ReceiverInfoCodeType;
/**
 * PayPal Java SDK sample code
 */
public class MassPay 
{



	public String massPayCode(String emailSub,String emailAddress,String receiverEmailItems[],
							  String amountItems[],String uniqueIdItems[],String noteItems[], 
							  String currencyCode)
	{
		CallerServices caller = new CallerServices();
		String responseValue = null;
		
		try
		{
			APIProfile profile = ProfileFactory.createSignatureAPIProfile();
			/*
			 WARNING: Do not embed plaintext credentials in your application code.
			 Doing so is insecure and against best practices.
			 Your API credentials must be handled securely. Please consider
			 encrypting them for use in any production environment, and ensure
			 that only authorized individuals may view or modify them.
			 */

		// Set up your API credentials, PayPal end point, and API version.
			profile.setAPIUsername("sdk-three_api1.sdk.com");
			profile.setAPIPassword("QFZCWN5HZM8VBG7Q");
			profile.setSignature("AVGidzoSQiGWu.lGj3z15HLczXaaAcK6imHawrjefqgclVwBe8imgCHZ");
			profile.setEnvironment("sandbox");
			caller.setAPIProfile(profile);
			
			MassPayRequestType pprequest = new MassPayRequestType();
			pprequest.setVersion("51.0");

		// Add request-specific fields to the request.
			MassPayRequestItemType[] massPayItem = new MassPayRequestItemType[receiverEmailItems.length];
			
			for(int i=0,j=0;i<receiverEmailItems.length; i++)
			{
				String recreceiverEmail=receiverEmailItems[i];
				if(recreceiverEmail != null && recreceiverEmail.length()!= 0)
				{
					MassPayRequestItemType massItemReq = new MassPayRequestItemType();
					massItemReq.setReceiverEmail(receiverEmailItems[i]);
					BasicAmountType amount = new BasicAmountType();
					amount.set_value(amountItems[i]);
					amount.setCurrencyID(CurrencyCodeType.fromString(currencyCode));
					massItemReq.setUniqueId(uniqueIdItems[i]);
					massItemReq.setNote(noteItems[i]);
					massItemReq.setAmount(amount);
					massPayItem[j]=massItemReq;
					j++;
				}								
			}
			pprequest.setEmailSubject(emailSub);;
			pprequest.setReceiverType(ReceiverInfoCodeType.fromString(emailAddress));
			pprequest.setMassPayItem(massPayItem);

		// Execute the API operation and obtain the response.
			MassPayResponseType ppresponse = (MassPayResponseType) caller.call("MassPay", pprequest);
			responseValue = ppresponse.getAck().toString();
			
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return responseValue;
	}
}
