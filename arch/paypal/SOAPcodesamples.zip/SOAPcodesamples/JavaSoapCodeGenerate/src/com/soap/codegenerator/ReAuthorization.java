/*
 * Copyright 2005, 2008 PayPal, Inc. All Rights Reserved.
 *
 * DoReauthorization SOAP example; last modified 08MAY23. 
 *
 * Reauthorize a previously authorized payment.  
 */
package com.soap.codegenerator;

import com.paypal.sdk.profiles.APIProfile;
import com.paypal.sdk.profiles.ProfileFactory;
import com.paypal.sdk.services.CallerServices;
import com.paypal.soap.api.BasicAmountType;
import com.paypal.soap.api.CurrencyCodeType;
import com.paypal.soap.api.DoReauthorizationRequestType;
import com.paypal.soap.api.DoReauthorizationResponseType;
/**
 * PayPal Java SDK sample code
 */
public class ReAuthorization 
{

	public String ReauthorizationCode(String authorizationId,String amount,String currencyCode,String refundType)
	{
		String responseValue = null;
		CallerServices caller = new CallerServices();
		
		try	{
			
			APIProfile profile = ProfileFactory.createSignatureAPIProfile();
			/*
			 WARNING: Do not embed plaintext credentials in your application code.
			 Doing so is insecure and against best practices.
			 Your API credentials must be handled securely. Please consider
			 encrypting them for use in any production environment, and ensure
			 that only authorized individuals may view or modify them.
			 */

		// Set up your API credentials, PayPal end point, and API version.
			profile.setAPIUsername("sdk-three_api1.sdk.com");
			profile.setAPIPassword("QFZCWN5HZM8VBG7Q");
			profile.setSignature("AVGidzoSQiGWu.lGj3z15HLczXaaAcK6imHawrjefqgclVwBe8imgCHZ");
			profile.setEnvironment("sandbox");
			caller.setAPIProfile(profile);
			
			DoReauthorizationRequestType pp_request = new DoReauthorizationRequestType();
			pp_request.setVersion("51.0");

		// Add request-specific fields to the request.
			pp_request.setAuthorizationID(authorizationId); 
			BasicAmountType amtType = new BasicAmountType();
			amtType.set_value(amount);
			amtType.setCurrencyID(CurrencyCodeType.fromString(currencyCode));
			pp_request.setAmount(amtType);

		// Execute the API operation and obtain the response.
			DoReauthorizationResponseType ppresponse = (DoReauthorizationResponseType) caller.call("DoReauthorization", pp_request);
			responseValue = ppresponse.getAck().toString();
			
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		return responseValue;
	}
	
}
