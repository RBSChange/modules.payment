/*
 * Copyright 2005, 2008 PayPal, Inc. All Rights Reserved.
 */

import java.util.Calendar;

import com.paypal.sdk.exceptions.PayPalException;
import com.paypal.sdk.profiles.APIProfile;
import com.paypal.sdk.profiles.ProfileFactory;
import com.paypal.sdk.services.CallerServices;
import com.paypal.soap.api.*;

/**
 * PayPal Java SDK sample application
 */
public class SetCustomerBillingAgreement {
	CallerServices caller;

    public static void main(String[] args) {
    	try {
    		SetCustomerBillingAgreement sample = new SetCustomerBillingAgreement();
    		sample.run();
		}
    	catch (Exception e) {
    		System.out.println("ERROR: " + e.getMessage());
		}
    }

    public SetCustomerBillingAgreement() throws PayPalException {
    	caller = new CallerServices();

    	/*
    	 WARNING: Do not embed plaintext credentials in your application code.
    	 Doing so is insecure and against best practices.
    	 Your API credentials must be handled securely. Please consider
    	 encrypting them for use in any production environment, and ensure
    	 that only authorized individuals may view or modify them.
    	 */

    	APIProfile profile = ProfileFactory.createSignatureAPIProfile();
		profile.setAPIUsername("sdk-three_api1.sdk.com");
		profile.setAPIPassword("QFZCWN5HZM8VBG7Q");
		profile.setSignature("A.d9eRKfd1yVkRrtmMfCFLTqa6M9AyodL0SJkhYztxUi8W9pCXF6.4NI");
		profile.setEnvironment("sandbox");
    	caller.setAPIProfile(profile);
    }

    public void run() throws PayPalException {

		makeApiCallandGetToken();
		System.out.println("\nDone...");
    }

    public void makeApiCallandGetToken() throws PayPalException {
    	System.out.println("\n########## Starting SetCustomerBillingAgreementCode ##########\n");

		// Create the request object
		SetCustomerBillingAgreementRequestType request = new SetCustomerBillingAgreementRequestType();
		request.setSetCustomerBillingAgreementRequestDetails( new SetCustomerBillingAgreementRequestDetailsType());
		request.setVersion("50.0");
		SetCustomerBillingAgreementResponseType response = new SetCustomerBillingAgreementResponseType();
        StringBuffer url = new StringBuffer();

		String returnURL = "http://www.yahoo.com";   //replace this value with your application url
		String cancelURL = "http://www.google.com";  //replace this value with your application error handling application url

		request.getSetCustomerBillingAgreementRequestDetails().setCancelURL(cancelURL);
		request.getSetCustomerBillingAgreementRequestDetails().setReturnURL(returnURL);

		request.getSetCustomerBillingAgreementRequestDetails().setBillingAgreementDetails(new BillingAgreementDetailsType());
        String description = "Description";
		request.getSetCustomerBillingAgreementRequestDetails().getBillingAgreementDetails().setBillingAgreementDescription("recurring payment test");
		request.getSetCustomerBillingAgreementRequestDetails().getBillingAgreementDetails().setBillingType(BillingCodeType.RecurringPayments);
		response= (SetCustomerBillingAgreementResponseType) caller.call("SetCustomerBillingAgreement", request);

		if (!response.getAck().equals(AckCodeType.Success) && !response.getAck().equals(AckCodeType.SuccessWithWarning)) {
			// do error processing
			System.out.println("\n########## SetCustomerBillingAgreementAPI call failed ##########\n");
		} else {
			//success
			System.out.println("\n########## SetCustomerBillingAgreementAPI call passed. The token returned is = " + response.getToken()  +" ##########\n");
		}

    }

}