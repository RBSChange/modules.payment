/*
 * Copyright 2005, 2008 PayPal, Inc. All Rights Reserved.
 *
 * TransactionSearch SOAP example; last modified 08MAY23. 
 *
 * Search your account history for transactions that meet the criteria you specify.  
 */
package com.soap.codegenerator;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.paypal.sdk.profiles.APIProfile;
import com.paypal.sdk.profiles.ProfileFactory;
import com.paypal.sdk.services.CallerServices;
import com.paypal.soap.api.TransactionSearchRequestType;
import com.paypal.soap.api.TransactionSearchResponseType;
/**
 * PayPal Java SDK sample code
 */
public class TransactionSearch 
{

	public String TransactionSearchCode(String startDateStr, String endDateStr, String transactionID)
	{
		String responseValue = null;
		CallerServices caller = new CallerServices();
		
		try
		{
			APIProfile profile = ProfileFactory.createSignatureAPIProfile();
			/*
			 WARNING: Do not embed plaintext credentials in your application code.
			 Doing so is insecure and against best practices.
			 Your API credentials must be handled securely. Please consider
			 encrypting them for use in any production environment, and ensure
			 that only authorized individuals may view or modify them.
			 */

		// Set up your API credentials, PayPal end point, and API version.
			profile.setAPIUsername("sdk-three_api1.sdk.com");
			profile.setAPIPassword("QFZCWN5HZM8VBG7Q");
			profile.setSignature("AVGidzoSQiGWu.lGj3z15HLczXaaAcK6imHawrjefqgclVwBe8imgCHZ");
			profile.setEnvironment("sandbox");
			caller.setAPIProfile(profile);
			
			DateFormat dfRead = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss Z");
			Calendar startDate = Calendar.getInstance();
			startDate.setTime(dfRead.parse(startDateStr + " 00:00:00 +0000"));
			Calendar endDate = Calendar.getInstance();
			if ((endDateStr != null)&& (endDateStr.length() > 0)) {
				endDate.setTime(dfRead.parse(endDateStr + " 23:59:59 +0000"));  
			}
			
			TransactionSearchRequestType pprequest = new TransactionSearchRequestType();
			pprequest.setVersion("51.0");

		// Add request-specific fields to the request.
			pprequest.setStartDate(startDate);
			pprequest.setEndDate(endDate);
			pprequest.setTransactionID(transactionID);

		// Execute the API operation and obtain the response.
			TransactionSearchResponseType ppresponse = (TransactionSearchResponseType) 
				caller.call("TransactionSearch", pprequest);
			responseValue = ppresponse.getAck().toString();
			
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		
		return responseValue;
	}
}
