<?php
/** CreateRecurringPaymentsProfile SOAP example; last modified 08MAY23.
 *
 *  CreateRecurringPaymentsProfile.
*/

include 'ppsdk_include_path.inc';

require_once 'PayPal.php';
require_once 'PayPal/Profile/Handler/Array.php';
require_once 'PayPal/Profile/API.php';
require_once 'PayPal/Type/BasicAmountType';
require_once 'PayPal/Type/BillingPeriodDetailsType';
require_once 'PayPal/Type/ScheduleDetailsType';
require_once 'PayPal/Type/RecurringPaymentsProfileDetailsType';
require_once 'PayPal/Type/CreateRecurringPaymentsProfileRequestType.php';
require_once 'PayPal/Type/CreateRecurringPaymentsProfileRequestDetailsType';
require_once 'PayPal/Type/CreateRecurringPaymentsProfileResponseDetailsType ';
require_once 'PayPal/Type/CreateRecurringPaymentsProfileResponseType';

$environment = 'sandbox';	// or 'beta-sandbox' or 'live'

//--------------------------------------------------
// PROFILE
//--------------------------------------------------
/**
 *                    W A R N I N G
 * Do not embed plaintext credentials in your application code.
 * Doing so is insecure and against best practices.
 *
 * Your API credentials must be handled securely. Please consider
 * encrypting them for use in any production environment, and ensure
 * that only authorized individuals may view or modify them.
 */

$handler = & ProfileHandler_Array::getInstance(array(
            'username' => 'my_api_username',
            'certificateFile' => null,
            'subject' => null,
            'environment' => $environment));

$pid = ProfileHandler::generateID();

$profile = & new APIProfile($pid, $handler);

// Set up your API credentials, PayPal end point, and API version.
$profile->setAPIUsername('my_api_username');
$profile->setAPIPassword('my_api_password');
$profile->setSignature('my_api_signature');
$profile->setCertificateFile('my_cert_file_path');
$profile->setEnvironment($environment);
//--------------------------------------------------

$recurring_payments_request =& PayPal::getType('CreateRecurringPaymentsProfileRequestType');
$recurring_payments_request->setVersion("51.0");

// Set request-specific fields.
$token = urlencode("token_from_setExpressCheckout");
$paymentAmount = urlencode("payment_amount");
$currencyID = urlencode("USD");						// or other currency code ('GBP', 'EUR', 'JPY', 'CAD', 'AUD')
$startDate = urlencode("2009-9-6T0:0:0");
$billingPeriod = urlencode("Month");				// or "Day", "Week", "SemiMonth", "Year"
$billingFreq = urlencode("4");						// combination of this and billingPeriod must be at most a year

$recurring_payments_request_details =& PayPal::getType('CreateRecurringPaymentsProfileRequestDetailsType');
$recurring_payments_request_details->setToken($token);

$recurring_payments_details =& PayPal::getType('RecurringPaymentsProfileDetailsType');
$recurring_payments_details->setBillingStartDate($startDate);
$recurring_payments_request_details->setRecurringPaymentsProfileDetails($recurring_payments_details);

$schedule_details =& PayPal::getType('ScheduleDetailsType');

$billing_period_details =& PayPal::getType('BillingPeriodDetails');

$billing_period_details->setBillingPeriod($billingPeriod);
$billing_period_details->setBillingFrequency($billingFreq);

$basic_amount =& PayPal::getType('BasicAmountType');
$basic_amount->setattr('currencyID', $currencyID);
$basic_amount->setval($paymentAmount);
$billing_period_details->setAmount($basic_amount);

$schedule_details->setPaymentPeriod($billing_period_details);

$recurring_payments_request_details->setScheduleDetails($schedule_details);

$recurring_payments_request->setCreateRecurringPaymentsProfileRequestDetails($recurring_payments_request_details);

$caller =& PayPal::getCallerServices($profile);

// Execute SOAP request.
$response = $caller->CreateRecurringPaymentsProfile($recurring_payments_request);

switch($response->getAck()) {
	case 'Success':
	case 'SuccessWithWarning':
        // Extract the response details.
		$recurring_payments_response_details = $response->getCreateRecurringPaymentsProfileResponseDetails();
		$profileID = $recurring_payments_response_details->getProfileID();

		exit('CreateRecurringPaymentsProfile Completed Successfully: ' . print_r($response, true));

	default:
		exit('CreateRecurringPaymentsProfile failed: ' . print_r($response, true));
}

?>