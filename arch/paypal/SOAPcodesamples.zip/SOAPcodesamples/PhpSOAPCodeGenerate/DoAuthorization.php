<?php

/** DoAuthorization SOAP example; last modified 08MAY23.
 *
 *  Authorize a payment. 
*/

include 'ppsdk_include_path.inc';

require_once 'PayPal.php';
require_once 'PayPal/Profile/Handler/Array.php';
require_once 'PayPal/Profile/API.php';
require_once 'PayPal/Type/DoAuthorizationRequestType.php';
require_once 'PayPal/Type/DoAuthorizationResponseType.php';

$environment = 'sandbox';	// or 'beta-sandbox' or 'live'

//--------------------------------------------------
// PROFILE
//--------------------------------------------------
/**
 *                    W A R N I N G
 * Do not embed plaintext credentials in your application code.
 * Doing so is insecure and against best practices.
 *
 * Your API credentials must be handled securely. Please consider
 * encrypting them for use in any production environment, and ensure
 * that only authorized individuals may view or modify them.
 */

$handler = & ProfileHandler_Array::getInstance(array(
            'username' => 'my_api_username',
            'certificateFile' => null,
            'subject' => null,
            'environment' => $environment));

$pid = ProfileHandler::generateID();

$profile = & new APIProfile($pid, $handler);

// Set up your API credentials, PayPal end point, and API version.
$profile->setAPIUsername('my_api_username');
$profile->setAPIPassword('my_api_password');
$profile->setSignature('my_api_signature');
$profile->setCertificateFile('my_cert_file_path');
$profile->setEnvironment($environment);
//--------------------------------------------------

$authorization_request =& PayPal::getType('DoAuthorizationRequestType');
$authorization_request->setVersion("51.0");

// Set request-specific fields.
$transaction_id = 'example_transaction_id';
$amount = 'example_amount';
$currencyID = 'USD';					// or other currency ('GBP', 'EUR', 'JPY', 'CAD', 'AUD')

$authorization_request->setTransactionID($transaction_id);

$amtType =& PayPal::getType('BasicAmountType');
$amtType->setattr('currencyID', $currencyID);
$amtType->setval($amount, 'iso-8859-1');
$authorization_request->setAmount($amtType);

$caller =& PayPal::getCallerServices($profile);

// Execute SOAP request.
$response =$caller->DoAuthorization($authorization_request);

switch($response->getAck()) {
	case 'Success':
	case 'SuccessWithWarning':
        // Extract the response details.
		$transactionID = $response->getTransactionID();
		exit('DoAuthorization Completed Successfully: ' . print_r($response, true));

	default:
		exit('DoAuthorization failed: ' . print_r($response, true));
}

?>