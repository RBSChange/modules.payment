<?php
/** DoCapture SOAP example; last modified 08MAY23.
 *
 *  Capture a payment. 
*/

include 'ppsdk_include_path.inc';

require_once 'PayPal.php';
require_once 'PayPal/Profile/Handler/Array.php';
require_once 'PayPal/Profile/API.php';
require_once 'PayPal/Type/DoCaptureRequestType.php';
require_once 'PayPal/Type/DoCaptureResponseDetailsType.php';
require_once 'PayPal/Type/DoCaptureResponseType.php';

$environment = 'sandbox';	// or 'beta-sandbox' or 'live'

//--------------------------------------------------
// PROFILE
//--------------------------------------------------
/**
 *                    W A R N I N G
 * Do not embed plaintext credentials in your application code.
 * Doing so is insecure and against best practices.
 *
 * Your API credentials must be handled securely. Please consider
 * encrypting them for use in any production environment, and ensure
 * that only authorized individuals may view or modify them.
 */

$handler = & ProfileHandler_Array::getInstance(array(
            'username' => 'my_api_username',
            'certificateFile' => null,
            'subject' => null,
            'environment' => $environment));

$pid = ProfileHandler::generateID();

$profile = & new APIProfile($pid, $handler);

// Set up your API credentials, PayPal end point, and API version.
$profile->setAPIUsername('my_api_username');
$profile->setAPIPassword('my_api_password');
$profile->setSignature('my_api_signature');
$profile->setCertificateFile('my_cert_file_path');
$profile->setEnvironment($environment);
//--------------------------------------------------

$capture_request =& PayPal::getType('DoCaptureRequestType');
$capture_request->setVersion("51.0");

// Set request-specific fields.
$authorization_id = 'example_authorization_id';
$amount = 'example_amount';
$currencyID = 'USD';					// or other currency ('GBP', 'EUR', 'JPY', 'CAD', 'AUD')
$complete_code_type = 'Complete';		// or 'NotComplete'
$invoice_id;							// optional
$note;									// optional

$capture_request->setAuthorizationID($authorization_id, 'iso-8859-1');
$capture_request->setCompleteType($complete_code_type);
if(isset($invoice_id))
   $capture_request->setInvoiceID($invoice_id);
if(isset($note))
   $capture_request->setNote($note);

$amtType =& PayPal::getType('BasicAmountType');
$amtType->setattr('currencyID', $currencyID);
$amtType->setval($amount, 'iso-8859-1');
$capture_request->setAmount($amtType);

$caller =& PayPal::getCallerServices($profile);

// Execute SOAP request.
$response = $caller->DoCapture($capture_request);

switch($response->getAck()) {
	case 'Success':
	case 'SuccessWithWarning':
        // Extract the response details.
		$capture_details = $response->getDoCaptureResponseDetails();

		$authorizationID = $capture_details->getAuthorizationID();
		$paymentInfo = $capture_details->getPaymentInfo();
		$transactionID = $paymentInfo->getTransactionID();
		$paymentStatus = $paymentInfo->getPaymentStatus();
		$grossAmount = $paymentInfo->getGrossAmount();
		$amount = $grossAmount->_value;
		$currencyID = $grossAmount->getattr('currencyID');
		exit('Capture Completed Successfully: ' . print_r($response, true));

	default:
		exit('DoCapture failed: ' . print_r($response, true));
}

?>