<?php
/** DoDirectPayment SOAP example; last modified 08MAY23.
 *
 *  Process a credit card payment. 
*/

include 'ppsdk_include_path.inc';

require_once 'PayPal.php';
require_once 'PayPal/Profile/Handler/Array.php';
require_once 'PayPal/Profile/API.php';
require_once 'PayPal/Type/DoDirectPaymentRequestType.php';
require_once 'PayPal/Type/DoDirectPaymentRequestDetailsType.php';
require_once 'PayPal/Type/DoDirectPaymentResponseType.php';

$environment = 'sandbox';	// or 'beta-sandbox' or 'live'

//--------------------------------------------------
// PROFILE
//--------------------------------------------------
/**
 *                    W A R N I N G
 * Do not embed plaintext credentials in your application code.
 * Doing so is insecure and against best practices.
 *
 * Your API credentials must be handled securely. Please consider
 * encrypting them for use in any production environment, and ensure
 * that only authorized individuals may view or modify them.
 */

$handler = & ProfileHandler_Array::getInstance(array(
            'username' => 'my_api_username',
            'certificateFile' => null,
            'subject' => null,
            'environment' => $environment));

$pid = ProfileHandler::generateID();

$profile = & new APIProfile($pid, $handler);

// Set up your API credentials, PayPal end point, and API version.
$profile->setAPIUsername('my_api_username');
$profile->setAPIPassword('my_api_password');
$profile->setSignature('my_api_signature');
$profile->setCertificateFile('my_cert_file_path');
$profile->setEnvironment($environment);
//--------------------------------------------------

$dp_request =& PayPal::getType('DoDirectPaymentRequestType');
$dp_request->setVersion("51.0");

// Set request-specific fields.
$refund_request->setTransactionId('example_transaction_id', 'iso-8859-1');

$paymentType = 'Authorization';				// or 'Sale'
$firstName = 'customer_first_name';
$lastName = 'customer_last_name';
$creditCardType = 'customer_credit_card_type';
$creditCardNumber = 'customer_credit_card_number';
$expDateMonth = 'cc_expiration_month';
// Month must be padded with leading zero
$padDateMonth = str_pad($expDateMonth, 2, '0', STR_PAD_LEFT);

$expDateYear = 'cc_expiration_year';
$cvv2Number = 'cc_cvv2_number';
$address1 = 'customer_address1';
$address2 = 'customer_address2';
$city = 'customer_city';
$state = 'customer_state';
$zip = 'customer_zip';
$country = 'customer_country';				// UNITED_STATES or other valid country
$amount = 'example_payment_amuont';
$currencyID = 'USD';						// or other currency ('GBP', 'EUR', 'JPY', 'CAD', 'AUD')

// setup the DoDirectPayment Request Payment details.
$OrderTotal =& PayPal::getType('BasicAmountType');
$OrderTotal->setattr('currencyID', $currencyID);
$OrderTotal->setval($amount, 'iso-8859-1');

$shipTo =& PayPal::getType('AddressType');
$shipTo->setName($firstName.' '.$lastName);
$shipTo->setStreet1($address1);
$shipTo->setStreet2($address2);
$shipTo->setCityName($city);
$shipTo->setStateOrProvince($state);
$shipTo->setCountry($country);
$shipTo->setPostalCode($zip);

$PaymentDetails =& PayPal::getType('PaymentDetailsType');
$PaymentDetails->setOrderTotal($OrderTotal);
$PaymentDetails->setShipToAddress($shipTo);

// Set up credit card info.
$person_name =& PayPal::getType('PersonNameType');
$person_name->setFirstName($firstName);
$person_name->setLastName($lastName);

$payer =& PayPal::getType('PayerInfoType');
$payer->setPayerName($person_name);
$payer->setPayerCountry($country);
$payer->setAddress($shipTo);

$card_details =& PayPal::getType('CreditCardDetailsType');
$card_details->setCardOwner($payer);
$card_details->setCreditCardType($creditCardType);
$card_details->setCreditCardNumber($creditCardNumber);
$card_details->setExpMonth($padDateMonth);
$card_details->setExpYear($expDateYear);
$card_details->setCVV2($cvv2Number);

$dp_details =& PayPal::getType('DoDirectPaymentRequestDetailsType');
$dp_details->setPaymentDetails($PaymentDetails);
$dp_details->setCreditCard($card_details);
$dp_details->setIPAddress($_SERVER['SERVER_ADDR']);
$dp_details->setPaymentAction($paymentType);

$dp_request->setDoDirectPaymentRequestDetails($dp_details);

$caller =& PayPal::getCallerServices($profile);

// Execute SOAP request.
$response = $caller->DoDirectPayment($dp_request);

switch($response->getAck()) {
	case 'Success':
	case 'SuccessWithWarning':
        // Extract the response details.
		$tranID = $response->getTransactionID();
		$avsCode = $response->getAVSCode();
		$cvv2 = $response->getCVV2Code();
		$amt = $response->getAmount()->_value;
		$currencyID = $response->getAmount()->getattr('currencyID');
		$amt_display = "$currencyID $amt";
		exit('Direct Payment Completed Successfully: ' . print_r($response, true));

	default:
		exit('DoDirectPayment failed: ' . print_r($response, true));
}

?>