<?php
/** MassPay SOAP example; last modified 08MAY23.
 *
 *  Pay one or more recipients. 
*/

include 'ppsdk_include_path.inc';

require_once 'PayPal.php';
require_once 'PayPal/Profile/Handler/Array.php';
require_once 'PayPal/Profile/API.php';
require_once 'PayPal/Type/MassPayRequestType.php';
require_once 'PayPal/Type/MassPayRequestItemType.php';
require_once 'PayPal/Type/MassPayResponseType.php';

$environment = 'sandbox';	// or 'beta-sandbox' or 'live'

//--------------------------------------------------
// PROFILE
//--------------------------------------------------
/**
 *                    W A R N I N G
 * Do not embed plaintext credentials in your application code.
 * Doing so is insecure and against best practices.
 *
 * Your API credentials must be handled securely. Please consider
 * encrypting them for use in any production environment, and ensure
 * that only authorized individuals may view or modify them.
 */

$handler = & ProfileHandler_Array::getInstance(array(
            'username' => 'my_api_username',
            'certificateFile' => null,
            'subject' => null,
            'environment' => $environment));

$pid = ProfileHandler::generateID();

$profile = & new APIProfile($pid, $handler);

// Set up your API credentials, PayPal end point, and API version.
$profile->setAPIUsername('my_api_username');
$profile->setAPIPassword('my_api_password');
$profile->setSignature('my_api_signature');
$profile->setCertificateFile('my_cert_file_path');
$profile->setEnvironment($environment);
//--------------------------------------------------

$masspay_request =& PayPal::getType('MassPayRequestType');
$masspay_request->setVersion("51.0");

// Set request-specific fields.
$emailSubject =urlencode('example_email_subject');
$receiverType = urlencode('EmailAddress');
$currencyID = urlencode('USD');							// or other currency ('GBP', 'EUR', 'JPY', 'CAD', 'AUD')

$receiversArray = array();

for($i = 0; $i < 3; $i++) {
	$receiverData = array(	'receiverEmail' => "user$i@paypal.com",
							'amount' => "example_amount",
							'uniqueID' => "example_unique_id",
							'note' => "example_note");
	$receiversArray[$i] = $receiverData;
}

$massPayItems = array();

foreach($receiversArray as $i => $receiverData) {
	$massPayItems[$i] =& PayPal::getType('MassPayRequestItemType');
	$massPayItems[$i]->setReceiverEmail($receiverData["receiverEmail"]);
	$massPayItems[$i]->setNote($receiverData["note"]);
	$massPayItems[$i]->setUniqueId($receiverData["uniqueID"]);

	$amtType =& PayPal::getType('BasicAmountType');
	$amtType->setattr('currencyID',$currencyID);
	$amtType->setval($receiverData["amount"],'iso-8859-1');
	$massPayItems[$i]->setAmount($amtType);
}

$masspay_request->setEmailSubject($emailSubject);
$masspay_request->setReceiverType($receiverType);
// Create multiple occurences of MassPayRequestItem. as necessary.
$multiItems =&new MultiOccurs($masspay_request, 'MassPayRequestItem');
$multiItems->setChildren($massPayItems);
$masspay_request->setMassPayItem($multiItems);

$caller =& PayPal::getCallerServices($profile);

// Execute SOAP request.
$response =$caller->MassPay($masspay_request);

switch($response->getAck()) {
	case 'Success':
	case 'SuccessWithWarning':
        // Extract the response details.
		exit('DoMassPay Completed Successfully: ' . print_r($response, true));

	default:
		exit('DoMassPay failed: ' . print_r($response, true));
}

?>