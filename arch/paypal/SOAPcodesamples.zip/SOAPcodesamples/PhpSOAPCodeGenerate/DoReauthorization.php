<?php
/** DoReauthorization SOAP example; last modified 08MAY23.
 *
 *  Reauthorize a previously authorized payment. 
*/

include 'ppsdk_include_path.inc';

require_once 'PayPal.php';
require_once 'PayPal/Profile/Handler/Array.php';
require_once 'PayPal/Profile/API.php';
require_once 'PayPal/Type/DoReauthorizationRequestType.php';
require_once 'PayPal/Type/DoReauthorizationResponseType.php';

$environment = 'sandbox';	// or 'beta-sandbox' or 'live'

//--------------------------------------------------
// PROFILE
//--------------------------------------------------
/**
 *                    W A R N I N G
 * Do not embed plaintext credentials in your application code.
 * Doing so is insecure and against best practices.
 *
 * Your API credentials must be handled securely. Please consider
 * encrypting them for use in any production environment, and ensure
 * that only authorized individuals may view or modify them.
 */

$handler = & ProfileHandler_Array::getInstance(array(
            'username' => 'my_api_username',
            'certificateFile' => null,
            'subject' => null,
            'environment' => $environment));

$pid = ProfileHandler::generateID();

$profile = & new APIProfile($pid, $handler);

// Set up your API credentials, PayPal end point, and API version.
$profile->setAPIUsername('my_api_username');
$profile->setAPIPassword('my_api_password');
$profile->setSignature('my_api_signature');
$profile->setCertificateFile('my_cert_file_path');
$profile->setEnvironment($environment);
//--------------------------------------------------

$reauthorization_request =& PayPal::getType('DoReauthorizationRequestType');
$reauthorization_request->setVersion("51.0");

// Set request-specific fields.
$authorization_id = 'example_authorization_id';
$amount = 'example_amount';
$currencyID = 'USD';					// or other currency ('GBP', 'EUR', 'JPY', 'CAD', 'AUD')

$reauthorization_request->setAuthorizationID($authorization_id);

$amtType =& PayPal::getType('BasicAmountType');
$amtType->setattr('currencyID', $currencyID);
$amtType->setval($amount, 'iso-8859-1');
$reauthorization_request->setAmount($amtType);

$caller =& PayPal::getCallerServices($profile);

// Execute SOAP request.
$response =$caller->DoReauthorization($reauthorization_request);

switch($response->getAck()) {
	case 'Success':
	case 'SuccessWithWarning':
        // Extract the response details.
		$authorizationID = $response->getAuthorizationID();
		exit('DoReauthorization Completed Successfully: ' . print_r($response, true));

	default:
		exit('DoReauthorization failed: ' . print_r($response, true));
}

?>