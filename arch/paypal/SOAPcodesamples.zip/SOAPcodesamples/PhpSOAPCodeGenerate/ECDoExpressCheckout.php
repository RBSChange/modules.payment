<?php
/** DoExpressCheckoutPayment SOAP example; last modified 08MAY23.
 *
 *  Complete an Express Checkout transaction. 
*/

include 'ppsdk_include_path.inc';

require_once 'PayPal.php';
require_once 'PayPal/Profile/Handler/Array.php';
require_once 'PayPal/Profile/API.php';
require_once 'PayPal/Type/BasicAmountType.php';
require_once 'PayPal/Type/DoExpressCheckoutPaymentRequestType.php';
require_once 'PayPal/Type/DoExpressCheckoutPaymentRequestDetailsType.php';
require_once 'PayPal/Type/DoExpressCheckoutPaymentResponseType.php';

$environment = 'sandbox';	// or 'beta-sandbox' or 'live'

//--------------------------------------------------
// PROFILE
//--------------------------------------------------
/**
 *                    W A R N I N G
 * Do not embed plaintext credentials in your application code.
 * Doing so is insecure and against best practices.
 *
 * Your API credentials must be handled securely. Please consider
 * encrypting them for use in any production environment, and ensure
 * that only authorized individuals may view or modify them.
 */

$handler = & ProfileHandler_Array::getInstance(array(
            'username' => 'my_api_username',
            'certificateFile' => null,
            'subject' => null,
            'environment' => $environment));

$pid = ProfileHandler::generateID();

$profile = & new APIProfile($pid, $handler);

// Set up your API credentials, PayPal end point, and API version.
$profile->setAPIUsername('my_api_username');
$profile->setAPIPassword('my_api_password');
$profile->setSignature('my_api_signature');
$profile->setCertificateFile('my_cert_file_path');
$profile->setEnvironment($environment);
//--------------------------------------------------

$ec_details =& PayPal::getType('DoExpressCheckoutPaymentRequestDetailsType');
$ec_details->setVersion("51.0");

// Set request-specific fields.
/**
 * This example assumes that a token was obtained from the SetExpressCheckout API call.
 * This example  alos assumes that a payerID was obtained from the SetExpressCheckout API call
 * or from the GetExpressCheckoutDetails API call.
 */
$payerID = "payer_id";
$token = "token";

$paymentType = "Authorization";			// or 'Sale' or 'Order'
$paymentAmount = "payment_amount";
$currencyID = "USD";					// or other currency code ('GBP', 'EUR', 'JPY', 'CAD', 'AUD')

$order_total = "$currencyID $paymentAmount";

$ec_details->setToken($token);
$ec_details->setPayerID($payerID);
$ec_details->setPaymentAction($paymentType);

$amt_type =& PayPal::getType('BasicAmountType');
$amt_type->setattr('currencyID', $currencyID);
$amt_type->setval($paymentAmount, 'iso-8859-1');

$payment_details =& PayPal::getType('PaymentDetailsType');
$payment_details->setOrderTotal($amt_type);

$ec_details->setPaymentDetails($payment_details);

$ec_request =& PayPal::getType('DoExpressCheckoutPaymentRequestType');
$ec_request->setDoExpressCheckoutPaymentRequestDetails($ec_details);

$caller =& PayPal::getCallerServices($profile);

// Execute SOAP request.
$response = $caller->DoExpressCheckoutPayment($ec_request);

switch ($response->getAck()) {
	case 'Success':
	case 'SuccessWithWarning':
        // Extract the response details.
		$details = $response->getDoExpressCheckoutPaymentResponseDetails();
		$payment_info = $details->getPaymentInfo();
		$tran_ID = $payment_info->getTransactionID();

		$amt_obj = $payment_info->getGrossAmount();
		$amt = $amt_obj->_value;
		$currency_cd = $amt_obj->_attributeValues['currencyID'];
		$display_amt = $currency_cd.' '.$amt;
		exit('Express Checkout Payment Completed Successfully: ' . print_r($response, true));

	default:
		exit('DoExpressCheckoutPayment failed: ' . print_r($response, true));
}

?>