<?php
/** GetExpressCheckoutDetails SOAP example; last modified 08MAY23.
 *
 *  Get information about an Express Checkout transaction. 
*/

include 'ppsdk_include_path.inc';

require_once 'PayPal.php';
require_once 'PayPal/Profile/Handler/Array.php';
require_once 'PayPal/Profile/API.php';
require_once 'PayPal/Type/BasicAmountType.php';
require_once 'PayPal/Type/GetExpressCheckoutDetailsRequestType.php';
require_once 'PayPal/Type/GetExpressCheckoutDetailsResponseDetailsType.php';
require_once 'PayPal/Type/GetExpressCheckoutDetailsResponseType.php';

$environment = 'sandbox';	// or 'beta-sandbox' or 'live'

//--------------------------------------------------
// PROFILE
//--------------------------------------------------
/**
 *                    W A R N I N G
 * Do not embed plaintext credentials in your application code.
 * Doing so is insecure and against best practices.
 *
 * Your API credentials must be handled securely. Please consider
 * encrypting them for use in any production environment, and ensure
 * that only authorized individuals may view or modify them.
 */

$handler = & ProfileHandler_Array::getInstance(array(
            'username' => 'my_api_username',
            'certificateFile' => null,
            'subject' => null,
            'environment' => $environment));

$pid = ProfileHandler::generateID();

$profile = & new APIProfile($pid, $handler);

// Set up your API credentials, PayPal end point, and API version.
$profile->setAPIUsername('my_api_username');
$profile->setAPIPassword('my_api_password');
$profile->setSignature('my_api_signature');
$profile->setCertificateFile('my_cert_file_path');
$profile->setEnvironment($environment);
//--------------------------------------------------

$ec_request =& PayPal::getType('GetExpressCheckoutDetailsRequestType');
$ec_request->setVersion("51.0");

/**
 * This example assumes that the token is in the return URL in the SetExpressCheckout API call.
 * The PayPal website redirects the user to this page with a token.
 */
if(!array_key_exists('token', $_REQUEST)) {
	exit('Token is not received.');
}

// Set request-specific fields.
$token = htmlspecialchars($_REQUEST['token']);
$ec_request->setToken($token);

$caller =& PayPal::getCallerServices($profile);

// Execute SOAP request.
$response = $caller->GetExpressCheckoutDetails($ec_request);

switch($response->getAck()) {
	case 'Success':
	case 'SuccessWithWarning':
        // Extract the response details.
		$responseDetails = $response->getGetExpressCheckoutDetailsResponseDetails();

		$payerInfo = $responseDetails->getPayerInfo();
		$payerID = $payerInfo->getPayerID();

		$address = $payerInfo->getAddress();
		$street1 = $address->getStreet1();
		$street2 = $address->getStreet2();
		$cityName = $address->getCityName();
		$stateOrProvince = $address->getStateOrProvince();
		$postalCode = $address->getPostalCode();
		$countryCode = $address->getCountryName();

		exit('Express Checkout Get Details Completed Successfully: ' . print_r($response, true));

	default:
		exit('GetExpressCheckoutDetails failed: ' . print_r($response, true));
}