<?php
/** SetExpressCheckout SOAP example; last modified 08MAY23.
 *
 *  Initiate an Express Checkout transaction. 
*/

include 'ppsdk_include_path.inc';

require_once 'PayPal.php';
require_once 'PayPal/Profile/Handler/Array.php';
require_once 'PayPal/Profile/API.php';
require_once 'PayPal/Type/BasicAmountType.php';
require_once 'PayPal/Type/SetExpressCheckoutRequestType.php';
require_once 'PayPal/Type/SetExpressCheckoutRequestDetailsType.php';
require_once 'PayPal/Type/SetExpressCheckoutResponseType.php';

$environment = 'sandbox';	// or 'beta-sandbox' or 'live'

//--------------------------------------------------
// PROFILE
//--------------------------------------------------
/**
 *                    W A R N I N G
 * Do not embed plaintext credentials in your application code.
 * Doing so is insecure and against best practices.
 *
 * Your API credentials must be handled securely. Please consider
 * encrypting them for use in any production environment, and ensure
 * that only authorized individuals may view or modify them.
 */

$handler = & ProfileHandler_Array::getInstance(array(
            'username' => 'my_api_username',
            'certificateFile' => null,
            'subject' => null,
            'environment' => $environment));

$pid = ProfileHandler::generateID();

// Set up your API credentials, PayPal end point, and API version.
$profile = & new APIProfile($pid, $handler);

$profile->setAPIUsername('my_api_username');
$profile->setAPIPassword('my_api_password');
$profile->setSignature('my_api_signature');
$profile->setCertificateFile('my_cert_file_path');
$profile->setEnvironment($environment);
//--------------------------------------------------

$ec_request =& PayPal::getType('SetExpressCheckoutRequestType');
$ec_request->setVersion("51.0");

// Set request-specific fields.
$paymentAmount = 'example_payment_amuont';
$currencyID = 'USD';						// or other currency code ('GBP', 'EUR', 'JPY', 'CAD', 'AUD')
$paymentType = 'Authorization';				// or 'Sale' or 'Order'

$ec_details =& PayPal::getType('SetExpressCheckoutRequestDetailsType');
$ec_details->setReturnURL('my_return_url');
$ec_details->setCancelURL('my_cancel_url');
$ec_details->setPaymentAction($paymentType);

$amt_type =& PayPal::getType('BasicAmountType');
$amt_type->setattr('currencyID', $currencyID);
$amt_type->setval($paymentAmount, 'iso-8859-1');
$ec_details->setOrderTotal($amt_type);

$ec_request->setSetExpressCheckoutRequestDetails($ec_details);

$caller =& PayPal::getCallerServices($profile);

// Execute SOAP request.
$response = $caller->SetExpressCheckout($ec_request);

switch($response->getAck()) {
	case 'Success':
	case 'SuccessWithWarning':
        // Extract the response details.
        // Redirect to paypal.com.
		$token = $response->getToken();
 		$payPalURL = "https://www.paypal.com/cgi-bin/webscr?cmd=_express-checkout&token=$token";
 		if("sandbox" === $environment || "beta-sandbox" === $environment) {
			$payPalURL = "https://www.$environment.paypal.com/cgi-bin/webscr?cmd=_express-checkout&token=$token";
		}
		header("Location: $payPalURL");
		exit;

	default:
		exit('SetExpressCheckout failed: ' . print_r($response, true));
}

?>