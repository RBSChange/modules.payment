<?php
include 'ppsdk_include_path.inc';

require_once 'PayPal.php';
require_once 'PayPal/Profile/Handler/Array.php';
require_once 'PayPal/Profile/API.php';
require_once 'PayPal/Type/GetBalanceRequestType.php';
require_once 'PayPal/Type/GetBalanceResponseType.php';

$environment = 'sandbox';	// or 'beta-sandbox' or 'live'

//--------------------------------------------------
// PROFILE
//--------------------------------------------------
/**
 *                    W A R N I N G
 * Do not embed plaintext credentials in your application code.
 * Doing so is insecure and against best practices.
 *
 * Your API credentials must be handled securely. Please consider
 * encrypting them for use in any production environment, and ensure
 * hat only authorized individuals may view or modify them.
 */

$handler = & ProfileHandler_Array::getInstance(array(
            'username' => 'my_api_username',
            'certificateFile' => null,
            'subject' => null,
            'environment' => $environment));

$pid = ProfileHandler::generateID();

$profile = & new APIProfile($pid, $handler);

$profile->setAPIUsername('my_api_username');
$profile->setAPIPassword('my_api_password');
$profile->setSignature('my_api_signature');
$profile->setCertificateFile('my_cert_file_path');
$profile->setEnvironment($environment);
//--------------------------------------------------

$balance_request =& PayPal::getType('GetBalanceRequestType');
$balance_request->setVersion("51.0");

$caller =& PayPal::getCallerServices($profile);

// Execute SOAP request
$response = $caller->GetBalance($get_balance_request);

switch($response->getAck()) {
	case 'Success':
	case 'SuccessWithWarning':
		// Extract the GetBalance response parameters
		$balance = $response->getBalance();
		$balance_amt = $balance->_value;
		$balance_currency_id = $balance->getattr('currencyID');

		$balance_time_stamp = $response->getBalanceTimeStamp();

		$balance_holdings = $response->getBalanceHoldings();
		$balance_holdings_amt = $balance_holdings->_value;
		$balance_holdings_currency_id = $balance_holdings->getattr('currencyID');

		exit('GetBalance Completed Successfully: ' . print_r($response, true));

	default:
		exit('GetBalance failed: ' . print_r($response, true));
}

?>