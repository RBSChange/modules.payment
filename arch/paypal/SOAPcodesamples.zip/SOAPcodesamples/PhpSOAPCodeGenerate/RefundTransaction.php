<?php
/** RefundTransaction SOAP example; last modified 08MAY23.
 *
 *  Issue a refund for a prior transaction. 
*/

include 'ppsdk_include_path.inc';

require_once 'PayPal.php';
require_once 'PayPal/Profile/Handler/Array.php';
require_once 'PayPal/Profile/API.php';
require_once 'PayPal/Type/RefundTransactionRequestType.php';
require_once 'PayPal/Type/RefundTransactionResponseType.php';

$environment = 'sandbox';	// or 'beta-sandbox' or 'live'

//--------------------------------------------------
// PROFILE
//--------------------------------------------------
/**
 *                    W A R N I N G
 * Do not embed plaintext credentials in your application code.
 * Doing so is insecure and against best practices.
 *
 * Your API credentials must be handled securely. Please consider
 * encrypting them for use in any production environment, and ensure
 * that only authorized individuals may view or modify them.
 */

$handler = & ProfileHandler_Array::getInstance(array(
            'username' => 'my_api_username',
            'certificateFile' => null,
            'subject' => null,
            'environment' => $environment));

$pid = ProfileHandler::generateID();

// Set up your API credentials, PayPal end point, and API version.
$profile = & new APIProfile($pid, $handler);

$profile->setAPIUsername('my_api_username');
$profile->setAPIPassword('my_api_password');
$profile->setSignature('my_api_signature');
$profile->setCertificateFile('my_cert_file_path');
$profile->setEnvironment($environment);
//--------------------------------------------------

$refund_request =& PayPal::getType('RefundTransactionRequestType');
$refund_request->setVersion("51.0");

// Set request-specific fields.
$refund_request->setTransactionId('example_transaction_id', 'iso-8859-1');

$refundType = 'Full';	// or 'Partial'
$amount;				// required if Partial.
$memo;					// required if Partial.
$currencyID = 'USD';	// or other currency ('GBP', 'EUR', 'JPY', 'CAD', 'AUD')

$refund_request->setRefundType($refundType, 'iso-8859-1');

if(strcasecmp($refundType, 'Partial') == 0) {
	if(isset($amount)) {
		$Amount =& PayPal::getType('BasicAmountType');
		$Amount->setattr('currencyID', $currencyID);
		$Amount->setval($amount, 'iso-8859-1');
		$refund_request->setAmount($Amount);
	} else {
		exit('Partial Refund Amount is not specified.');
	}

	if(isset($memo)) {
		$refund_request->setMemo($memo, 'iso-8859-1');
	} else {
		exit('Partial Refund Memo is not specified.');
	}
}

$caller =& PayPal::getCallerServices($profile);

// Execute SOAP request.
$response = $caller->RefundTransaction($refund_request);

switch($response->getAck()) {
	case 'Success':
	case 'SuccessWithWarning':
        // Extract the response details.
		$refund_tran_ID = $response->getRefundTransactionID();
		$gross_amt_obj = $response->getGrossRefundAmount();
		$gross_amt = $gross_amt_obj->_value;
		$currency_cd = $gross_amt_obj->_attributeValues['currencyID'];
		exit('Refund Completed Successfully: ' . print_r($response, true));

	default:
		exit('RefundTransaction failed: ' . print_r($response, true));
}

?>