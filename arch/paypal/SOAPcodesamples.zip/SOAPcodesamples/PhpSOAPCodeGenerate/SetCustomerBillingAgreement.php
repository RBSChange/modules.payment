<?php
/** SetCustomerBillingAgreement SOAP example; last modified 08MAY23.
 *
 *  SetCustomerBillingAgreement. 
*/

include 'ppsdk_include_path.inc';

require_once 'PayPal.php';
require_once 'PayPal/Profile/Handler/Array.php';
require_once 'PayPal/Profile/API.php';
require_once 'PayPal/Type/BillingAgreementDetailsType';
require_once 'PayPal/Type/SetCustomerBillingAgreementRequestType.php';
require_once 'PayPal/Type/SetCustomerBillingAgreementRequestDetailsType';
require_once 'PayPal/Type/SetCustomerBillingAgreementResponseType';

$environment = 'sandbox';	// or 'beta-sandbox' or 'live'

//--------------------------------------------------
// PROFILE
//--------------------------------------------------
/**
 *                    W A R N I N G
 * Do not embed plaintext credentials in your application code.
 * Doing so is insecure and against best practices.
 *
 * Your API credentials must be handled securely. Please consider
 * encrypting them for use in any production environment, and ensure
 * that only authorized individuals may view or modify them.
 */

$handler = & ProfileHandler_Array::getInstance(array(
            'username' => 'my_api_username',
            'certificateFile' => null,
            'subject' => null,
            'environment' => $environment));

$pid = ProfileHandler::generateID();

$profile = & new APIProfile($pid, $handler);

// Set up your API credentials, PayPal end point, and API version.
$profile->setAPIUsername('my_api_username');
$profile->setAPIPassword('my_api_password');
$profile->setSignature('my_api_signature');
$profile->setCertificateFile('my_cert_file_path');
$profile->setEnvironment($environment);
//--------------------------------------------------

$billig_agreement_request =& PayPal::getType('SetCustomerBillingAgreementRequestType');
$billig_agreement_request->setVersion("51.0");

// Set request-specific fields.
$returnURL = urlencode("my_return_url");
$cancelURL = urlencode("my_cancel_url");
$billingType = urlencode("RecurringPayments");	// or "MerchantInitiatedBilling"

$billig_agreement_request_details =& PayPal::getType('SetCustomerBillingAgreementRequestDetailsType');

$billig_agreement_request_details->setReturnURL($returnURL);
$billig_agreement_request_details->setCancelURL($cancelURL);

$billing_agreement_details =& PayPal::getType('BillingAgreementDetailsType');
$billing_agreement_details->setBillingType($billingType);
$billig_agreement_request_details->setBillingAgreementDetails($billing_agreement_details);

$billig_agreement_request->setSetCustomerBillingAgreementRequestDetails($billig_agreement_request_details);

$caller =& PayPal::getCallerServices($profile);

// Execute SOAP request.
$response = $caller->SetCustomerBillingAgreement($billig_agreement_request);

switch($response->getAck()) {
	case 'Success':
	case 'SuccessWithWarning':
        // Extract the response details.
		$token = $response->getToken();

		exit('SetCustomerBillingAgreement Completed Successfully: ' . print_r($response, true));

	default:
		exit('SetCustomerBillingAgreement failed: ' . print_r($response, true));
}

?>