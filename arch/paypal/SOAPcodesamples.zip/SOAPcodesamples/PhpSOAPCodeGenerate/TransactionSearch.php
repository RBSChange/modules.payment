<?php
/** TransactionSearch SOAP example; last modified 08MAY23.
 *
 *  Search your account history for transactions that meet the criteria you specify. 
*/

include 'ppsdk_include_path.inc';

require_once 'PayPal.php';
require_once 'PayPal/Profile/Handler/Array.php';
require_once 'PayPal/Profile/API.php';
require_once 'PayPal/Type/TransactionSearchRequestType.php';
require_once 'PayPal/Type/TransactionSearchResponseType.php';

$environment = 'sandbox';	// or 'beta-sandbox' or 'live'

//--------------------------------------------------
// PROFILE
//--------------------------------------------------
/**
 *                    W A R N I N G
 * Do not embed plaintext credentials in your application code.
 * Doing so is insecure and against best practices.
 *
 * Your API credentials must be handled securely. Please consider
 * encrypting them for use in any production environment, and ensure
 * that only authorized individuals may view or modify them.
 */

$handler = & ProfileHandler_Array::getInstance(array(
            'username' => 'my_api_username',
            'certificateFile' => null,
            'subject' => null,
            'environment' => $environment));

$pid = ProfileHandler::generateID();

$profile = & new APIProfile($pid, $handler);

// Set up your API credentials, PayPal end point, and API version.
$profile->setAPIUsername('my_api_username');
$profile->setAPIPassword('my_api_password');
$profile->setSignature('my_api_signature');
$profile->setCertificateFile('my_cert_file_path');
$profile->setEnvironment($environment);
//--------------------------------------------------

$trans_search =& PayPal::getType('TransactionSearchRequestType');
$trans_search->setVersion("51.0");

// Set request-specific fields.
$start_date_str;			// in 'mm/dd/ccyy' format
$end_date_str;				// in 'mm/dd/ccyy' format

$trans_search->setTransactionId('example_transaction_id');

if(isset($start_date_str)) {
   $start_time = strtotime($start_date_str);
   $iso_start = date('Y-m-d\T00:00:00\Z', $start_time);
   $trans_search->setStartDate($iso_start, 'iso-8859-1');
}

if(isset($end_date_str)) {
   $end_time = strtotime($end_date_str);
   $iso_end = date('Y-m-d\T24:00:00\Z', $end_time);
   $trans_search->setEndDate($iso_end, 'iso-8859-1');
}

$caller =& PayPal::getCallerServices($profile);

// Execute SOAP request.
$response = $caller->TransactionSearch($trans_search);

switch($response->getAck()) {
	case 'Success':
	case 'SuccessWithWarning':
        // Extract the response details.
		$ptsr = $response->getPaymentTransactions();
		if(!is_array($ptsr)) {
			$ptsr = array($ptsr);
		}

		$tran_id = array();
		$tran_ts = array();
		$tran_status = array();
		$tran_payer_name = array();
		$gross_amt_obj = array();
        $tran_amount = array();

		foreach($ptsr as $i => $trans) {
			$tran_id[$i] = $trans->getTransactionID();
			$tran_ts[$i] = $trans->getTimestamp();
			$tran_status[$i] = $trans->getStatus();
			$tran_payer_name[$i] = $trans->getPayerDisplayName();
			$gross_amt_obj[$i] = $trans->getGrossAmount();
        	$tran_amount[$i] = $gross_amt_obj->_value;
        }
		exit('TransactionSearch Completed Successfully: ' . print_r($response, true));

	default:
		exit('TransactionSearch failed: ' . print_r($response, true));
}

?>